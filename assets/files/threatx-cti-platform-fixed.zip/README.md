# ThreatX CTI Platform

## Cyber Threat Intelligence & Attack Surface Intelligence

Professional, multi-tenant CTI platform.

## Architecture

Browser --> localhost:5173 (Vite Dev Server) --> /api/* proxied --> localhost:8000 (FastAPI) --> MongoDB + Redis

## Quick Start

1. Copy .env.example to .env
2. Generate secret keys (openssl rand -hex 32)
3. docker-compose up --build
4. Open http://localhost:5173

## Ports

- Frontend: http://localhost:5173
- Backend API: http://localhost:8000
- Swagger: http://localhost:8000/docs

## Manual Setup

### Backend
- Create virtualenv and install dependencies from requirements.txt
- Set env vars: MONGODB_URI, SECRET_KEY, JWT_SECRET_KEY, ENCRYPTION_KEY, CORS_ORIGINS
- Run: uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload

### Frontend
- Install dependencies from package.json
- Run: npm run dev
- Vite proxies /api/* to backend

## Environment Variables

| Variable | Description |
|----------|-------------|
| SECRET_KEY | General secret |
| JWT_SECRET_KEY | JWT signing key |
| ENCRYPTION_KEY | Fernet encryption key (32 chars) |
| MONGODB_URI | MongoDB connection string |
| REDIS_URL | Redis connection string |
| CORS_ORIGINS | Allowed CORS origins |
| NMAP_ENABLED | Enable Nmap scanning |

## User Flow

1. Register at /register
2. Complete Setup Wizard
3. View Dashboard
4. Start Scans
5. Search intelligence
6. Generate PDF Reports

## API Sources

- HIBP: https://haveibeenpwned.com/API/Key
- Shodan: https://account.shodan.io/
- IntelX: https://intelx.io/account

## Adding a New Source

1. Create folder: backend/app/sources/newsource/
2. Implement BaseSource interface
3. Register in sources/registry.py
4. Add router

## Legal Notes on Nmap

- Only scans explicitly authorized assets
- Authorization confirmation required
- Default: -sV --version-light -T2 --top-ports 100
- All scans audit-logged

## Troubleshooting

### Network error: unable to connect to server
- Backend must be running on port 8000
- Docker users: check docker-compose logs backend
- .env file must exist (copy .env.example)
- Frontend proxies /api to backend via Vite

### Load Failed after login
- MongoDB must be accessible
- Check backend logs
- Verify env vars

## Tech Stack

- Frontend: React 18, Vite 5, TypeScript, Tailwind CSS, Recharts
- Backend: Python 3.11, FastAPI, Pydantic v2, Motor, JWT
- Database: MongoDB 7, Redis 7
- Sources: HIBP, Shodan, IntelX, Nmap, DNS, WHOIS, Subdomain
- Reports: ReportLab PDF generation
