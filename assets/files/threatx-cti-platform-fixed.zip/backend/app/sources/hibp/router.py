from fastapi import APIRouter, Depends
from ...core.tenant import get_current_user
router = APIRouter(prefix="/api/sources/hibp", tags=["sources-hibp"])

@router.get("/status")
async def hibp_status(user: dict = Depends(get_current_user)):
    from .client import HIBPSource
    return await HIBPSource().healthcheck()
