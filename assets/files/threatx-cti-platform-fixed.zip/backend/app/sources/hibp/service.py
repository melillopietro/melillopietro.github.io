from .client import HIBPSource
hibp_source = HIBPSource()
