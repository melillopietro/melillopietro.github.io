import httpx, asyncio
from typing import Any, List
from datetime import datetime
from ..base import BaseSource, SourceResult
from ...core.logging import logger

class HIBPSource(BaseSource):
    name = "HIBP"
    source_type = "api"
    BASE_URL = "https://haveibeenpwned.com/api/v3"

    async def validate_config(self, config: dict) -> bool:
        api_key = config.get("api_key")
        if not api_key: return False
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.get(f"{self.BASE_URL}/subscription/status", headers={"hibp-api-key": api_key, "user-agent": "ThreatX-CTI"})
                return resp.status_code == 200
        except: return False

    async def run(self, input_context: dict) -> List[SourceResult]:
        api_key = input_context.get("api_key")
        if not api_key: return []
        results = []
        emails = input_context.get("emails", [])
        org_id = input_context.get("organization_id", "")
        scan_id = input_context.get("scan_id", "")
        async with httpx.AsyncClient(timeout=15) as client:
            for email in emails:
                try:
                    resp = await client.get(f"{self.BASE_URL}/breachedaccount/{email}?truncateResponse=false",
                        headers={"hibp-api-key": api_key, "user-agent": "ThreatX-CTI"})
                    if resp.status_code == 200:
                        for breach in resp.json():
                            results.append(SourceResult(source_name=self.name, source_type=self.source_type,
                                collected_at=datetime.utcnow(), confidence=0.95,
                                severity=self._calc_severity(breach), tags=["breach"],
                                raw_response=breach, normalized_entity_type="breach",
                                normalized_value=email, organization_id=org_id, scan_id=scan_id,
                                metadata={"email": email, "breach_name": breach.get("Name"),
                                    "breach_date": breach.get("BreachDate"),
                                    "pwn_count": breach.get("PwnCount"),
                                    "data_classes": breach.get("DataClasses", []),
                                    "is_verified": breach.get("IsVerified"),
                                    "is_malware": breach.get("IsMalware")}))
                    elif resp.status_code == 429: break
                    elif resp.status_code == 401: break
                    await asyncio.sleep(1.6)
                except Exception as e:
                    logger.error(f"HIBP error for {email}: {e}")
        return results

    def normalize(self, raw_result: Any) -> List[SourceResult]:
        return [raw_result] if isinstance(raw_result, SourceResult) else []

    async def save(self, db, results: List[SourceResult]) -> int:
        saved = 0
        for r in results:
            doc = {"email": r.normalized_value, "source_name": self.name, "source_type": self.source_type,
                "scan_id": r.scan_id, "organization_id": r.organization_id,
                "breach_name": r.metadata.get("breach_name"), "breach_date": r.metadata.get("breach_date"),
                "pwn_count": r.metadata.get("pwn_count"), "data_classes": r.metadata.get("data_classes", []),
                "is_verified": r.metadata.get("is_verified"), "is_malware": r.metadata.get("is_malware"),
                "severity": r.severity, "confidence": r.confidence, "tags": r.tags,
                "collected_at": r.collected_at, "last_seen": r.collected_at, "status": "open"}
            await db.breaches.update_one({"email": r.normalized_value, "breach_name": r.metadata.get("breach_name")},
                {"$set": doc, "$setOnInsert": {"first_seen": r.collected_at}}, upsert=True)
            saved += 1
        return saved

    async def healthcheck(self) -> dict:
        return {"source": self.name, "status": "available", "type": self.source_type}

    def _calc_severity(self, b: dict) -> int:
        s = 40
        dc = b.get("DataClasses", [])
        if "Passwords" in dc: s += 25
        if "Credit cards" in dc: s += 20
        if b.get("IsVerified"): s += 10
        if b.get("IsMalware"): s += 15
        return min(100, s)
