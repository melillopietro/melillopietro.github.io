from fastapi import APIRouter, Depends
from ...core.tenant import get_current_user
router = APIRouter(prefix="/api/sources/subdomain", tags=["sources-subdomain"])
@router.get("/status")
async def status(user: dict = Depends(get_current_user)):
    from .service import SubdomainSource
    return await SubdomainSource().healthcheck()
