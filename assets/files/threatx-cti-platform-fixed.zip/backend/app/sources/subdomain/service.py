import asyncio, socket
from typing import Any, List
from datetime import datetime
from ..base import BaseSource, SourceResult
from ...core.logging import logger

COMMON_SUBS = ["www","mail","remote","blog","webmail","server","ns1","ns2","smtp","secure","vpn","m","shop","ftp",
    "test","portal","support","dev","web","admin","store","cdn","api","app","news","login","stage","staging",
    "demo","dashboard","cms","status","git","jenkins","ci","registry","docker","grafana","db","redis","mongo",
    "backup","internal","intranet","wiki","docs","sso","auth","accounts","billing","assets","static","media"]

class SubdomainSource(BaseSource):
    name = "SubdomainFinder"
    source_type = "passive_osint"

    async def validate_config(self, config: dict) -> bool:
        return bool(config.get("domains"))

    async def run(self, input_context: dict) -> List[SourceResult]:
        domains = input_context.get("domains", [])
        org_id = input_context.get("organization_id", "")
        scan_id = input_context.get("scan_id", "")
        results = []
        for domain in domains:
            discovered = await self._discover(domain)
            for sub, ips in discovered:
                results.append(SourceResult(source_name=self.name, source_type=self.source_type,
                    collected_at=datetime.utcnow(), confidence=0.95, severity=20,
                    tags=["subdomain", "discovery"], raw_response={"subdomain": sub, "ips": ips},
                    normalized_entity_type="subdomain", normalized_value=sub,
                    organization_id=org_id, scan_id=scan_id,
                    metadata={"parent_domain": domain, "subdomain": sub, "resolved_ips": ips}))
        logger.info(f"SubdomainFinder: Discovered {len(results)} subdomains")
        return results

    async def _discover(self, domain: str) -> List[tuple]:
        discovered = []
        async def check(prefix):
            fqdn = f"{prefix}.{domain}"
            try:
                loop = asyncio.get_event_loop()
                result = await asyncio.wait_for(loop.run_in_executor(None, socket.gethostbyname_ex, fqdn), timeout=3.0)
                if result and result[2]: return (fqdn, result[2])
            except: pass
            return None
        for i in range(0, len(COMMON_SUBS), 20):
            batch = COMMON_SUBS[i:i+20]
            tasks = [check(p) for p in batch]
            for r in await asyncio.gather(*tasks, return_exceptions=True):
                if r and not isinstance(r, Exception): discovered.append(r)
            await asyncio.sleep(0.1)
        return discovered

    def normalize(self, raw_result: Any) -> List[SourceResult]:
        return [raw_result] if isinstance(raw_result, SourceResult) else []

    async def save(self, db, results: List[SourceResult]) -> int:
        saved = 0
        for r in results:
            await db.assets_subdomains.update_one({"subdomain": r.metadata["subdomain"]},
                {"$set": {"subdomain": r.metadata["subdomain"], "parent_domain": r.metadata["parent_domain"],
                    "resolved_ips": r.metadata["resolved_ips"], "source_name": self.name,
                    "scan_id": r.scan_id, "organization_id": r.organization_id,
                    "collected_at": r.collected_at, "last_seen": r.collected_at, "status": "active"},
                "$setOnInsert": {"first_seen": r.collected_at}}, upsert=True)
            for ip in r.metadata.get("resolved_ips", []):
                await db.assets_ips.update_one({"ip": ip}, {"$setOnInsert": {
                    "ip": ip, "organization_id": r.organization_id, "source_name": self.name,
                    "discovered_via": r.metadata["subdomain"], "added_at": r.collected_at, "status": "active"}}, upsert=True)
            saved += 1
        return saved

    async def healthcheck(self) -> dict:
        return {"source": self.name, "status": "available", "type": self.source_type}
