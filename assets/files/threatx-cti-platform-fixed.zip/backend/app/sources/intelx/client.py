import httpx, asyncio
from typing import Any, List
from datetime import datetime
from ..base import BaseSource, SourceResult
from ...core.logging import logger

class IntelXSource(BaseSource):
    name = "IntelX"
    source_type = "api"
    BASE_URL = "https://2.intelx.io"

    async def validate_config(self, config: dict) -> bool:
        api_key = config.get("api_key")
        if not api_key: return False
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                return (await client.get(f"{self.BASE_URL}/authenticate/info", headers={"x-key": api_key})).status_code == 200
        except: return False

    async def run(self, input_context: dict) -> List[SourceResult]:
        api_key = input_context.get("api_key")
        if not api_key: return []
        results = []
        org_id = input_context.get("organization_id", "")
        scan_id = input_context.get("scan_id", "")
        search_terms = [(kw, "keyword") for kw in input_context.get("keywords", [])]
        search_terms += [(d, "domain") for d in input_context.get("domains", [])]
        search_terms += [(e, "email") for e in input_context.get("emails", [])]
        async with httpx.AsyncClient(timeout=30) as client:
            headers = {"x-key": api_key, "Content-Type": "application/json"}
            for term, term_type in search_terms:
                try:
                    resp = await client.post(f"{self.BASE_URL}/intelligent/search",
                        json={"term": term, "maxresults": 20, "media": 0, "sort": 2}, headers=headers)
                    if resp.status_code == 200:
                        sid = resp.json().get("id")
                        if sid:
                            await asyncio.sleep(2)
                            rr = await client.get(f"{self.BASE_URL}/intelligent/search/result?id={sid}&limit=20", headers=headers)
                            if rr.status_code == 200:
                                for rec in rr.json().get("records", []):
                                    bucket = rec.get("bucket", "")
                                    if "darknet" in bucket.lower(): mt, sev = "dark_web_reference", 75
                                    elif "leak" in bucket.lower(): mt, sev = "leak_reference", 65
                                    else: mt, sev = "keyword_match", 45
                                    results.append(SourceResult(source_name=self.name, source_type=self.source_type,
                                        collected_at=datetime.utcnow(), confidence=0.7, severity=sev,
                                        tags=["intelligence", mt], raw_response=rec,
                                        normalized_entity_type="mention", normalized_value=term,
                                        organization_id=org_id, scan_id=scan_id,
                                        metadata={"term": term, "term_type": term_type, "mention_type": mt, "bucket": bucket, "name": rec.get("name")}))
                    elif resp.status_code in (401, 402): break
                    await asyncio.sleep(1.0)
                except Exception as e:
                    logger.error(f"IntelX error for {term}: {e}")
        return results

    def normalize(self, raw_result: Any) -> List[SourceResult]:
        return [raw_result] if isinstance(raw_result, SourceResult) else []

    async def save(self, db, results: List[SourceResult]) -> int:
        saved = 0
        for r in results:
            await db.intelligence_mentions.insert_one({
                "term": r.metadata["term"], "term_type": r.metadata["term_type"],
                "mention_type": r.metadata["mention_type"], "bucket": r.metadata.get("bucket"),
                "name": r.metadata.get("name"), "source_name": self.name,
                "scan_id": r.scan_id, "organization_id": r.organization_id,
                "severity": r.severity, "confidence": r.confidence, "tags": r.tags,
                "collected_at": r.collected_at, "last_seen": r.collected_at, "status": "open"})
            saved += 1
        return saved

    async def healthcheck(self) -> dict:
        return {"source": self.name, "status": "available", "type": self.source_type}
