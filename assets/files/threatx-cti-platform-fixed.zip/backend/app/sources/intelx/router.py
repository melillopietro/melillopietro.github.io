from fastapi import APIRouter, Depends
from ...core.tenant import get_current_user
router = APIRouter(prefix="/api/sources/intelx", tags=["sources-intelx"])
@router.get("/status")
async def intelx_status(user: dict = Depends(get_current_user)):
    from .client import IntelXSource
    return await IntelXSource().healthcheck()
