import asyncio
from typing import Any, List
from datetime import datetime
from ..base import BaseSource, SourceResult
from ...core.logging import logger

try:
    import whois
    WHOIS_AVAILABLE = True
except ImportError:
    WHOIS_AVAILABLE = False

class WHOISSource(BaseSource):
    name = "WHOIS"
    source_type = "passive_osint"

    async def validate_config(self, config): return WHOIS_AVAILABLE and bool(config.get("domains"))

    async def run(self, input_context: dict) -> List[SourceResult]:
        if not WHOIS_AVAILABLE: return []
        domains = input_context.get("domains", [])
        org_id = input_context.get("organization_id", "")
        scan_id = input_context.get("scan_id", "")
        results = []
        loop = asyncio.get_event_loop()
        for domain in domains:
            try:
                w = await loop.run_in_executor(None, whois.whois, domain)
                if w:
                    data = {"registrar": w.registrar, "creation_date": str(w.creation_date) if w.creation_date else None,
                        "expiration_date": str(w.expiration_date) if w.expiration_date else None,
                        "name_servers": w.name_servers or [], "country": getattr(w, "country", None)}
                    results.append(SourceResult(source_name=self.name, source_type=self.source_type,
                        collected_at=datetime.utcnow(), confidence=0.9, severity=10,
                        tags=["whois","domain_info"], raw_response=data,
                        normalized_entity_type="whois_record", normalized_value=domain,
                        organization_id=org_id, scan_id=scan_id, metadata=data))
            except Exception as e:
                logger.warning(f"WHOIS failed for {domain}: {e}")
        return results

    def normalize(self, raw_result): return [raw_result] if isinstance(raw_result, SourceResult) else []

    async def save(self, db, results):
        saved = 0
        for r in results:
            await db.whois_records.update_one({"domain": r.normalized_value},
                {"$set": {"domain": r.normalized_value, **r.metadata,
                    "source_name": self.name, "scan_id": r.scan_id,
                    "organization_id": r.organization_id, "collected_at": r.collected_at},
                "$setOnInsert": {"first_seen": r.collected_at}}, upsert=True)
            saved += 1
        return saved

    async def healthcheck(self): return {"source": self.name, "status": "available" if WHOIS_AVAILABLE else "unavailable", "type": self.source_type}
