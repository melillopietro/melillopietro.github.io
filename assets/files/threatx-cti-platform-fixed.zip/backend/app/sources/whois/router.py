from fastapi import APIRouter, Depends
from ...core.tenant import get_current_user
router = APIRouter(prefix="/api/sources/whois", tags=["sources-whois"])
@router.get("/status")
async def whois_status(user: dict = Depends(get_current_user)):
    from .service import WHOISSource
    return await WHOISSource().healthcheck()
