from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional
from datetime import datetime
from pydantic import BaseModel

class SourceResult(BaseModel):
    source_name: str
    source_type: str
    collected_at: datetime
    confidence: float
    severity: int
    tags: List[str] = []
    raw_response: Optional[Dict[str, Any]] = None
    normalized_entity_type: str
    normalized_value: str
    organization_id: str
    scan_id: Optional[str] = None
    metadata: Dict[str, Any] = {}

class BaseSource(ABC):
    name: str = "base"
    source_type: str = "api"

    @abstractmethod
    async def validate_config(self, config: dict) -> bool: pass
    @abstractmethod
    async def run(self, input_context: dict) -> List[SourceResult]: pass
    @abstractmethod
    def normalize(self, raw_result: Any) -> List[SourceResult]: pass
    @abstractmethod
    async def save(self, db, results: List[SourceResult]) -> int: pass
    @abstractmethod
    async def healthcheck(self) -> dict: pass
    async def search(self, query: str, context: dict) -> List[SourceResult]: return []
