from fastapi import APIRouter, Depends
from ...core.tenant import get_current_user
router = APIRouter(prefix="/api/sources/shodan", tags=["sources-shodan"])
@router.get("/status")
async def shodan_status(user: dict = Depends(get_current_user)):
    from .client import ShodanSource
    return await ShodanSource().healthcheck()
