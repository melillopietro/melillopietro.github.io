from .client import ShodanSource
shodan_source = ShodanSource()
