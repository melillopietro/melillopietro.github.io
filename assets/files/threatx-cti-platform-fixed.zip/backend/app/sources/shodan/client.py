import httpx, asyncio
from typing import Any, List
from datetime import datetime
from ..base import BaseSource, SourceResult
from ...core.logging import logger

class ShodanSource(BaseSource):
    name = "Shodan"
    source_type = "api"
    BASE_URL = "https://api.shodan.io"

    async def validate_config(self, config: dict) -> bool:
        api_key = config.get("api_key")
        if not api_key: return False
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                return (await client.get(f"{self.BASE_URL}/api-info?key={api_key}")).status_code == 200
        except: return False

    async def run(self, input_context: dict) -> List[SourceResult]:
        api_key = input_context.get("api_key")
        if not api_key: return []
        results = []
        ips = input_context.get("ips", [])
        org_id = input_context.get("organization_id", "")
        scan_id = input_context.get("scan_id", "")
        async with httpx.AsyncClient(timeout=20) as client:
            for ip in ips:
                try:
                    resp = await client.get(f"{self.BASE_URL}/shodan/host/{ip}?key={api_key}")
                    if resp.status_code == 200:
                        data = resp.json()
                        for svc in data.get("data", []):
                            port = svc.get("port")
                            results.append(SourceResult(source_name=self.name, source_type=self.source_type,
                                collected_at=datetime.utcnow(), confidence=0.85,
                                severity=self._svc_severity(port, svc.get("product", "")),
                                tags=["exposed_service", f"port_{port}"], raw_response=svc,
                                normalized_entity_type="service", normalized_value=f"{ip}:{port}",
                                organization_id=org_id, scan_id=scan_id,
                                metadata={"ip": ip, "port": port, "transport": svc.get("transport", "tcp"),
                                    "product": svc.get("product", ""), "version": svc.get("version", ""),
                                    "hostnames": data.get("hostnames", []), "org": data.get("org"),
                                    "isp": data.get("isp"), "asn": data.get("asn"),
                                    "country": data.get("country_code"), "city": data.get("city")}))
                            for cve_id in svc.get("vulns", {}):
                                cvss = svc["vulns"][cve_id].get("cvss") if isinstance(svc["vulns"][cve_id], dict) else None
                                results.append(SourceResult(source_name=self.name, source_type=self.source_type,
                                    collected_at=datetime.utcnow(), confidence=0.8,
                                    severity=int((cvss or 5.0) * 10), tags=["vulnerability", "cve"],
                                    raw_response={"cve_id": cve_id}, normalized_entity_type="vulnerability",
                                    normalized_value=cve_id, organization_id=org_id, scan_id=scan_id,
                                    metadata={"ip": ip, "port": port, "cve_id": cve_id, "cvss": cvss,
                                        "product": svc.get("product", ""), "version": svc.get("version", "")}))
                    elif resp.status_code in (401, 429): break
                    await asyncio.sleep(1.0)
                except Exception as e:
                    logger.error(f"Shodan error for {ip}: {e}")
        return results

    def normalize(self, raw_result: Any) -> List[SourceResult]:
        return [raw_result] if isinstance(raw_result, SourceResult) else []

    async def save(self, db, results: List[SourceResult]) -> int:
        saved = 0
        for r in results:
            if r.normalized_entity_type == "service":
                await db.exposed_services.update_one({"ip": r.metadata["ip"], "port": r.metadata["port"]},
                    {"$set": {"ip": r.metadata["ip"], "port": r.metadata["port"],
                        "transport": r.metadata.get("transport"), "product": r.metadata.get("product"),
                        "version": r.metadata.get("version"), "hostnames": r.metadata.get("hostnames", []),
                        "org": r.metadata.get("org"), "country": r.metadata.get("country"),
                        "source_name": self.name, "source_type": self.source_type,
                        "scan_id": r.scan_id, "organization_id": r.organization_id,
                        "severity": r.severity, "confidence": r.confidence,
                        "collected_at": r.collected_at, "last_seen": r.collected_at, "status": "open"},
                    "$setOnInsert": {"first_seen": r.collected_at}}, upsert=True)
            elif r.normalized_entity_type == "vulnerability":
                await db.vulnerabilities.update_one({"cve_id": r.metadata["cve_id"], "ip": r.metadata["ip"]},
                    {"$set": {"cve_id": r.metadata["cve_id"], "ip": r.metadata["ip"],
                        "port": r.metadata.get("port"), "cvss": r.metadata.get("cvss"),
                        "product": r.metadata.get("product"), "version": r.metadata.get("version"),
                        "source_name": self.name, "source_type": self.source_type,
                        "scan_id": r.scan_id, "organization_id": r.organization_id,
                        "severity": r.severity, "confidence": r.confidence,
                        "collected_at": r.collected_at, "last_seen": r.collected_at, "status": "open"},
                    "$setOnInsert": {"first_seen": r.collected_at}}, upsert=True)
            saved += 1
        return saved

    async def healthcheck(self) -> dict:
        return {"source": self.name, "status": "available", "type": self.source_type}

    def _svc_severity(self, port: int, product: str) -> int:
        high = {21: 70, 23: 80, 445: 75, 3389: 80, 5900: 75}
        return high.get(port, 30)
