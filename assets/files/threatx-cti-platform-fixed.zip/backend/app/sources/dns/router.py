from fastapi import APIRouter, Depends
from ...core.tenant import get_current_user
router = APIRouter(prefix="/api/sources/dns", tags=["sources-dns"])
@router.get("/status")
async def dns_status(user: dict = Depends(get_current_user)):
    from .service import DNSSource
    return await DNSSource().healthcheck()
