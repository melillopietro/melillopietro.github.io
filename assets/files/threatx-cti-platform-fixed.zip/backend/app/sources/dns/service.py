import asyncio, socket
from typing import Any, List
from datetime import datetime
from ..base import BaseSource, SourceResult
from ...core.logging import logger

class DNSSource(BaseSource):
    name = "DNSResolver"
    source_type = "passive_osint"

    async def validate_config(self, config): return bool(config.get("domains"))

    async def run(self, input_context: dict) -> List[SourceResult]:
        domains = input_context.get("domains", []) + input_context.get("subdomains", [])
        org_id = input_context.get("organization_id", "")
        scan_id = input_context.get("scan_id", "")
        results = []
        loop = asyncio.get_event_loop()
        for domain in list(set(domains))[:100]:
            try:
                r = await asyncio.wait_for(loop.run_in_executor(None, socket.gethostbyname_ex, domain), timeout=5)
                if r and r[2]:
                    results.append(SourceResult(source_name=self.name, source_type=self.source_type,
                        collected_at=datetime.utcnow(), confidence=0.95, severity=10,
                        tags=["dns","resolution"], raw_response={"A": r[2], "aliases": r[1]},
                        normalized_entity_type="dns_record", normalized_value=domain,
                        organization_id=org_id, scan_id=scan_id,
                        metadata={"domain": domain, "records": {"A": r[2], "CNAME": r[1]}}))
            except: pass
        logger.info(f"DNSResolver: Resolved {len(results)} targets")
        return results

    def normalize(self, raw_result): return [raw_result] if isinstance(raw_result, SourceResult) else []

    async def save(self, db, results):
        saved = 0
        for r in results:
            await db.dns_records.update_one({"domain": r.metadata["domain"]},
                {"$set": {"domain": r.metadata["domain"], "records": r.metadata["records"],
                    "source_name": self.name, "source_type": self.source_type,
                    "scan_id": r.scan_id, "organization_id": r.organization_id,
                    "collected_at": r.collected_at, "last_seen": r.collected_at},
                "$setOnInsert": {"first_seen": r.collected_at}}, upsert=True)
            for ip in r.metadata.get("records", {}).get("A", []):
                await db.assets_ips.update_one({"ip": ip}, {"$setOnInsert": {
                    "ip": ip, "organization_id": r.organization_id, "source_name": self.name,
                    "source_type": self.source_type, "discovered_via": r.metadata["domain"],
                    "added_at": r.collected_at, "status": "active"}}, upsert=True)
            saved += 1
        return saved

    async def healthcheck(self): return {"source": self.name, "status": "available", "type": self.source_type}
