from typing import Dict, Optional
from .base import BaseSource
from ..core.logging import logger

class SourceRegistry:
    _sources: Dict[str, BaseSource] = {}

    @classmethod
    def register(cls, source: BaseSource):
        cls._sources[source.name] = source
        logger.info(f"Source registered: {source.name}")

    @classmethod
    def get(cls, name: str) -> Optional[BaseSource]:
        return cls._sources.get(name)

    @classmethod
    def get_all(cls) -> Dict[str, BaseSource]:
        return cls._sources.copy()

    @classmethod
    def get_names(cls) -> list:
        return list(cls._sources.keys())

def init_sources():
    from .hibp.client import HIBPSource
    from .shodan.client import ShodanSource
    from .intelx.client import IntelXSource
    from .nmap.client import NmapSource
    from .subdomain.service import SubdomainSource
    from .dns.service import DNSSource
    from .whois.service import WHOISSource
    SourceRegistry.register(HIBPSource())
    SourceRegistry.register(ShodanSource())
    SourceRegistry.register(IntelXSource())
    SourceRegistry.register(NmapSource())
    SourceRegistry.register(SubdomainSource())
    SourceRegistry.register(DNSSource())
    SourceRegistry.register(WHOISSource())
    logger.info(f"Initialized {len(SourceRegistry.get_all())} sources")
