from .client import NmapSource
nmap_source = NmapSource()
