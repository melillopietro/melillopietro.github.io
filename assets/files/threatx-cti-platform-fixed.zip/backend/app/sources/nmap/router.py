from fastapi import APIRouter, Depends
from ...core.tenant import get_current_user
router = APIRouter(prefix="/api/sources/nmap", tags=["sources-nmap"])
@router.get("/status")
async def nmap_status(user: dict = Depends(get_current_user)):
    from .client import NmapSource
    return await NmapSource().healthcheck()
