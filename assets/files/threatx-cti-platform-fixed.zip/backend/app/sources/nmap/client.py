import asyncio, xml.etree.ElementTree as ET
from typing import Any, List
from datetime import datetime
from ..base import BaseSource, SourceResult
from ...core.logging import logger
from ...core.config import get_settings
settings = get_settings()

class NmapSource(BaseSource):
    name = "Nmap"
    source_type = "active_scan"

    async def validate_config(self, config: dict) -> bool:
        if not config.get("authorization_confirmed"): return False
        try:
            proc = await asyncio.create_subprocess_exec("nmap", "--version", stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            stdout, _ = await proc.communicate()
            return b"Nmap" in stdout
        except: return False

    async def run(self, input_context: dict) -> List[SourceResult]:
        if not input_context.get("authorization_confirmed") or not settings.NMAP_ENABLED: return []
        ips = input_context.get("ips", [])[:settings.NMAP_MAX_HOSTS]
        org_id = input_context.get("organization_id", "")
        scan_id = input_context.get("scan_id", "")
        results = []
        for ip in ips:
            try:
                services = await self._scan_host(ip, settings.NMAP_DEFAULT_ARGS)
                for svc in services:
                    results.append(SourceResult(source_name=self.name, source_type=self.source_type,
                        collected_at=datetime.utcnow(), confidence=0.9,
                        severity=self._calc_sev(svc.get("port", 0)),
                        tags=["active_scan", "exposed_service"], raw_response=svc,
                        normalized_entity_type="service", normalized_value=f"{ip}:{svc['port']}",
                        organization_id=org_id, scan_id=scan_id,
                        metadata={"ip": ip, "port": svc["port"], "protocol": svc.get("protocol", "tcp"),
                            "state": svc.get("state", "open"), "service_name": svc.get("service", ""),
                            "product": svc.get("product", ""), "version": svc.get("version", "")}))
            except Exception as e:
                logger.error(f"Nmap scan failed for {ip}: {e}")
        return results

    async def _scan_host(self, ip: str, args: str) -> List[dict]:
        cmd = f"nmap {args} -oX - {ip}"
        try:
            proc = await asyncio.create_subprocess_shell(cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=settings.NMAP_TIMEOUT)
            if proc.returncode != 0: return []
            return self._parse_xml(stdout.decode())
        except asyncio.TimeoutError: return []

    def _parse_xml(self, xml_output: str) -> List[dict]:
        services = []
        try:
            root = ET.fromstring(xml_output)
            for port_elem in root.findall(".//port"):
                state_elem = port_elem.find("state")
                service_elem = port_elem.find("service")
                if state_elem is not None and state_elem.get("state") == "open":
                    svc = {"port": int(port_elem.get("portid", 0)), "protocol": port_elem.get("protocol", "tcp"), "state": "open"}
                    if service_elem is not None:
                        svc.update({"service": service_elem.get("name", ""), "product": service_elem.get("product", ""), "version": service_elem.get("version", "")})
                    services.append(svc)
        except ET.ParseError: pass
        return services

    def normalize(self, raw_result: Any) -> List[SourceResult]:
        return [raw_result] if isinstance(raw_result, SourceResult) else []

    async def save(self, db, results: List[SourceResult]) -> int:
        saved = 0
        for r in results:
            await db.exposed_services.update_one({"ip": r.metadata["ip"], "port": r.metadata["port"], "source_name": self.name},
                {"$set": {"ip": r.metadata["ip"], "port": r.metadata["port"], "protocol": r.metadata.get("protocol"),
                    "service_name": r.metadata.get("service_name"), "product": r.metadata.get("product"),
                    "version": r.metadata.get("version"), "source_name": self.name, "source_type": self.source_type,
                    "scan_id": r.scan_id, "organization_id": r.organization_id,
                    "severity": r.severity, "confidence": r.confidence,
                    "collected_at": r.collected_at, "last_seen": r.collected_at, "status": "open"},
                "$setOnInsert": {"first_seen": r.collected_at}}, upsert=True)
            saved += 1
        return saved

    async def healthcheck(self) -> dict:
        try:
            proc = await asyncio.create_subprocess_exec("nmap", "--version", stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            await proc.communicate()
            avail = proc.returncode == 0
        except: avail = False
        return {"source": self.name, "status": "available" if avail else "unavailable", "type": self.source_type, "enabled": settings.NMAP_ENABLED}

    def _calc_sev(self, port: int) -> int:
        return {21: 65, 23: 80, 445: 75, 3389: 80, 5900: 75, 1433: 70, 3306: 70}.get(port, 35)
