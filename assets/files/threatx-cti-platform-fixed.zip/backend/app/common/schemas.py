from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime
from enum import Enum

class EntityType(str, Enum):
    DOMAIN = "domain"
    SUBDOMAIN = "subdomain"
    IP = "ip"
    EMAIL = "email"
    SERVICE = "service"
    VULNERABILITY = "vulnerability"
    BREACH = "breach"
    MENTION = "mention"

class FindingStatus(str, Enum):
    OPEN = "open"
    ACKNOWLEDGED = "acknowledged"
    REMEDIATED = "remediated"
    FALSE_POSITIVE = "false_positive"

class Finding(BaseModel):
    id: Optional[str] = None
    organization_id: str
    scan_id: Optional[str] = None
    title: str
    description: Optional[str] = None
    entity_type: EntityType
    entity_value: str
    source_name: str
    source_type: str
    severity: int = Field(ge=0, le=100)
    confidence: float = Field(ge=0.0, le=1.0)
    tags: List[str] = []
    first_seen: Optional[datetime] = None
    last_seen: Optional[datetime] = None
    status: FindingStatus = FindingStatus.OPEN
