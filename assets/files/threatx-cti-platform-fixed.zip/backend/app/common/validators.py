import re

def validate_domain(domain: str) -> bool:
    return bool(re.match(r'^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$', domain))

def validate_ip(ip: str) -> bool:
    parts = ip.split('.')
    return len(parts) == 4 and all(p.isdigit() and 0 <= int(p) <= 255 for p in parts)

def validate_email(email: str) -> bool:
    return bool(re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email))

def sanitize_search_query(query: str) -> str:
    for c in ['$', '{', '}']: query = query.replace(c, '')
    return query.strip()[:200]
