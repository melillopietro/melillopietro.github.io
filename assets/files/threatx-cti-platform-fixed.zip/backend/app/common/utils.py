from datetime import datetime
from bson import ObjectId

def serialize_doc(doc: dict) -> dict:
    if not doc: return {}
    result = {}
    for k, v in doc.items():
        if isinstance(v, ObjectId): result[k] = str(v)
        elif isinstance(v, datetime): result[k] = v.isoformat()
        elif isinstance(v, bytes): result[k] = None
        elif isinstance(v, dict): result[k] = serialize_doc(v)
        else: result[k] = v
    return result
