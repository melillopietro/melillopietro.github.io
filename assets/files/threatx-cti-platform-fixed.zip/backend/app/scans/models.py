from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime
from enum import Enum

class ScanStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"

class ScanCreate(BaseModel):
    scan_type: str = "light"
