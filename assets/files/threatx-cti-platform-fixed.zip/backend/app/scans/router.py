from fastapi import APIRouter, HTTPException, Depends
from bson import ObjectId
from datetime import datetime
from .orchestrator import ScanOrchestrator
from ..core.database import get_client, get_core_db, get_org_db
from ..core.tenant import get_current_user

router = APIRouter(prefix="/api/orgs/{org_id}/scans", tags=["scans"])

@router.post("/start")
async def start_scan(org_id: str, user: dict = Depends(get_current_user)):
    client = await get_client()
    core_db = get_core_db(client)
    membership = await core_db.memberships.find_one({"user_id": str(user["_id"]), "organization_id": org_id})
    if not membership: raise HTTPException(status_code=403, detail="Access denied")
    org = await core_db.organizations.find_one({"_id": ObjectId(org_id)})
    if not org: raise HTTPException(status_code=404, detail="Organization not found")
    orchestrator = ScanOrchestrator()
    try: scan_id = await orchestrator.start_scan(org_id, org["slug"])
    except ValueError as e: raise HTTPException(status_code=400, detail=str(e))
    await core_db.audit_logs.insert_one({"action": "scan_started", "user_id": str(user["_id"]), "organization_id": org_id, "scan_id": scan_id, "timestamp": datetime.utcnow()})
    return {"scan_id": scan_id, "status": "running"}

@router.get("")
async def list_scans(org_id: str, user: dict = Depends(get_current_user)):
    client = await get_client()
    core_db = get_core_db(client)
    membership = await core_db.memberships.find_one({"user_id": str(user["_id"]), "organization_id": org_id})
    if not membership: raise HTTPException(status_code=403, detail="Access denied")
    org = await core_db.organizations.find_one({"_id": ObjectId(org_id)})
    org_db = get_org_db(client, org["slug"])
    scans = await org_db.scan_jobs.find().sort("created_at", -1).limit(50).to_list(50)
    return [{"id": str(s["_id"]), "scan_type": s["scan_type"], "status": s["status"],
        "steps": s.get("steps", []), "created_at": s["created_at"].isoformat(),
        "completed_at": s["completed_at"].isoformat() if s.get("completed_at") else None,
        "total_findings": s.get("total_findings", 0), "progress": s.get("progress", 0)} for s in scans]

@router.get("/{scan_id}")
async def get_scan(org_id: str, scan_id: str, user: dict = Depends(get_current_user)):
    client = await get_client()
    core_db = get_core_db(client)
    membership = await core_db.memberships.find_one({"user_id": str(user["_id"]), "organization_id": org_id})
    if not membership: raise HTTPException(status_code=403, detail="Access denied")
    org = await core_db.organizations.find_one({"_id": ObjectId(org_id)})
    org_db = get_org_db(client, org["slug"])
    scan = await org_db.scan_jobs.find_one({"_id": ObjectId(scan_id)})
    if not scan: raise HTTPException(status_code=404, detail="Scan not found")
    return {"id": str(scan["_id"]), "scan_type": scan["scan_type"], "status": scan["status"],
        "steps": scan.get("steps", []), "created_at": scan["created_at"].isoformat(),
        "started_at": scan["started_at"].isoformat() if scan.get("started_at") else None,
        "completed_at": scan["completed_at"].isoformat() if scan.get("completed_at") else None,
        "total_findings": scan.get("total_findings", 0), "progress": scan.get("progress", 0)}
