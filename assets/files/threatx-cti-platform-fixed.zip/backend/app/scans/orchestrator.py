import asyncio
from datetime import datetime
from bson import ObjectId
from ..core.database import get_client, get_core_db, get_org_db
from ..core.security import decrypt_api_key
from ..core.logging import logger
from ..sources.registry import SourceRegistry

class ScanOrchestrator:
    PIPELINE = [
        {"name": "Subdomain Discovery", "source_name": "SubdomainFinder", "key": "subdomain"},
        {"name": "DNS Resolution", "source_name": "DNSResolver", "key": "dns"},
        {"name": "WHOIS Lookup", "source_name": "WHOIS", "key": "whois"},
        {"name": "Shodan Enrichment", "source_name": "Shodan", "key": "shodan"},
        {"name": "HIBP Breach Check", "source_name": "HIBP", "key": "hibp"},
        {"name": "IntelX Intelligence", "source_name": "IntelX", "key": "intelx"},
        {"name": "Nmap Active Scan", "source_name": "Nmap", "key": "nmap"},
    ]

    async def start_scan(self, org_id: str, org_slug: str, scan_type: str = "light") -> str:
        client = await get_client()
        org_db = get_org_db(client, org_slug)
        profile = await org_db.organization_profile.find_one({"organization_id": org_id})
        if not profile: raise ValueError("Organization profile not found")

        scan_policy = profile.get("scan_policy", {})
        api_sources = profile.get("api_sources", {})
        steps = []
        for s in self.PIPELINE:
            skip = False
            k = s["key"]
            if k in api_sources and api_sources[k].get("status") == "not_configured" and k in ("shodan","hibp","intelx"):
                skip = True
            if k == "nmap" and (not scan_policy.get("nmap_enabled") or not profile.get("authorization_confirmed")):
                skip = True
            steps.append({"name": s["name"], "source_name": s["source_name"], "status": "skipped" if skip else "pending",
                "started_at": None, "completed_at": None, "error_message": None, "progress": 0, "results_count": 0})

        scan_doc = {"organization_id": org_id, "scan_type": scan_type, "status": "pending",
            "steps": steps, "created_at": datetime.utcnow(), "started_at": None,
            "completed_at": None, "total_findings": 0, "progress": 0}
        result = await org_db.scan_jobs.insert_one(scan_doc)
        scan_id = str(result.inserted_id)
        asyncio.create_task(self._run_pipeline(org_id, org_slug, scan_id, profile))
        logger.info(f"Scan started: {scan_id}")
        return scan_id

    async def _run_pipeline(self, org_id, org_slug, scan_id, profile):
        client = await get_client()
        org_db = get_org_db(client, org_slug)
        await org_db.scan_jobs.update_one({"_id": ObjectId(scan_id)}, {"$set": {"status": "running", "started_at": datetime.utcnow()}})

        api_sources = profile.get("api_sources", {})
        domains = profile.get("domains", [])
        ips = list(profile.get("ips", []))
        keywords = profile.get("keywords", []) + profile.get("brand_keywords", [])
        email_domains = profile.get("email_domains", [])
        discovered_subs = []
        total_findings = 0

        for idx, step_def in enumerate(self.PIPELINE):
            scan = await org_db.scan_jobs.find_one({"_id": ObjectId(scan_id)})
            if scan["steps"][idx]["status"] == "skipped": continue

            await self._upd_step(org_db, scan_id, idx, {"status": "running", "started_at": datetime.utcnow()})
            try:
                source = SourceRegistry.get(step_def["source_name"])
                if not source:
                    await self._upd_step(org_db, scan_id, idx, {"status": "skipped", "error_message": "Source not registered"})
                    continue

                context = {"organization_id": org_id, "scan_id": scan_id, "domains": domains,
                    "ips": list(set(ips)), "subdomains": discovered_subs, "keywords": keywords,
                    "emails": [f"info@{d}" for d in email_domains],
                    "email_domains": email_domains,
                    "authorization_confirmed": profile.get("authorization_confirmed", False)}

                k = step_def["key"]
                if k in api_sources and api_sources[k].get("api_key_encrypted"):
                    try: context["api_key"] = decrypt_api_key(api_sources[k]["api_key_encrypted"])
                    except: pass

                results = await source.run(context)
                if results:
                    saved = await source.save(org_db, results)
                    total_findings += saved
                    if k == "subdomain":
                        for r in results:
                            discovered_subs.append(r.metadata.get("subdomain", ""))
                            ips.extend(r.metadata.get("resolved_ips", []))
                    elif k == "dns":
                        for r in results:
                            ips.extend(r.metadata.get("records", {}).get("A", []))

                await self._upd_step(org_db, scan_id, idx, {"status": "completed", "completed_at": datetime.utcnow(), "progress": 100, "results_count": len(results)})
            except Exception as e:
                logger.error(f"Step {step_def['source_name']} failed: {e}")
                await self._upd_step(org_db, scan_id, idx, {"status": "failed", "completed_at": datetime.utcnow(), "error_message": str(e)})

            progress = int(((idx + 1) / len(self.PIPELINE)) * 100)
            await org_db.scan_jobs.update_one({"_id": ObjectId(scan_id)}, {"$set": {"progress": progress, "total_findings": total_findings}})

        # Run risk scoring
        from ..risk.engine import RiskEngine
        try:
            engine = RiskEngine()
            await engine.calculate_risk(org_db, org_id, scan_id)
        except Exception as e:
            logger.error(f"Risk calculation failed: {e}")

        await org_db.scan_jobs.update_one({"_id": ObjectId(scan_id)},
            {"$set": {"status": "completed", "completed_at": datetime.utcnow(), "progress": 100, "total_findings": total_findings}})
        logger.info(f"Scan completed: {scan_id}, findings: {total_findings}")

    async def _upd_step(self, db, scan_id, idx, update):
        await db.scan_jobs.update_one({"_id": ObjectId(scan_id)}, {"$set": {f"steps.{idx}.{k}": v for k, v in update.items()}})
