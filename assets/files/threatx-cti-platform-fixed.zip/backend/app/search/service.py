import re
from datetime import datetime
from motor.motor_asyncio import AsyncIOMotorDatabase

class SearchService:
    async def search(self, db: AsyncIOMotorDatabase, query: str, org_id: str, limit: int = 50) -> dict:
        results = {"query": query, "total": 0, "assets": [], "breaches": [], "vulnerabilities": [], "services": [], "intelligence": []}
        q = {"$regex": re.escape(query), "$options": "i"}

        for d in await db.assets_domains.find({"domain": q}).limit(limit).to_list(limit):
            results["assets"].append({"type": "domain", "value": d["domain"], "id": str(d["_id"])})
        for s in await db.assets_subdomains.find({"subdomain": q}).limit(limit).to_list(limit):
            results["assets"].append({"type": "subdomain", "value": s["subdomain"], "id": str(s["_id"])})
        for i in await db.assets_ips.find({"ip": q}).limit(limit).to_list(limit):
            results["assets"].append({"type": "ip", "value": i["ip"], "id": str(i["_id"])})

        for b in await db.breaches.find({"$or": [{"email": q}, {"breach_name": q}]}).limit(limit).to_list(limit):
            results["breaches"].append({"email": b.get("email"), "breach_name": b.get("breach_name"), "severity": b.get("severity"), "id": str(b["_id"])})

        for v in await db.vulnerabilities.find({"$or": [{"cve_id": q}, {"product": q}, {"ip": q}]}).limit(limit).to_list(limit):
            results["vulnerabilities"].append({"cve_id": v.get("cve_id"), "ip": v.get("ip"), "cvss": v.get("cvss"), "id": str(v["_id"])})

        for s in await db.exposed_services.find({"$or": [{"ip": q}, {"product": q}, {"service_name": q}]}).limit(limit).to_list(limit):
            results["services"].append({"ip": s.get("ip"), "port": s.get("port"), "product": s.get("product"), "id": str(s["_id"])})

        for i in await db.intelligence_mentions.find({"$or": [{"term": q}, {"name": q}]}).limit(limit).to_list(limit):
            results["intelligence"].append({"term": i.get("term"), "mention_type": i.get("mention_type"), "severity": i.get("severity"), "id": str(i["_id"])})

        results["total"] = sum(len(v) for v in results.values() if isinstance(v, list))
        await db.search_history.insert_one({"query": query, "results_count": results["total"], "searched_at": datetime.utcnow(), "organization_id": org_id})
        return results
