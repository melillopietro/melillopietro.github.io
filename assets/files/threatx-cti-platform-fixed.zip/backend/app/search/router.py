from fastapi import APIRouter, HTTPException, Depends, Query
from bson import ObjectId
from .service import SearchService
from ..core.database import get_client, get_core_db, get_org_db
from ..core.tenant import get_current_user

router = APIRouter(prefix="/api/orgs/{org_id}/search", tags=["search"])

@router.get("")
async def search(org_id: str, q: str = Query(..., min_length=1), user: dict = Depends(get_current_user)):
    client = await get_client()
    core_db = get_core_db(client)
    membership = await core_db.memberships.find_one({"user_id": str(user["_id"]), "organization_id": org_id})
    if not membership: raise HTTPException(status_code=403, detail="Access denied")
    org = await core_db.organizations.find_one({"_id": ObjectId(org_id)})
    org_db = get_org_db(client, org["slug"])
    service = SearchService()
    return await service.search(org_db, q, org_id)
