from pydantic import BaseModel
from typing import Dict, List
from datetime import datetime

class RiskScore(BaseModel):
    final_score: int
    risk_level: str
    category_scores: Dict[str, int]
    top_risk_drivers: List[Dict]
    recommended_actions: List[str]
    source_distribution: Dict[str, int]
    calculated_at: datetime
