import math
from datetime import datetime
from typing import Optional
from motor.motor_asyncio import AsyncIOMotorDatabase
from ..core.logging import logger

class RiskEngine:
    CATEGORY_WEIGHTS = {"exposure": 0.30, "vulnerability": 0.30, "breach": 0.25, "intelligence": 0.15}

    async def calculate_risk(self, db: AsyncIOMotorDatabase, org_id: str, scan_id: Optional[str] = None) -> dict:
        exposure = await self._exposure(db)
        vuln = await self._vulnerability(db)
        breach = await self._breach(db)
        intel = await self._intelligence(db)

        raw = (exposure * self.CATEGORY_WEIGHTS["exposure"] + vuln * self.CATEGORY_WEIGHTS["vulnerability"] +
               breach * self.CATEGORY_WEIGHTS["breach"] + intel * self.CATEGORY_WEIGHTS["intelligence"])
        boost = await self._confidence_boost(db)
        final_score = min(100, int(raw + boost))
        risk_level = "Critical" if final_score >= 80 else "High" if final_score >= 60 else "Medium" if final_score >= 40 else "Low"

        drivers = sorted([{"category": "Exposure", "score": int(exposure)}, {"category": "Vulnerabilities", "score": int(vuln)},
            {"category": "Breaches", "score": int(breach)}, {"category": "Intelligence", "score": int(intel)}], key=lambda x: -x["score"])
        recommendations = self._recommendations(exposure, vuln, breach, intel)
        source_dist = await self._source_dist(db)

        snapshot = {"organization_id": org_id, "scan_id": scan_id, "final_score": final_score,
            "risk_level": risk_level, "category_scores": {"exposure": int(exposure), "vulnerability": int(vuln), "breach": int(breach), "intelligence": int(intel)},
            "confidence_boost": boost, "top_risk_drivers": drivers, "source_distribution": source_dist,
            "recommended_actions": recommendations, "calculated_at": datetime.utcnow()}
        await db.risk_snapshots.insert_one(snapshot)
        logger.info(f"Risk: {final_score} ({risk_level}) for {org_id}")
        return snapshot

    async def _exposure(self, db) -> float:
        s = 0.0
        s += min(40, await db.exposed_services.count_documents({"status": "open"}) * 5)
        s += min(15, await db.assets_ips.count_documents({}) * 2)
        s += min(30, await db.exposed_services.count_documents({"port": {"$in": [21,23,445,3389,5900]}, "status": "open"}) * 10)
        s += min(15, await db.assets_subdomains.count_documents({}) * 0.5)
        return min(100, s)

    async def _vulnerability(self, db) -> float:
        vulns = await db.vulnerabilities.find({"status": "open"}).to_list(500)
        if not vulns: return 0.0
        s = min(30, len(vulns) * 3)
        max_cvss = max((v.get("cvss") or 0 for v in vulns), default=0)
        s += max_cvss * 5
        s += min(20, sum(1 for v in vulns if (v.get("cvss") or 0) >= 9) * 10)
        return min(100, s)

    async def _breach(self, db) -> float:
        breaches = await db.breaches.find({"status": "open"}).to_list(500)
        if not breaches: return 0.0
        s = min(25, len(set(b.get("email") for b in breaches)) * 5)
        s += min(20, len(set(b.get("breach_name") for b in breaches)) * 3)
        sensitive = {"Passwords", "Credit cards", "Social security numbers"}
        for b in breaches:
            if set(b.get("data_classes", [])) & sensitive: s += 3
        s += min(15, sum(1 for b in breaches if b.get("is_malware")) * 8)
        return min(100, s)

    async def _intelligence(self, db) -> float:
        mentions = await db.intelligence_mentions.find({"status": "open"}).to_list(200)
        if not mentions: return 0.0
        s = 0.0
        for m in mentions:
            mt = m.get("mention_type", "keyword_match")
            if mt == "dark_web_reference": s += 15
            elif mt == "credential_exposure": s += 20
            elif mt == "leak_reference": s += 12
            else: s += 5
        return min(100, s)

    async def _confidence_boost(self, db) -> float:
        shodan_ips = set()
        nmap_ips = set()
        async for svc in db.exposed_services.find({"source_name": "Shodan"}): shodan_ips.add(svc.get("ip"))
        async for svc in db.exposed_services.find({"source_name": "Nmap"}): nmap_ips.add(svc.get("ip"))
        return min(10, len(shodan_ips & nmap_ips) * 2)

    async def _source_dist(self, db) -> dict:
        dist = {}
        for col in ["exposed_services", "vulnerabilities", "breaches", "intelligence_mentions"]:
            async for doc in db[col].aggregate([{"$group": {"_id": "$source_name", "count": {"$sum": 1}}}]):
                dist[doc["_id"] or "Unknown"] = dist.get(doc["_id"] or "Unknown", 0) + doc["count"]
        return dist

    def _recommendations(self, exp, vuln, breach, intel):
        r = []
        if exp > 60: r += ["Close unnecessary exposed services", "Review firewall rules"]
        if vuln > 60: r += ["Patch critical CVEs immediately", "Implement vulnerability management"]
        if breach > 60: r += ["Force password resets for compromised accounts", "Enable MFA"]
        if intel > 40: r += ["Investigate dark web mentions", "Engage threat intelligence team"]
        return r or ["Maintain current security posture", "Schedule regular scans"]
