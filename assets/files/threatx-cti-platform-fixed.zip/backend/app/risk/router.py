from fastapi import APIRouter, HTTPException, Depends
from bson import ObjectId
from .engine import RiskEngine
from ..core.database import get_client, get_core_db, get_org_db
from ..core.tenant import get_current_user

router = APIRouter(prefix="/api/orgs/{org_id}/risk", tags=["risk"])

@router.get("")
async def get_risk(org_id: str, user: dict = Depends(get_current_user)):
    client = await get_client()
    core_db = get_core_db(client)
    membership = await core_db.memberships.find_one({"user_id": str(user["_id"]), "organization_id": org_id})
    if not membership: raise HTTPException(status_code=403, detail="Access denied")
    org = await core_db.organizations.find_one({"_id": ObjectId(org_id)})
    org_db = get_org_db(client, org["slug"])
    snapshot = await org_db.risk_snapshots.find_one(sort=[("calculated_at", -1)])
    if not snapshot:
        engine = RiskEngine()
        snapshot = await engine.calculate_risk(org_db, org_id)
    snapshot["_id"] = str(snapshot.get("_id", ""))
    return snapshot

@router.post("/recalculate")
async def recalculate(org_id: str, user: dict = Depends(get_current_user)):
    client = await get_client()
    core_db = get_core_db(client)
    membership = await core_db.memberships.find_one({"user_id": str(user["_id"]), "organization_id": org_id})
    if not membership: raise HTTPException(status_code=403, detail="Access denied")
    org = await core_db.organizations.find_one({"_id": ObjectId(org_id)})
    org_db = get_org_db(client, org["slug"])
    engine = RiskEngine()
    snapshot = await engine.calculate_risk(org_db, org_id)
    snapshot["_id"] = str(snapshot.get("_id", ""))
    return snapshot
