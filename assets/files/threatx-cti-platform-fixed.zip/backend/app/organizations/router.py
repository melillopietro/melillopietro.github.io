from fastapi import APIRouter, HTTPException, Depends
from typing import List
from bson import ObjectId
from .models import OrgCreate, OrgResponse
from .service import create_organization, get_user_organizations, select_organization
from ..core.database import get_client, get_core_db
from ..core.tenant import get_current_user

router = APIRouter(prefix="/api/orgs", tags=["organizations"])

@router.post("", response_model=OrgResponse)
async def create_org(org_data: OrgCreate, user: dict = Depends(get_current_user)):
    client = await get_client()
    core_db = get_core_db(client)
    org = await create_organization(core_db, client, org_data, str(user["_id"]))
    return OrgResponse(id=str(org["_id"]), name=org["name"], slug=org["slug"],
        description=org.get("description"), sector=org.get("sector"),
        country=org.get("country"), size=org.get("size"),
        primary_domain=org["primary_domain"],
        security_contacts=org.get("security_contacts", []),
        created_at=org["created_at"], is_active=True)

@router.get("", response_model=List[OrgResponse])
async def list_orgs(user: dict = Depends(get_current_user)):
    client = await get_client()
    core_db = get_core_db(client)
    orgs = await get_user_organizations(core_db, str(user["_id"]))
    return [OrgResponse(id=str(o["_id"]), name=o["name"], slug=o["slug"],
        description=o.get("description"), sector=o.get("sector"),
        country=o.get("country"), size=o.get("size"),
        primary_domain=o["primary_domain"],
        security_contacts=o.get("security_contacts", []),
        created_at=o["created_at"], is_active=True) for o in orgs]

@router.get("/{org_id}", response_model=OrgResponse)
async def get_org(org_id: str, user: dict = Depends(get_current_user)):
    client = await get_client()
    core_db = get_core_db(client)
    membership = await core_db.memberships.find_one({"user_id": str(user["_id"]), "organization_id": org_id})
    if not membership:
        raise HTTPException(status_code=403, detail="Access denied")
    org = await core_db.organizations.find_one({"_id": ObjectId(org_id)})
    if not org:
        raise HTTPException(status_code=404, detail="Organization not found")
    return OrgResponse(id=str(org["_id"]), name=org["name"], slug=org["slug"],
        description=org.get("description"), sector=org.get("sector"),
        country=org.get("country"), size=org.get("size"),
        primary_domain=org["primary_domain"],
        security_contacts=org.get("security_contacts", []),
        created_at=org["created_at"], is_active=True)

@router.post("/{org_id}/select")
async def select_org(org_id: str, user: dict = Depends(get_current_user)):
    client = await get_client()
    core_db = get_core_db(client)
    try:
        await select_organization(core_db, str(user["_id"]), org_id)
    except ValueError as e:
        raise HTTPException(status_code=403, detail=str(e))
    return {"message": "Organization selected", "organization_id": org_id}
