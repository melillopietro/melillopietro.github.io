from datetime import datetime
from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorDatabase
from bson import ObjectId
import re
from ..core.database import get_org_db, init_org_indexes
from ..core.logging import logger
from .models import OrgCreate

def generate_slug(name: str) -> str:
    slug = re.sub(r'[^a-z0-9]+', '-', name.lower()).strip('-')
    return slug[:50]

async def create_organization(core_db, client, org_data: OrgCreate, user_id: str) -> dict:
    slug = generate_slug(org_data.name)
    existing = await core_db.organizations.find_one({"slug": slug})
    if existing:
        slug = f"{slug}-{str(ObjectId())[:6]}"
    org_doc = {
        "name": org_data.name, "slug": slug, "description": org_data.description,
        "sector": org_data.sector.value if org_data.sector else None,
        "country": org_data.country,
        "size": org_data.size.value if org_data.size else None,
        "primary_domain": org_data.primary_domain,
        "security_contacts": org_data.security_contacts or [],
        "created_by": user_id, "is_active": True,
        "created_at": datetime.utcnow(), "updated_at": datetime.utcnow(),
    }
    result = await core_db.organizations.insert_one(org_doc)
    org_id = str(result.inserted_id)
    await core_db.memberships.insert_one({
        "user_id": user_id, "organization_id": org_id, "role": "admin", "joined_at": datetime.utcnow()
    })
    await core_db.users.update_one({"_id": ObjectId(user_id)}, {"$set": {"active_organization_id": org_id}})
    org_db = get_org_db(client, slug)
    await init_org_indexes(org_db)
    await org_db.organization_profile.insert_one({
        "organization_id": org_id, "name": org_data.name,
        "primary_domain": org_data.primary_domain,
        "domains": [org_data.primary_domain], "subdomains": [], "ips": [], "cidrs": [],
        "keywords": [], "brand_keywords": [], "executive_keywords": [],
        "technologies": [], "email_domains": [org_data.primary_domain],
        "scan_policy": {}, "api_sources": {}, "authorization_confirmed": False,
        "created_at": datetime.utcnow(),
    })
    org_doc["_id"] = result.inserted_id
    return org_doc

async def get_user_organizations(core_db, user_id: str) -> list:
    memberships = await core_db.memberships.find({"user_id": user_id}).to_list(100)
    org_ids = [ObjectId(m["organization_id"]) for m in memberships]
    orgs = await core_db.organizations.find({"_id": {"$in": org_ids}}).to_list(100)
    role_map = {m["organization_id"]: m["role"] for m in memberships}
    for org in orgs:
        org["user_role"] = role_map.get(str(org["_id"]), "read_only")
    return orgs

async def select_organization(core_db, user_id: str, org_id: str):
    membership = await core_db.memberships.find_one({"user_id": user_id, "organization_id": org_id})
    if not membership:
        raise ValueError("Not a member of this organization")
    await core_db.users.update_one({"_id": ObjectId(user_id)}, {"$set": {"active_organization_id": org_id}})
