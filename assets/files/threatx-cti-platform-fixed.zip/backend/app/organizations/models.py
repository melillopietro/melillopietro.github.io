from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime
from enum import Enum

class OrgSector(str, Enum):
    FINANCE = "finance"
    HEALTHCARE = "healthcare"
    TECHNOLOGY = "technology"
    GOVERNMENT = "government"
    ENERGY = "energy"
    RETAIL = "retail"
    MANUFACTURING = "manufacturing"
    EDUCATION = "education"
    TELECOM = "telecom"
    OTHER = "other"

class OrgSize(str, Enum):
    STARTUP = "startup"
    SMALL = "small"
    MEDIUM = "medium"
    LARGE = "large"
    ENTERPRISE = "enterprise"

class OrgCreate(BaseModel):
    name: str = Field(..., min_length=2, max_length=100)
    description: Optional[str] = None
    sector: Optional[OrgSector] = None
    country: Optional[str] = None
    size: Optional[OrgSize] = None
    primary_domain: str = Field(..., min_length=3)
    security_contacts: Optional[List[str]] = []

class OrgResponse(BaseModel):
    id: str
    name: str
    slug: str
    description: Optional[str] = None
    sector: Optional[str] = None
    country: Optional[str] = None
    size: Optional[str] = None
    primary_domain: str
    security_contacts: List[str] = []
    created_at: datetime
    is_active: bool = True
