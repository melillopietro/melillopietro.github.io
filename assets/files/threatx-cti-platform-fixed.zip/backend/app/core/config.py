"""ThreatX CTI Platform - Core Configuration"""
from pydantic_settings import BaseSettings
from typing import Optional
from functools import lru_cache

class Settings(BaseSettings):
    APP_NAME: str = "ThreatX CTI Platform"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False
    SECRET_KEY: str = "change-me-in-production-use-openssl-rand-hex-32"
    JWT_SECRET_KEY: str = "change-me-jwt-secret-key"
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRATION_MINUTES: int = 480
    MONGODB_URI: str = "mongodb://localhost:27017"
    CORE_DB_NAME: str = "cti_core"
    ORG_DB_PREFIX: str = "cti_org_"
    REDIS_URL: str = "redis://localhost:6379/0"
    ENCRYPTION_KEY: str = "change-me-encryption-key-32-chars!"
    RATE_LIMIT_PER_MINUTE: int = 60
    NMAP_ENABLED: bool = True
    NMAP_DEFAULT_ARGS: str = "-sV --version-light -T2 --top-ports 100"
    NMAP_TIMEOUT: int = 300
    NMAP_MAX_HOSTS: int = 10
    CORS_ORIGINS: str = "http://localhost:5173,http://localhost:3000"
    LOG_LEVEL: str = "INFO"
    class Config:
        env_file = ".env"
        case_sensitive = True

@lru_cache()
def get_settings() -> Settings:
    return Settings()
