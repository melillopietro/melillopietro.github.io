"""ThreatX CTI Platform - Database management"""
from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorDatabase
from typing import Optional
import re
from .config import get_settings

settings = get_settings()
_client: Optional[AsyncIOMotorClient] = None

async def get_client() -> AsyncIOMotorClient:
    global _client
    if _client is None:
        _client = AsyncIOMotorClient(settings.MONGODB_URI)
    return _client

async def close_client():
    global _client
    if _client:
        _client.close()
        _client = None

def get_core_db(client: AsyncIOMotorClient) -> AsyncIOMotorDatabase:
    return client[settings.CORE_DB_NAME]

def get_org_db(client: AsyncIOMotorClient, org_slug: str) -> AsyncIOMotorDatabase:
    safe_slug = sanitize_db_name(org_slug)
    return client[f"{settings.ORG_DB_PREFIX}{safe_slug}"]

def sanitize_db_name(name: str) -> str:
    safe = re.sub(r'[^a-z0-9_]', '_', name.lower())
    safe = re.sub(r'_+', '_', safe).strip('_')
    return safe[:50] if safe else "default"

async def init_core_indexes(db: AsyncIOMotorDatabase):
    await db.users.create_index("email", unique=True)
    await db.organizations.create_index("slug", unique=True)
    await db.memberships.create_index([("user_id", 1), ("organization_id", 1)], unique=True)
    await db.audit_logs.create_index([("timestamp", -1)])

async def init_org_indexes(db: AsyncIOMotorDatabase):
    await db.scan_jobs.create_index([("created_at", -1)])
    await db.assets_domains.create_index("domain", unique=True)
    await db.assets_subdomains.create_index("subdomain", unique=True)
    await db.assets_ips.create_index("ip", unique=True)
    await db.findings.create_index([("severity", -1), ("created_at", -1)])
    await db.findings.create_index([("source_name", 1)])
    await db.breaches.create_index([("email", 1)])
    await db.exposed_services.create_index([("ip", 1), ("port", 1)])
    await db.vulnerabilities.create_index([("cve_id", 1)])
    await db.alerts.create_index([("created_at", -1), ("read", 1)])
    await db.reports.create_index([("created_at", -1)])
