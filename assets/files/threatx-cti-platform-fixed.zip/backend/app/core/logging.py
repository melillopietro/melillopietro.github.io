"""ThreatX CTI Platform - Logging"""
import logging, sys
from .config import get_settings

settings = get_settings()

def setup_logging():
    log_level = getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(formatter)
    root_logger = logging.getLogger("threatx")
    root_logger.setLevel(log_level)
    root_logger.addHandler(handler)
    return root_logger

logger = setup_logging()
