"""ThreatX CTI Platform - Tenant management"""
from fastapi import Request, HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from motor.motor_asyncio import AsyncIOMotorDatabase
from .security import decode_access_token
from .database import get_client, get_core_db, get_org_db
from bson import ObjectId

security_scheme = HTTPBearer()

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security_scheme)):
    token = credentials.credentials
    payload = decode_access_token(token)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    user_id = payload.get("sub")
    if not user_id:
        raise HTTPException(status_code=401, detail="Invalid token payload")
    client = await get_client()
    core_db = get_core_db(client)
    user = await core_db.users.find_one({"_id": ObjectId(user_id)})
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    user["id"] = str(user["_id"])
    return user

async def get_active_org_db(request: Request, user: dict = Depends(get_current_user)) -> AsyncIOMotorDatabase:
    org_id = request.headers.get("X-Organization-ID") or user.get("active_organization_id")
    if not org_id:
        raise HTTPException(status_code=400, detail="No active organization selected")
    client = await get_client()
    core_db = get_core_db(client)
    membership = await core_db.memberships.find_one({"user_id": str(user["_id"]), "organization_id": org_id})
    if not membership:
        raise HTTPException(status_code=403, detail="Not a member of this organization")
    org = await core_db.organizations.find_one({"_id": ObjectId(org_id)})
    if not org:
        raise HTTPException(status_code=404, detail="Organization not found")
    return get_org_db(client, org["slug"])
