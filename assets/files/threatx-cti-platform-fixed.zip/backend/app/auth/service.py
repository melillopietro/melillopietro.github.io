from datetime import datetime
from motor.motor_asyncio import AsyncIOMotorDatabase
from ..core.security import hash_password, verify_password, create_access_token
from ..core.logging import logger
from .models import UserCreate, UserLogin

async def register_user(db: AsyncIOMotorDatabase, user_data: UserCreate) -> dict:
    existing = await db.users.find_one({"email": user_data.email})
    if existing:
        raise ValueError("Email already registered")
    user_doc = {
        "email": user_data.email,
        "full_name": user_data.full_name,
        "password_hash": hash_password(user_data.password),
        "is_active": True,
        "active_organization_id": None,
        "created_at": datetime.utcnow(),
        "updated_at": datetime.utcnow(),
    }
    result = await db.users.insert_one(user_doc)
    user_doc["_id"] = result.inserted_id
    logger.info(f"User registered: {user_data.email}")
    return user_doc

async def authenticate_user(db: AsyncIOMotorDatabase, login_data: UserLogin) -> dict:
    user = await db.users.find_one({"email": login_data.email})
    if not user or not verify_password(login_data.password, user["password_hash"]):
        raise ValueError("Invalid credentials")
    if not user.get("is_active", True):
        raise ValueError("Account disabled")
    token = create_access_token({"sub": str(user["_id"]), "email": user["email"]})
    return {"token": token, "user": user}
