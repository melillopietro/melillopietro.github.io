from fastapi import APIRouter, HTTPException, Depends
from .models import UserCreate, UserLogin, UserResponse, TokenResponse
from .service import register_user, authenticate_user
from ..core.database import get_client, get_core_db
from ..core.tenant import get_current_user
from ..core.security import create_access_token

router = APIRouter(prefix="/api/auth", tags=["auth"])

@router.post("/register", response_model=TokenResponse)
async def register(user_data: UserCreate):
    client = await get_client()
    db = get_core_db(client)
    try:
        user = await register_user(db, user_data)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    token = create_access_token({"sub": str(user["_id"]), "email": user["email"]})
    return TokenResponse(access_token=token, user=UserResponse(
        id=str(user["_id"]), email=user["email"], full_name=user["full_name"],
        active_organization_id=user.get("active_organization_id"),
        created_at=user["created_at"], is_active=True))

@router.post("/login", response_model=TokenResponse)
async def login(login_data: UserLogin):
    client = await get_client()
    db = get_core_db(client)
    try:
        result = await authenticate_user(db, login_data)
    except ValueError as e:
        raise HTTPException(status_code=401, detail=str(e))
    user = result["user"]
    return TokenResponse(access_token=result["token"], user=UserResponse(
        id=str(user["_id"]), email=user["email"], full_name=user["full_name"],
        active_organization_id=user.get("active_organization_id"),
        created_at=user["created_at"], is_active=user.get("is_active", True)))

@router.get("/me", response_model=UserResponse)
async def get_me(user: dict = Depends(get_current_user)):
    return UserResponse(id=str(user["_id"]), email=user["email"], full_name=user["full_name"],
        active_organization_id=user.get("active_organization_id"),
        created_at=user["created_at"], is_active=user.get("is_active", True))
