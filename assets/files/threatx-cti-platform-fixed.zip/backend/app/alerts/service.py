from datetime import datetime
from bson import ObjectId

class AlertService:
    async def create_alert(self, db, alert_data: dict) -> str:
        doc = {"title": alert_data.get("title"), "description": alert_data.get("description"),
            "severity": alert_data.get("severity", "medium"), "category": alert_data.get("category"),
            "source_name": alert_data.get("source_name"), "entity_type": alert_data.get("entity_type"),
            "entity_value": alert_data.get("entity_value"), "read": False, "status": "new", "created_at": datetime.utcnow()}
        result = await db.alerts.insert_one(doc)
        return str(result.inserted_id)

    async def get_alerts(self, db, limit=50, unread_only=False):
        query = {"read": False} if unread_only else {}
        alerts = await db.alerts.find(query).sort("created_at", -1).limit(limit).to_list(limit)
        for a in alerts: a["id"] = str(a.pop("_id"))
        return alerts

    async def mark_read(self, db, alert_id: str):
        await db.alerts.update_one({"_id": ObjectId(alert_id)}, {"$set": {"read": True, "read_at": datetime.utcnow()}})

    async def get_unread_count(self, db) -> int:
        return await db.alerts.count_documents({"read": False})
