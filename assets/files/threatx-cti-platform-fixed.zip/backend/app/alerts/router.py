from fastapi import APIRouter, HTTPException, Depends, Query
from bson import ObjectId
from .service import AlertService
from ..core.database import get_client, get_core_db, get_org_db
from ..core.tenant import get_current_user

router = APIRouter(prefix="/api/orgs/{org_id}/alerts", tags=["alerts"])

@router.get("")
async def list_alerts(org_id: str, unread_only: bool = Query(False), user: dict = Depends(get_current_user)):
    client = await get_client()
    core_db = get_core_db(client)
    membership = await core_db.memberships.find_one({"user_id": str(user["_id"]), "organization_id": org_id})
    if not membership: raise HTTPException(status_code=403, detail="Access denied")
    org = await core_db.organizations.find_one({"_id": ObjectId(org_id)})
    org_db = get_org_db(client, org["slug"])
    return await AlertService().get_alerts(org_db, unread_only=unread_only)

@router.post("/{alert_id}/read")
async def mark_read(org_id: str, alert_id: str, user: dict = Depends(get_current_user)):
    client = await get_client()
    core_db = get_core_db(client)
    membership = await core_db.memberships.find_one({"user_id": str(user["_id"]), "organization_id": org_id})
    if not membership: raise HTTPException(status_code=403, detail="Access denied")
    org = await core_db.organizations.find_one({"_id": ObjectId(org_id)})
    org_db = get_org_db(client, org["slug"])
    await AlertService().mark_read(org_db, alert_id)
    return {"message": "Alert marked as read"}

@router.get("/count")
async def count(org_id: str, user: dict = Depends(get_current_user)):
    client = await get_client()
    core_db = get_core_db(client)
    membership = await core_db.memberships.find_one({"user_id": str(user["_id"]), "organization_id": org_id})
    if not membership: raise HTTPException(status_code=403, detail="Access denied")
    org = await core_db.organizations.find_one({"_id": ObjectId(org_id)})
    org_db = get_org_db(client, org["slug"])
    return {"unread_count": await AlertService().get_unread_count(org_db)}
