from datetime import datetime

class AuditService:
    async def log(self, db, action: str, user_id: str, **kwargs):
        await db.audit_logs.insert_one({"action": action, "user_id": user_id, "timestamp": datetime.utcnow(), **kwargs})

    async def get_logs(self, db, limit=100, action=None):
        query = {"action": action} if action else {}
        logs = await db.audit_logs.find(query).sort("timestamp", -1).limit(limit).to_list(limit)
        for l in logs: l["id"] = str(l.pop("_id"))
        return logs
