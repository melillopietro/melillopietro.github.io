from fastapi import APIRouter, Depends, Query
from .service import AuditService
from ..core.database import get_client, get_core_db
from ..core.tenant import get_current_user

router = APIRouter(prefix="/api/audit", tags=["audit"])

@router.get("")
async def list_logs(limit: int = Query(50, le=200), action: str = None, user: dict = Depends(get_current_user)):
    client = await get_client()
    core_db = get_core_db(client)
    return await AuditService().get_logs(core_db, limit=limit, action=action)
