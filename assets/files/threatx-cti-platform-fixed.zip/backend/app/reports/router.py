from fastapi import APIRouter, HTTPException, Depends
from fastapi.responses import Response
from bson import ObjectId
from .generator import ReportGenerator
from ..core.database import get_client, get_core_db, get_org_db
from ..core.tenant import get_current_user

router = APIRouter(prefix="/api/orgs/{org_id}/reports", tags=["reports"])

@router.post("/generate")
async def generate_report(org_id: str, user: dict = Depends(get_current_user)):
    client = await get_client()
    core_db = get_core_db(client)
    membership = await core_db.memberships.find_one({"user_id": str(user["_id"]), "organization_id": org_id})
    if not membership: raise HTTPException(status_code=403, detail="Access denied")
    org = await core_db.organizations.find_one({"_id": ObjectId(org_id)})
    org_db = get_org_db(client, org["slug"])
    gen = ReportGenerator()
    return await gen.generate(org_db, org_id)

@router.get("")
async def list_reports(org_id: str, user: dict = Depends(get_current_user)):
    client = await get_client()
    core_db = get_core_db(client)
    membership = await core_db.memberships.find_one({"user_id": str(user["_id"]), "organization_id": org_id})
    if not membership: raise HTTPException(status_code=403, detail="Access denied")
    org = await core_db.organizations.find_one({"_id": ObjectId(org_id)})
    org_db = get_org_db(client, org["slug"])
    reports = await org_db.reports.find().sort("generated_at", -1).limit(50).to_list(50)
    return [{"id": str(r["_id"]), "title": r.get("title"), "generated_at": r.get("generated_at").isoformat() if r.get("generated_at") else None,
        "risk_score": r.get("risk_score"), "risk_level": r.get("risk_level"), "findings_count": r.get("findings_count")} for r in reports]

@router.get("/{report_id}/download")
async def download_report(org_id: str, report_id: str, user: dict = Depends(get_current_user)):
    client = await get_client()
    core_db = get_core_db(client)
    membership = await core_db.memberships.find_one({"user_id": str(user["_id"]), "organization_id": org_id})
    if not membership: raise HTTPException(status_code=403, detail="Access denied")
    org = await core_db.organizations.find_one({"_id": ObjectId(org_id)})
    org_db = get_org_db(client, org["slug"])
    rf = await org_db.report_files.find_one({"report_id": report_id})
    if not rf: raise HTTPException(status_code=404, detail="Report not found")
    return Response(content=rf["pdf_data"], media_type="application/pdf", headers={"Content-Disposition": f"attachment; filename=cti_report_{report_id}.pdf"})
