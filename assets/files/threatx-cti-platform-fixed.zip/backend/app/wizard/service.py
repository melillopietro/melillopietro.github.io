from datetime import datetime
from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorDatabase
from bson import ObjectId
from ..core.security import encrypt_api_key
from ..core.database import get_org_db
from ..core.logging import logger
from ..organizations.service import create_organization
from ..organizations.models import OrgCreate
from .schemas import WizardComplete
import httpx


async def complete_wizard(core_db, client, wizard_data: WizardComplete, user_id: str) -> dict:
    # Convert empty strings to None for enum fields
    sector_val = wizard_data.step1.sector if wizard_data.step1.sector else None
    size_val = wizard_data.step1.size if wizard_data.step1.size else None
    country_val = wizard_data.step1.country if wizard_data.step1.country else None

    org_data = OrgCreate(
        name=wizard_data.step1.name,
        description=wizard_data.step1.description or None,
        sector=sector_val,
        country=country_val,
        size=size_val,
        primary_domain=wizard_data.step1.primary_domain,
        security_contacts=wizard_data.step1.security_contacts or []
    )
    org = await create_organization(core_db, client, org_data, user_id)
    org_id = str(org["_id"])
    org_db = get_org_db(client, org["slug"])

    # Set domains - use primary domain as fallback
    domains = wizard_data.step2.domains if wizard_data.step2.domains else [wizard_data.step1.primary_domain]

    await org_db.organization_profile.update_one(
        {"organization_id": org_id},
        {"$set": {
            "domains": domains,
            "subdomains": wizard_data.step2.subdomains,
            "ips": wizard_data.step2.ips,
            "cidrs": wizard_data.step2.cidrs,
            "keywords": wizard_data.step2.keywords,
            "brand_keywords": wizard_data.step2.brand_keywords,
            "executive_keywords": wizard_data.step2.executive_keywords,
            "technologies": wizard_data.step2.technologies,
            "email_domains": wizard_data.step2.email_domains or [wizard_data.step1.primary_domain],
        }}
    )

    # Handle API sources - encrypt keys if provided
    api_sources = {}
    source_configs = [
        ("hibp", wizard_data.step3.hibp_api_key, wizard_data.step3.hibp_enabled),
        ("shodan", wizard_data.step3.shodan_api_key, wizard_data.step3.shodan_enabled),
        ("intelx", wizard_data.step3.intelx_api_key, wizard_data.step3.intelx_enabled),
    ]
    for src_name, api_key, enabled in source_configs:
        if api_key and enabled:
            api_sources[src_name] = {
                "enabled": True,
                "api_key_encrypted": encrypt_api_key(api_key),
                "status": "configured",
                "configured_at": datetime.utcnow()
            }
        else:
            api_sources[src_name] = {"enabled": enabled, "status": "not_configured"}

    scan_policy = {
        "scan_type": wizard_data.step5.scan_type.value,
        "nmap_enabled": wizard_data.step5.nmap_enabled,
        "shodan_enabled": wizard_data.step5.shodan_enabled,
        "hibp_enabled": wizard_data.step5.hibp_enabled,
        "intelx_enabled": wizard_data.step5.intelx_enabled,
        "scan_frequency": wizard_data.step5.scan_frequency,
        "authorization_confirmed": wizard_data.step5.authorization_confirmed,
    }

    await org_db.organization_profile.update_one(
        {"organization_id": org_id},
        {"$set": {
            "api_sources": api_sources,
            "scan_policy": scan_policy,
            "authorization_confirmed": wizard_data.step5.authorization_confirmed,
        }}
    )

    # Insert domain assets
    for domain in domains:
        await org_db.assets_domains.update_one(
            {"domain": domain},
            {"$setOnInsert": {
                "domain": domain, "organization_id": org_id,
                "source_name": "manual", "source_type": "manual",
                "added_at": datetime.utcnow(), "status": "active"
            }},
            upsert=True
        )

    # Insert IP assets
    for ip in wizard_data.step2.ips:
        await org_db.assets_ips.update_one(
            {"ip": ip},
            {"$setOnInsert": {
                "ip": ip, "organization_id": org_id,
                "source_name": "manual", "source_type": "manual",
                "added_at": datetime.utcnow(), "status": "active"
            }},
            upsert=True
        )

    logger.info(f"Wizard completed for org '{org_data.name}' (id={org_id}) by user {user_id}")

    return {
        "organization_id": org_id,
        "slug": org["slug"],
        "message": "Organization configured successfully",
        "start_scan": wizard_data.start_scan,
    }


async def test_api_key(source_name: str, api_key: str) -> dict:
    try:
        async with httpx.AsyncClient(timeout=10) as http_client:
            if source_name == "hibp":
                resp = await http_client.get(
                    "https://haveibeenpwned.com/api/v3/subscription/status",
                    headers={"hibp-api-key": api_key}
                )
                return {"status": "ok" if resp.status_code == 200 else "invalid", "message": f"HTTP {resp.status_code}"}
            elif source_name == "shodan":
                resp = await http_client.get(f"https://api.shodan.io/api-info?key={api_key}")
                return {"status": "ok" if resp.status_code == 200 else "invalid", "message": f"HTTP {resp.status_code}"}
            elif source_name == "intelx":
                resp = await http_client.get(
                    "https://2.intelx.io/authenticate/info",
                    headers={"x-key": api_key}
                )
                return {"status": "ok" if resp.status_code == 200 else "invalid", "message": f"HTTP {resp.status_code}"}
        return {"status": "unknown", "message": f"Unknown source: {source_name}"}
    except Exception as e:
        return {"status": "error", "message": str(e)}
