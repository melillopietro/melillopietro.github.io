from pydantic import BaseModel, Field
from typing import Optional, List
from enum import Enum

class WizardStep1(BaseModel):
    name: str = Field(..., min_length=2, max_length=100)
    description: Optional[str] = ""
    sector: Optional[str] = ""
    country: Optional[str] = ""
    size: Optional[str] = ""
    primary_domain: str = Field(..., min_length=3)
    security_contacts: List[str] = []

class WizardStep2(BaseModel):
    domains: List[str] = []
    subdomains: List[str] = []
    ips: List[str] = []
    cidrs: List[str] = []
    keywords: List[str] = []
    brand_keywords: List[str] = []
    executive_keywords: List[str] = []
    technologies: List[str] = []
    email_domains: List[str] = []
    authorization_notes: Optional[str] = ""

class WizardStep3(BaseModel):
    hibp_api_key: Optional[str] = None
    shodan_api_key: Optional[str] = None
    intelx_api_key: Optional[str] = None
    hibp_enabled: bool = True
    shodan_enabled: bool = True
    intelx_enabled: bool = True

class WizardStep4(BaseModel):
    additional_users: List[dict] = []

class ScanPolicyType(str, Enum):
    LIGHT = "light"
    DEEP = "deep"

class WizardStep5(BaseModel):
    scan_type: ScanPolicyType = ScanPolicyType.LIGHT
    nmap_enabled: bool = False
    shodan_enabled: bool = True
    hibp_enabled: bool = True
    intelx_enabled: bool = True
    scan_frequency: str = "manual"
    authorization_confirmed: bool = False

class WizardComplete(BaseModel):
    step1: WizardStep1
    step2: WizardStep2 = WizardStep2()
    step3: WizardStep3 = WizardStep3()
    step4: WizardStep4 = WizardStep4()
    step5: WizardStep5 = WizardStep5()
    start_scan: bool = False

class ApiKeyTest(BaseModel):
    source_name: str
    api_key: str
