"""ThreatX CTI Platform - Main Application"""
from fastapi import FastAPI, Request, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
from bson import ObjectId
from bson.errors import InvalidId
import time

from .core.config import get_settings
from .core.database import get_client, close_client, get_core_db, get_org_db, init_core_indexes
from .core.logging import logger
from .core.tenant import get_current_user
from .sources.registry import init_sources

from .auth.router import router as auth_router
from .organizations.router import router as orgs_router
from .wizard.router import router as wizard_router
from .scans.router import router as scans_router
from .risk.router import router as risk_router
from .search.router import router as search_router
from .reports.router import router as reports_router
from .alerts.router import router as alerts_router
from .audit.router import router as audit_router

settings = get_settings()

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info(f"Starting {settings.APP_NAME} v{settings.APP_VERSION}")
    client = await get_client()
    await init_core_indexes(get_core_db(client))
    init_sources()
    logger.info("Application started")
    yield
    await close_client()

app = FastAPI(title=settings.APP_NAME, version=settings.APP_VERSION,
    description="Cyber Threat Intelligence & Attack Surface Intelligence Platform", lifespan=lifespan)

app.add_middleware(CORSMiddleware, allow_origins=[o.strip() for o in settings.CORS_ORIGINS.split(",")],
    allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

@app.middleware("http")
async def timing(request: Request, call_next):
    start = time.time()
    response = await call_next(request)
    response.headers["X-Process-Time"] = f"{time.time()-start:.4f}"
    return response

app.include_router(auth_router)
app.include_router(orgs_router)
app.include_router(wizard_router)
app.include_router(scans_router)
app.include_router(risk_router)
app.include_router(search_router)
app.include_router(reports_router)
app.include_router(alerts_router)
app.include_router(audit_router)

@app.get("/api/health")
async def health():
    return {"status": "healthy", "app": settings.APP_NAME, "version": settings.APP_VERSION}

@app.get("/api/orgs/{org_id}/dashboard")
async def get_dashboard(org_id: str, user: dict = Depends(get_current_user)):
    # Validate org_id format
    try:
        oid = ObjectId(org_id)
    except (InvalidId, Exception):
        raise HTTPException(status_code=400, detail="Invalid organization ID")

    client = await get_client()
    core_db = get_core_db(client)

    # Verify membership
    membership = await core_db.memberships.find_one({
        "user_id": str(user["_id"]),
        "organization_id": org_id
    })
    if not membership:
        raise HTTPException(status_code=403, detail="Not a member of this organization")

    org = await core_db.organizations.find_one({"_id": oid})
    if not org:
        raise HTTPException(status_code=404, detail="Organization not found")

    org_db = get_org_db(client, org["slug"])

    # Get risk snapshot
    risk = await org_db.risk_snapshots.find_one(sort=[("calculated_at", -1)])

    # Build stats safely
    stats = {
        "risk_score": risk.get("final_score", 0) if risk else 0,
        "risk_level": risk.get("risk_level", "Low") if risk else "Low",
        "category_scores": risk.get("category_scores", {}) if risk else {},
        "assets": {
            "domains": await org_db.assets_domains.count_documents({}),
            "subdomains": await org_db.assets_subdomains.count_documents({}),
            "ips": await org_db.assets_ips.count_documents({}),
        },
        "findings": {
            "services": await org_db.exposed_services.count_documents({"status": "open"}),
            "vulnerabilities": await org_db.vulnerabilities.count_documents({"status": "open"}),
            "breaches": await org_db.breaches.count_documents({"status": "open"}),
            "mentions": await org_db.intelligence_mentions.count_documents({"status": "open"}),
        },
        "source_distribution": risk.get("source_distribution", {}) if risk else {},
        "recommended_actions": risk.get("recommended_actions", []) if risk else [],
        "alerts_unread": await org_db.alerts.count_documents({"read": False}),
    }
    stats["findings"]["total"] = sum(stats["findings"].values())

    # Latest scan
    latest = await org_db.scan_jobs.find_one(sort=[("created_at", -1)])
    stats["latest_scan"] = {
        "id": str(latest["_id"]),
        "status": latest["status"],
        "progress": latest.get("progress", 0),
        "created_at": latest["created_at"].isoformat()
    } if latest else None

    # Risk trend
    history = await org_db.risk_snapshots.find().sort("calculated_at", -1).limit(10).to_list(10)
    stats["risk_trend"] = [{"score": r.get("final_score", 0), "date": r["calculated_at"].isoformat()} for r in reversed(history)]

    # Recent findings
    recent_svcs = await org_db.exposed_services.find({"status": "open"}).sort("collected_at", -1).limit(5).to_list(5)
    recent_vulns = await org_db.vulnerabilities.find({"status": "open"}).sort("collected_at", -1).limit(5).to_list(5)
    stats["recent_findings"] = {
        "services": [{"ip": s.get("ip"), "port": s.get("port"), "product": s.get("product"), "source": s.get("source_name")} for s in recent_svcs],
        "vulnerabilities": [{"cve_id": v.get("cve_id"), "ip": v.get("ip"), "cvss": v.get("cvss")} for v in recent_vulns],
    }
    return stats


@app.get("/api/orgs/{org_id}/settings")
async def get_org_settings(org_id: str, user: dict = Depends(get_current_user)):
    try:
        oid = ObjectId(org_id)
    except (InvalidId, Exception):
        raise HTTPException(status_code=400, detail="Invalid organization ID")

    client = await get_client()
    core_db = get_core_db(client)

    # Verify membership
    membership = await core_db.memberships.find_one({
        "user_id": str(user["_id"]),
        "organization_id": org_id
    })
    if not membership:
        raise HTTPException(status_code=403, detail="Not a member of this organization")

    org = await core_db.organizations.find_one({"_id": oid})
    if not org:
        raise HTTPException(status_code=404, detail="Organization not found")

    org_db = get_org_db(client, org["slug"])
    profile = await org_db.organization_profile.find_one({"organization_id": org_id})
    if profile:
        safe_sources = {}
        for name, cfg in profile.get("api_sources", {}).items():
            safe_sources[name] = {"enabled": cfg.get("enabled"), "status": cfg.get("status")}
        profile["api_sources"] = safe_sources
        profile.pop("_id", None)
    return profile or {}
