const API_URL = import.meta.env.VITE_API_URL || ''

interface RequestOptions {
  method?: string
  body?: any
  headers?: Record<string, string>
}

class ApiClient {
  private token: string | null = null

  setToken(token: string | null) {
    this.token = token
    if (token) localStorage.setItem('token', token)
    else localStorage.removeItem('token')
  }

  getToken(): string | null {
    if (!this.token) this.token = localStorage.getItem('token')
    return this.token
  }

  private getOrgId(): string | null {
    return localStorage.getItem('active_org_id')
  }

  async request<T>(endpoint: string, options: RequestOptions = {}): Promise<T> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...options.headers,
    }
    const token = this.getToken()
    if (token) headers['Authorization'] = `Bearer ${token}`
    const orgId = this.getOrgId()
    if (orgId) headers['X-Organization-ID'] = orgId

    let response: Response
    try {
      response = await fetch(`${API_URL}${endpoint}`, {
        method: options.method || 'GET',
        headers,
        body: options.body ? JSON.stringify(options.body) : undefined,
      })
    } catch (networkError) {
      throw new Error('Network error: unable to connect to server')
    }

    if (response.status === 401) {
      this.setToken(null)
      localStorage.removeItem('active_org_id')
      // Only redirect if we're not already on auth pages
      if (!window.location.pathname.startsWith('/login') && !window.location.pathname.startsWith('/register')) {
        window.location.href = '/login'
      }
      throw new Error('Session expired. Please sign in again.')
    }

    if (!response.ok) {
      let errorMessage = 'Request failed'
      try {
        const errorBody = await response.json()
        errorMessage = errorBody.detail || errorBody.message || `Error ${response.status}`
      } catch {
        errorMessage = `Server error (${response.status})`
      }
      throw new Error(errorMessage)
    }

    // Handle empty responses (204 No Content, etc.)
    const contentType = response.headers.get('content-type')
    if (response.status === 204 || !contentType || !contentType.includes('application/json')) {
      const text = await response.text()
      if (!text) return {} as T
      try {
        return JSON.parse(text) as T
      } catch {
        return {} as T
      }
    }

    return response.json()
  }

  get<T>(endpoint: string) { return this.request<T>(endpoint) }
  post<T>(endpoint: string, body?: any) { return this.request<T>(endpoint, { method: 'POST', body }) }
  put<T>(endpoint: string, body?: any) { return this.request<T>(endpoint, { method: 'PUT', body }) }
  delete<T>(endpoint: string) { return this.request<T>(endpoint, { method: 'DELETE' }) }
}

export const api = new ApiClient()
