import { useState, useEffect } from 'react'
import { api } from '../api/client'

interface Report { id: string; title: string; generated_at: string; risk_score: number; risk_level: string; findings_count: number }

export default function ReportsPage() {
  const [reports, setReports] = useState<Report[]>([])
  const [generating, setGenerating] = useState(false)
  const orgId = localStorage.getItem('active_org_id')

  useEffect(() => {
    if (orgId) api.get<Report[]>(`/api/orgs/${orgId}/reports`).then(setReports).catch(console.error)
  }, [orgId])

  const generate = async () => {
    if (!orgId) return
    setGenerating(true)
    try {
      await api.post(`/api/orgs/${orgId}/reports/generate`)
      const updated = await api.get<Report[]>(`/api/orgs/${orgId}/reports`)
      setReports(updated)
    } catch (err: any) { alert(err.message) }
    finally { setGenerating(false) }
  }

  const download = (reportId: string) => {
    const token = localStorage.getItem('token')
    window.open(`/api/orgs/${orgId}/reports/${reportId}/download?token=${token}`, '_blank')
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Reports</h1>
        <button onClick={generate} disabled={generating} className="btn-primary">{generating ? 'Generating...' : 'Generate Report'}</button>
      </div>
      {reports.length === 0 ? (
        <div className="card text-center py-12"><p className="text-gray-600">No reports generated yet</p></div>
      ) : (
        <div className="space-y-3">
          {reports.map(r => (
            <div key={r.id} className="card flex items-center justify-between">
              <div>
                <h3 className="font-medium text-gray-200">{r.title}</h3>
                <div className="flex items-center gap-4 mt-1 text-sm text-gray-500">
                  <span>{r.generated_at?.split('T')[0]}</span>
                  <span className={`badge ${r.risk_level === 'Critical' ? 'badge-critical' : r.risk_level === 'High' ? 'badge-high' : r.risk_level === 'Medium' ? 'badge-medium' : 'badge-low'}`}>{r.risk_level} ({r.risk_score})</span>
                  <span>{r.findings_count} findings</span>
                </div>
              </div>
              <button onClick={() => download(r.id)} className="btn-secondary text-sm">Download PDF</button>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
