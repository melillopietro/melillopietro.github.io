import { useState, useEffect } from 'react'
import { api } from '../api/client'

export default function AssetsPage() {
  const [tab, setTab] = useState<'domains'|'subdomains'|'ips'>('domains')
  const [data, setData] = useState<any>(null)
  const orgId = localStorage.getItem('active_org_id')

  useEffect(() => {
    if (orgId) api.get(`/api/orgs/${orgId}/dashboard`).then((d: any) => setData(d)).catch(console.error)
  }, [orgId])

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Assets</h1>
      <div className="flex gap-2">
        {(['domains','subdomains','ips'] as const).map(t => (
          <button key={t} onClick={() => setTab(t)} className={`px-4 py-2 rounded-lg text-sm ${tab === t ? 'bg-indigo-600 text-white' : 'bg-navy-800 text-gray-400'}`}>
            {t.charAt(0).toUpperCase() + t.slice(1)} ({data?.assets?.[t] || 0})
          </button>
        ))}
      </div>
      <div className="card">
        <p className="text-gray-500 text-sm">Asset details are populated after running a scan. {data?.assets?.[tab] || 0} {tab} discovered.</p>
        {!data?.assets?.[tab] && (
          <div className="text-center py-12">
            <p className="text-gray-600">No {tab} discovered yet</p>
            <p className="text-gray-700 text-sm mt-1">Run a scan to discover assets</p>
          </div>
        )}
      </div>
    </div>
  )
}
