import { useState, useEffect } from 'react'
import { api } from '../api/client'

export default function SettingsPage() {
  const [settings, setSettings] = useState<any>(null)
  const orgId = localStorage.getItem('active_org_id')

  useEffect(() => {
    if (orgId) api.get(`/api/orgs/${orgId}/settings`).then(setSettings).catch(console.error)
  }, [orgId])

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Settings</h1>
      {settings ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="card">
            <h2 className="text-lg font-medium mb-4">Organization Profile</h2>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between"><span className="text-gray-500">Name</span><span className="text-gray-200">{settings.name}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">Primary Domain</span><span className="text-gray-200">{settings.primary_domain}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">Domains</span><span className="text-gray-200">{settings.domains?.length || 0}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">IPs</span><span className="text-gray-200">{settings.ips?.length || 0}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">Authorization</span>
                <span className={settings.authorization_confirmed ? 'text-emerald-400' : 'text-red-400'}>{settings.authorization_confirmed ? 'Confirmed' : 'Pending'}</span></div>
            </div>
          </div>
          <div className="card">
            <h2 className="text-lg font-medium mb-4">API Sources</h2>
            <div className="space-y-3">
              {Object.entries(settings.api_sources || {}).map(([name, cfg]: [string, any]) => (
                <div key={name} className="flex items-center justify-between bg-navy-800/50 rounded-lg px-4 py-3">
                  <span className="text-gray-200 font-medium capitalize">{name}</span>
                  <div className="flex items-center gap-2">
                    <span className={`badge ${cfg.status === 'configured' ? 'badge-low' : 'badge-high'}`}>{cfg.status}</span>
                    <span className={`w-2 h-2 rounded-full ${cfg.enabled ? 'bg-emerald-400' : 'bg-gray-600'}`} />
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="card">
            <h2 className="text-lg font-medium mb-4">Scan Policy</h2>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between"><span className="text-gray-500">Scan Type</span><span className="text-gray-200">{settings.scan_policy?.scan_type}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">Nmap</span><span className={settings.scan_policy?.nmap_enabled ? 'text-emerald-400' : 'text-gray-600'}>{settings.scan_policy?.nmap_enabled ? 'Enabled' : 'Disabled'}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">Frequency</span><span className="text-gray-200">{settings.scan_policy?.scan_frequency}</span></div>
            </div>
          </div>
        </div>
      ) : (
        <div className="card text-center py-12"><p className="text-gray-600">No organization configured</p></div>
      )}
    </div>
  )
}
