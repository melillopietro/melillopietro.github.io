import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { api } from '../api/client'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'

interface DashboardData {
  risk_score: number
  risk_level: string
  category_scores: Record<string, number>
  assets: { domains: number; subdomains: number; ips: number }
  findings: { total: number; services: number; vulnerabilities: number; breaches: number; mentions: number }
  source_distribution: Record<string, number>
  recommended_actions: string[]
  alerts_unread: number
  latest_scan: { id: string; status: string; progress: number; created_at: string } | null
  risk_trend: { score: number; date: string }[]
  recent_findings: { services: any[]; vulnerabilities: any[] }
}

const RISK_COLORS: Record<string, string> = { Low: '#10b981', Medium: '#f59e0b', High: '#f97316', Critical: '#ef4444' }
const PIE_COLORS = ['#6366f1', '#8b5cf6', '#06b6d4', '#10b981', '#f59e0b', '#ef4444']

export default function DashboardPage() {
  const [data, setData] = useState<DashboardData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const navigate = useNavigate()

  useEffect(() => {
    const orgId = localStorage.getItem('active_org_id')
    if (!orgId) {
      setLoading(false)
      return
    }
    api.get<DashboardData>(`/api/orgs/${orgId}/dashboard`)
      .then(setData)
      .catch(err => {
        console.error('Dashboard load error:', err)
        setError(err.message || 'Failed to load dashboard data')
      })
      .finally(() => setLoading(false))
  }, [])

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500" /></div>

  if (!localStorage.getItem('active_org_id')) {
    return (
      <div className="text-center py-20">
        <h2 className="text-2xl font-bold mb-2">No Organization Selected</h2>
        <p className="text-gray-500 mb-4">Complete the setup wizard to get started</p>
        <button onClick={() => navigate('/wizard')} className="btn-primary">Setup Wizard</button>
      </div>
    )
  }

  if (error) {
    return (
      <div className="text-center py-20">
        <h2 className="text-2xl font-bold mb-2 text-red-400">Unable to Load Dashboard</h2>
        <p className="text-gray-500 mb-4">{error}</p>
        <div className="flex gap-3 justify-center">
          <button onClick={() => window.location.reload()} className="btn-primary">Retry</button>
          <button onClick={() => navigate('/wizard')} className="btn-secondary">Setup Wizard</button>
        </div>
      </div>
    )
  }

  if (!data) {
    return (
      <div className="text-center py-20">
        <h2 className="text-2xl font-bold mb-2">Welcome to ThreatX</h2>
        <p className="text-gray-500 mb-4">Your organization is set up. Run your first scan to populate the dashboard.</p>
        <button onClick={() => navigate('/scans')} className="btn-primary">Go to Scans</button>
      </div>
    )
  }

  const riskColor = RISK_COLORS[data.risk_level] || '#6366f1'
  const sourceData = Object.entries(data.source_distribution).map(([name, value]) => ({ name, value }))

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Threat Intelligence Dashboard</h1>
        {data.latest_scan && (
          <span className={`badge ${data.latest_scan.status === 'completed' ? 'badge-low' : data.latest_scan.status === 'running' ? 'badge-medium' : 'badge-high'}`}>
            Scan: {data.latest_scan.status} {data.latest_scan.status === 'running' && `(${data.latest_scan.progress}%)`}
          </span>
        )}
      </div>

      {/* Risk Score + Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="card flex flex-col items-center justify-center py-8">
          <div className="relative w-28 h-28">
            <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
              <circle cx="50" cy="50" r="42" fill="none" stroke="#1e1b4b" strokeWidth="8" />
              <circle cx="50" cy="50" r="42" fill="none" stroke={riskColor} strokeWidth="8"
                strokeDasharray={`${data.risk_score * 2.64} 264`} strokeLinecap="round" />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-3xl font-bold" style={{ color: riskColor }}>{data.risk_score}</span>
              <span className="text-xs text-gray-500">/ 100</span>
            </div>
          </div>
          <span className="mt-2 text-sm font-medium" style={{ color: riskColor }}>{data.risk_level} Risk</span>
        </div>

        <div className="card">
          <h3 className="text-sm text-gray-500 mb-3">Assets Discovered</h3>
          <div className="space-y-2">
            <div className="flex justify-between"><span className="text-gray-400">Domains</span><span className="font-bold">{data.assets.domains}</span></div>
            <div className="flex justify-between"><span className="text-gray-400">Subdomains</span><span className="font-bold">{data.assets.subdomains}</span></div>
            <div className="flex justify-between"><span className="text-gray-400">IPs</span><span className="font-bold">{data.assets.ips}</span></div>
          </div>
        </div>

        <div className="card">
          <h3 className="text-sm text-gray-500 mb-3">Findings</h3>
          <div className="space-y-2">
            <div className="flex justify-between"><span className="text-gray-400">Services</span><span className="font-bold text-orange-400">{data.findings.services}</span></div>
            <div className="flex justify-between"><span className="text-gray-400">Vulnerabilities</span><span className="font-bold text-red-400">{data.findings.vulnerabilities}</span></div>
            <div className="flex justify-between"><span className="text-gray-400">Breaches</span><span className="font-bold text-amber-400">{data.findings.breaches}</span></div>
            <div className="flex justify-between"><span className="text-gray-400">Intel Mentions</span><span className="font-bold text-purple-400">{data.findings.mentions}</span></div>
          </div>
        </div>

        <div className="card">
          <h3 className="text-sm text-gray-500 mb-3">Status</h3>
          <div className="space-y-2">
            <div className="flex justify-between"><span className="text-gray-400">Total Findings</span><span className="font-bold">{data.findings.total}</span></div>
            <div className="flex justify-between"><span className="text-gray-400">Unread Alerts</span><span className="font-bold text-amber-400">{data.alerts_unread}</span></div>
            <div className="flex justify-between"><span className="text-gray-400">Last Scan</span><span className="text-xs text-gray-400">{data.latest_scan?.created_at?.split('T')[0] || 'Never'}</span></div>
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card">
          <h3 className="text-sm font-medium text-gray-400 mb-4">Risk Trend</h3>
          {data.risk_trend.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={data.risk_trend}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e1b4b" />
                <XAxis dataKey="date" tick={{ fill: '#6b7280', fontSize: 10 }} tickFormatter={v => v.split('T')[0]?.slice(5)} />
                <YAxis domain={[0, 100]} tick={{ fill: '#6b7280', fontSize: 10 }} />
                <Tooltip contentStyle={{ backgroundColor: '#0f0d2e', border: '1px solid #374151' }} />
                <Line type="monotone" dataKey="score" stroke="#6366f1" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          ) : <p className="text-gray-600 text-sm text-center py-8">No risk history yet — run a scan first</p>}
        </div>

        <div className="card">
          <h3 className="text-sm font-medium text-gray-400 mb-4">Source Distribution</h3>
          {sourceData.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={sourceData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={70} label={({ name, value }) => `${name}: ${value}`}>
                  {sourceData.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: '#0f0d2e', border: '1px solid #374151' }} />
              </PieChart>
            </ResponsiveContainer>
          ) : <p className="text-gray-500 text-center py-8">No data yet — run a scan first</p>}
        </div>
      </div>

      {/* Recommendations */}
      {data.recommended_actions.length > 0 && (
        <div className="card">
          <h3 className="text-sm font-medium text-gray-400 mb-3">Recommended Actions</h3>
          <ul className="space-y-2">
            {data.recommended_actions.map((action, i) => (
              <li key={i} className="flex items-start gap-2 text-sm">
                <span className="text-indigo-400 mt-0.5">●</span>
                <span className="text-gray-300">{action}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Recent Findings */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card">
          <h3 className="text-sm font-medium text-gray-400 mb-3">Recent Exposed Services</h3>
          <div className="space-y-2">
            {data.recent_findings.services.length > 0 ? data.recent_findings.services.map((s, i) => (
              <div key={i} className="flex items-center justify-between text-sm bg-navy-800/50 rounded-lg px-3 py-2">
                <span className="text-gray-300 font-mono">{s.ip}:{s.port}</span>
                <span className="text-gray-500">{s.product || 'Unknown'}</span>
                <span className="badge badge-medium">{s.source}</span>
              </div>
            )) : <p className="text-gray-600 text-sm">No exposed services found yet</p>}
          </div>
        </div>

        <div className="card">
          <h3 className="text-sm font-medium text-gray-400 mb-3">Recent Vulnerabilities</h3>
          <div className="space-y-2">
            {data.recent_findings.vulnerabilities.length > 0 ? data.recent_findings.vulnerabilities.map((v, i) => (
              <div key={i} className="flex items-center justify-between text-sm bg-navy-800/50 rounded-lg px-3 py-2">
                <span className="text-red-400 font-mono">{v.cve_id}</span>
                <span className="text-gray-500">{v.ip}</span>
                <span className="badge badge-critical">CVSS {v.cvss || 'N/A'}</span>
              </div>
            )) : <p className="text-gray-600 text-sm">No vulnerabilities found yet</p>}
          </div>
        </div>
      </div>
    </div>
  )
}
