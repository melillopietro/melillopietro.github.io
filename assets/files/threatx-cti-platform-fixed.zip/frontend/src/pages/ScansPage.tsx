import { useState, useEffect } from 'react'
import { api } from '../api/client'

interface Scan { id: string; scan_type: string; status: string; steps: any[]; created_at: string; completed_at: string|null; total_findings: number; progress: number }

export default function ScansPage() {
  const [scans, setScans] = useState<Scan[]>([])
  const [loading, setLoading] = useState(false)
  const orgId = localStorage.getItem('active_org_id')

  const loadScans = () => {
    if (orgId) api.get<Scan[]>(`/api/orgs/${orgId}/scans`).then(setScans).catch(console.error)
  }
  useEffect(loadScans, [orgId])

  const startScan = async () => {
    if (!orgId) return
    setLoading(true)
    try {
      await api.post(`/api/orgs/${orgId}/scans/start`)
      setTimeout(loadScans, 1000)
    } catch (err: any) { alert(err.message) }
    finally { setLoading(false) }
  }

  const statusColor = (s: string) => s === 'completed' ? 'badge-low' : s === 'running' ? 'badge-medium' : s === 'failed' ? 'badge-critical' : 'badge-high'

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Scans</h1>
        <button onClick={startScan} disabled={loading} className="btn-primary">{loading ? 'Starting...' : 'Start New Scan'}</button>
      </div>
      <div className="space-y-3">
        {scans.length === 0 && <div className="card text-center py-12"><p className="text-gray-600">No scans yet. Start your first scan to gather intelligence.</p></div>}
        {scans.map(scan => (
          <div key={scan.id} className="card">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <span className={`badge ${statusColor(scan.status)}`}>{scan.status}</span>
                <span className="text-sm text-gray-400">{scan.scan_type} scan</span>
              </div>
              <span className="text-xs text-gray-500">{scan.created_at?.split('T')[0]}</span>
            </div>
            {scan.status === 'running' && (
              <div className="w-full bg-navy-800 rounded-full h-2 mb-3">
                <div className="bg-indigo-600 h-2 rounded-full transition-all" style={{ width: `${scan.progress}%` }} />
              </div>
            )}
            <div className="flex items-center gap-4 text-sm text-gray-500">
              <span>Findings: {scan.total_findings}</span>
              <span>Steps: {scan.steps?.filter((s:any) => s.status === 'completed').length}/{scan.steps?.length}</span>
            </div>
            {scan.steps && scan.steps.length > 0 && (
              <div className="mt-3 grid grid-cols-2 md:grid-cols-4 gap-2">
                {scan.steps.map((s: any, i: number) => (
                  <div key={i} className="text-xs bg-navy-800/50 rounded px-2 py-1">
                    <span className={s.status === 'completed' ? 'text-emerald-400' : s.status === 'running' ? 'text-amber-400' : s.status === 'failed' ? 'text-red-400' : 'text-gray-600'}>
                      {s.status === 'completed' ? '✓' : s.status === 'running' ? '⟳' : s.status === 'failed' ? '✗' : '○'}
                    </span>
                    <span className="text-gray-500 ml-1">{s.name}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}
