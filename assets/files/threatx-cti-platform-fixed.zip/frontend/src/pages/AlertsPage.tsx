import { useState, useEffect } from 'react'
import { api } from '../api/client'

interface Alert { id: string; title: string; description: string; severity: string; category: string; source_name: string; read: boolean; created_at: string }

export default function AlertsPage() {
  const [alerts, setAlerts] = useState<Alert[]>([])
  const orgId = localStorage.getItem('active_org_id')

  useEffect(() => {
    if (orgId) api.get<Alert[]>(`/api/orgs/${orgId}/alerts`).then(setAlerts).catch(console.error)
  }, [orgId])

  const markRead = async (alertId: string) => {
    if (!orgId) return
    await api.post(`/api/orgs/${orgId}/alerts/${alertId}/read`)
    setAlerts(prev => prev.map(a => a.id === alertId ? { ...a, read: true } : a))
  }

  const sevBadge = (sev: string) => sev === 'critical' ? 'badge-critical' : sev === 'high' ? 'badge-high' : sev === 'medium' ? 'badge-medium' : 'badge-low'

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Alerts</h1>
      {alerts.length === 0 ? (
        <div className="card text-center py-12"><p className="text-gray-600">No alerts</p></div>
      ) : (
        <div className="space-y-2">
          {alerts.map(a => (
            <div key={a.id} className={`card flex items-center justify-between ${!a.read ? 'border-l-4 border-l-indigo-500' : ''}`}>
              <div>
                <div className="flex items-center gap-2">
                  <span className={`badge ${sevBadge(a.severity)}`}>{a.severity}</span>
                  <h3 className="font-medium text-gray-200">{a.title}</h3>
                </div>
                <p className="text-sm text-gray-500 mt-1">{a.description}</p>
              </div>
              {!a.read && <button onClick={() => markRead(a.id)} className="text-xs text-indigo-400 hover:text-indigo-300">Mark Read</button>}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
