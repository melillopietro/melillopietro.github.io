import { useState } from 'react'
import { api } from '../api/client'

export default function SearchPage() {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const orgId = localStorage.getItem('active_org_id')

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!query.trim() || !orgId) return
    setLoading(true)
    try {
      const res = await api.get(`/api/orgs/${orgId}/search?q=${encodeURIComponent(query)}`)
      setResults(res)
    } catch (err: any) { alert(err.message) }
    finally { setLoading(false) }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Global Search</h1>
      <form onSubmit={handleSearch} className="flex gap-3">
        <input className="input-field flex-1" value={query} onChange={e => setQuery(e.target.value)}
          placeholder="Search by domain, IP, email, CVE, keyword..." />
        <button type="submit" disabled={loading} className="btn-primary">{loading ? 'Searching...' : 'Search'}</button>
      </form>

      {results && (
        <div className="space-y-4">
          <p className="text-sm text-gray-500">{results.total} results found</p>
          {results.assets?.length > 0 && (
            <div className="card"><h3 className="text-sm font-medium text-gray-400 mb-2">Assets ({results.assets.length})</h3>
              {results.assets.map((a: any, i: number) => (
                <div key={i} className="flex items-center gap-3 py-1 text-sm"><span className="badge bg-navy-700 text-gray-300">{a.type}</span><span className="font-mono text-gray-200">{a.value}</span></div>
              ))}</div>
          )}
          {results.breaches?.length > 0 && (
            <div className="card"><h3 className="text-sm font-medium text-gray-400 mb-2">Breaches ({results.breaches.length})</h3>
              {results.breaches.map((b: any, i: number) => (
                <div key={i} className="flex items-center justify-between py-1 text-sm"><span className="text-gray-200">{b.email}</span><span className="text-gray-500">{b.breach_name}</span></div>
              ))}</div>
          )}
          {results.vulnerabilities?.length > 0 && (
            <div className="card"><h3 className="text-sm font-medium text-gray-400 mb-2">Vulnerabilities ({results.vulnerabilities.length})</h3>
              {results.vulnerabilities.map((v: any, i: number) => (
                <div key={i} className="flex items-center justify-between py-1 text-sm"><span className="text-red-400 font-mono">{v.cve_id}</span><span className="text-gray-500">{v.ip}</span><span className="badge badge-critical">CVSS {v.cvss}</span></div>
              ))}</div>
          )}
          {results.services?.length > 0 && (
            <div className="card"><h3 className="text-sm font-medium text-gray-400 mb-2">Services ({results.services.length})</h3>
              {results.services.map((s: any, i: number) => (
                <div key={i} className="flex items-center justify-between py-1 text-sm"><span className="font-mono text-gray-200">{s.ip}:{s.port}</span><span className="text-gray-500">{s.product}</span></div>
              ))}</div>
          )}
          {results.intelligence?.length > 0 && (
            <div className="card"><h3 className="text-sm font-medium text-gray-400 mb-2">Intelligence ({results.intelligence.length})</h3>
              {results.intelligence.map((m: any, i: number) => (
                <div key={i} className="flex items-center justify-between py-1 text-sm"><span className="text-purple-400">{m.term}</span><span className="badge badge-high">{m.mention_type}</span></div>
              ))}</div>
          )}
        </div>
      )}
    </div>
  )
}
