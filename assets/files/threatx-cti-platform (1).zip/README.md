# ThreatX CTI Platform

Cyber Threat Intelligence and Attack Surface Intelligence Platform.

A modular, multi-tenant CTI platform for organizations to discover, monitor, and manage their external attack surface and threat exposure.

## Features

- Multi-Tenancy with separate databases per organization
- Guided 5-step onboarding wizard
- Source Plugin System for easy extension
- Automated multi-step scan pipeline
- Risk Scoring 0-100 with weighted categories and temporal decay
- Dark enterprise-grade UI
- Professional PDF report generation
- Global cross-collection search
- Real-time alerts for new findings
- Complete audit logging

## Quick Start

1. Copy .env.example to .env and fill in secrets
2. Run: docker-compose up -d
3. Frontend at http://localhost:5173
4. Backend API at http://localhost:8000
5. API Docs at http://localhost:8000/docs

## Stack

- Frontend: React, Vite, TypeScript, Tailwind CSS, Recharts
- Backend: FastAPI, Python 3.11, Pydantic v2, Motor (async MongoDB)
- Database: MongoDB (multi-DB tenant isolation)
- Cache: Redis
- Scanning: Nmap (with authorization controls)
- Reports: ReportLab PDF generation
- Auth: JWT + bcrypt + Fernet encryption for API keys

## Environment Variables

See .env.example for all configuration options.
API keys for HIBP, Shodan, IntelX are per-organization (encrypted in DB).

## Nmap Legal Notice

Active scanning requires explicit authorization confirmation.
Default profile is non-aggressive: -sV --version-light -T2 --top-ports 100
Only targets within declared scope are scanned.

## Adding a New Source

1. Create backend/app/sources/newsource/client.py extending BaseSource
2. Implement: validate_config, run, normalize, save, healthcheck
3. Register in backend/app/sources/registry.py
4. Add step to scan orchestrator if needed

## Security

- API keys encrypted with Fernet (AES) before storage
- Passwords hashed with bcrypt
- JWT with configurable expiration
- Tenant isolation at database level
- Input validation and rate limiting
- Audit logging for all critical actions

## API Endpoints

Auth: POST /api/auth/register, /api/auth/login, GET /api/auth/me
Orgs: POST/GET /api/orgs, GET /api/orgs/{id}, POST /api/orgs/{id}/select
Wizard: POST /api/wizard/complete, /api/wizard/test-api-key
Scans: POST /api/orgs/{id}/scans/start, GET /api/orgs/{id}/scans
Dashboard: GET /api/orgs/{id}/dashboard
Risk: GET /api/orgs/{id}/risk, POST /api/orgs/{id}/risk/recalculate
Search: GET /api/orgs/{id}/search?q=
Reports: POST /api/orgs/{id}/reports/generate, GET .../download
Alerts: GET /api/orgs/{id}/alerts, POST .../read
Settings: GET /api/orgs/{id}/settings
Audit: GET /api/audit
Health: GET /api/health
