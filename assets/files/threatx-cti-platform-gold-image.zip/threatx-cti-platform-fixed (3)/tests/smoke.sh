#!/usr/bin/env bash
set -euo pipefail

BASE_URL="${BASE_URL:-http://localhost:8000}"
EMAIL="${EMAIL:-test@example.com}"
PASSWORD="${PASSWORD:-TestPassword123!}"

echo "[1] Health check"
curl -sS "$BASE_URL/api/health"
echo ""

echo "[2] Register test user"
curl -sS -X POST "$BASE_URL/api/auth/register" \
  -H "Content-Type: application/json" \
  -d "{\"email\":\"$EMAIL\",\"password\":\"$PASSWORD\",\"full_name\":\"Test User\"}" || true
echo ""

echo "[3] Login"
TOKEN=$(curl -sS -X POST "$BASE_URL/api/auth/login" \
  -H "Content-Type: application/json" \
  -d "{\"email\":\"$EMAIL\",\"password\":\"$PASSWORD\"}" \
  | python3 -c "import sys,json; print(json.load(sys.stdin).get('access_token',''))")

if [ -z "$TOKEN" ]; then
  echo "Login failed"
  exit 1
fi

echo "Token OK"

echo "[4] Smoke test completed"
