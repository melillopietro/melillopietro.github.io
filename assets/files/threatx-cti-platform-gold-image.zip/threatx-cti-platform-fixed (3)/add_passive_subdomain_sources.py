#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import textwrap

ROOT = Path.cwd()
TS = datetime.now().strftime('%Y%m%d_%H%M%S')
BACKUP = ROOT / '.passive_sources_patch_backups' / TS
BACKUP.mkdir(parents=True, exist_ok=True)

print('== ThreatX passive subdomain enrichment patch ==')
print(f'Project root: {ROOT}')
print(f'Backup dir:   {BACKUP}')


def backup(path: Path):
    if path.exists():
        rel = path.relative_to(ROOT)
        dst = BACKUP / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_text(path.read_text())
        print(f'[backup] {rel}')


def write(path: str, content: str):
    p = ROOT / path
    p.parent.mkdir(parents=True, exist_ok=True)
    backup(p)
    p.write_text(textwrap.dedent(content).lstrip())
    print(f'[write] {path}')

# Ensure httpx exists in requirements
req = ROOT / 'backend/requirements.txt'
if req.exists():
    backup(req)
    txt = req.read_text()
    if 'httpx' not in txt.lower():
        txt = txt.rstrip() + '\nhttpx>=0.27.0\n'
        req.write_text(txt)
        print('[fix] added httpx to backend/requirements.txt')
    else:
        print('[ok] httpx already present')

write('backend/app/sources/subdomain/service.py', r'''
import asyncio
import json
import os
import random
import re
import socket
import string
from collections import defaultdict
from datetime import datetime
from typing import Any, Dict, List, Set, Tuple
from urllib.parse import urlparse

import httpx

from ..base import BaseSource, SourceResult
from ...core.logging import logger


COMMON_SUBS = [
    'www','mail','webmail','smtp','imap','pop','mx','mx1','mx2','ns','ns1','ns2','dns','dns1','dns2',
    'autodiscover','cpanel','whm','ftp','sftp','ssh','vpn','remote','rdp','citrix','portal','login',
    'sso','auth','idp','accounts','account','admin','administrator','dashboard','console','manage',
    'management','intranet','internal','extranet','private','secure','ssl','tls','api','api1','api2',
    'app','apps','mobile','m','web','site','www1','www2','static','assets','cdn','media','img','images',
    'files','download','uploads','docs','doc','wiki','kb','help','support','ticket','tickets','jira',
    'confluence','git','gitlab','github','bitbucket','jenkins','ci','cd','build','registry','docker',
    'harbor','nexus','sonar','sonarqube','grafana','kibana','elastic','elasticsearch','log','logs',
    'monitor','monitoring','status','health','prometheus','zabbix','nagios','splunk','siem','soc',
    'dev','test','qa','uat','stage','staging','preprod','pre-prod','demo','sandbox','lab','labs',
    'old','new','backup','bak','archive','legacy','dr','replica','db','database','mysql','mssql',
    'postgres','postgresql','mongo','redis','oracle','erp','crm','sap','sharepoint','owa','exchange',
    'office','mail1','mail2','newsletter','marketing','shop','store','ecommerce','billing','pay',
    'payments','invoice','vpn1','vpn2','gw','gateway','router','firewall','fw','proxy','waf','voip',
    'sip','pbx','call','video','meet','teams','zoom','ldap','ad','adfs','radius','cas','keycloak',
]


class SubdomainSource(BaseSource):
    name = 'SubdomainFinder'
    source_type = 'passive_osint'

    async def validate_config(self, config: dict) -> bool:
        return bool(config.get('domains'))

    async def run(self, input_context: dict) -> List[SourceResult]:
        domains = [self._clean_domain(d) for d in input_context.get('domains', []) if d]
        domains = [d for d in domains if d]
        org_id = input_context.get('organization_id', '')
        scan_id = input_context.get('scan_id', '')
        log_cb = input_context.get('log')

        async def vlog(message: str, level: str = 'info'):
            logger.info(f'[SubdomainFinder] [{level}] {message}')
            if callable(log_cb):
                try:
                    await log_cb(message, level)
                except Exception:
                    pass

        if not domains:
            await vlog('No domains configured for passive discovery', 'warning')
            return []

        timeout = float(os.getenv('PASSIVE_SOURCE_TIMEOUT', '25'))
        max_per_domain = int(os.getenv('PASSIVE_MAX_SUBDOMAINS_PER_DOMAIN', '2500'))
        resolve_concurrency = int(os.getenv('DNS_RESOLVE_CONCURRENCY', '80'))

        headers = {
            'User-Agent': 'ThreatX-CTI-Platform/1.0 passive-asset-discovery',
            'Accept': 'application/json,text/plain,text/html,*/*',
        }

        results: List[SourceResult] = []

        async with httpx.AsyncClient(timeout=timeout, headers=headers, follow_redirects=True) as client:
            for domain in domains:
                await vlog(f'Starting passive discovery for {domain}', 'info')

                candidates: Dict[str, Set[str]] = defaultdict(set)
                source_ips: Dict[str, Set[str]] = defaultdict(set)

                async def merge(source_name: str, items: List[Tuple[str, List[str]]]):
                    for host, ips in items:
                        host = self._normalize_host(host, domain)
                        if not host:
                            continue
                        candidates[host].add(source_name)
                        for ip in ips or []:
                            if self._is_publicish_ip(ip):
                                source_ips[host].add(ip)

                tasks = [
                    ('crt.sh', self._from_crtsh(client, domain, vlog)),
                    ('HackerTarget', self._from_hackertarget(client, domain, vlog)),
                    ('RapidDNS', self._from_rapiddns(client, domain, vlog)),
                    ('CommonCrawl', self._from_commoncrawl(client, domain, vlog)),
                    ('AlienVault OTX', self._from_otx(client, domain, vlog)),
                ]

                for source_name, task in tasks:
                    try:
                        items = await task
                        await merge(source_name, items)
                        await vlog(f'{source_name}: {len(items)} raw candidates', 'info')
                    except Exception as exc:
                        await vlog(f'{source_name} failed: {exc}', 'warning')

                # Controlled DNS brute force. This is active DNS only, not port scanning.
                if os.getenv('DNS_BRUTEFORCE_ENABLED', 'true').lower() in ('1', 'true', 'yes'):
                    try:
                        brute_items = await self._from_dns_bruteforce(domain, vlog)
                        await merge('DNS brute force', brute_items)
                        await vlog(f'DNS brute force: {len(brute_items)} candidates', 'info')
                    except Exception as exc:
                        await vlog(f'DNS brute force failed: {exc}', 'warning')

                hosts = sorted(candidates.keys())[:max_per_domain]
                await vlog(f'{domain}: {len(hosts)} unique candidates before final resolution', 'info')

                resolved = await self._resolve_many(hosts, domain, resolve_concurrency, source_ips, vlog)

                for host, ips in resolved.items():
                    sources = sorted(candidates.get(host, []))
                    confidence = self._confidence(sources, ips)
                    results.append(
                        SourceResult(
                            source_name=self.name,
                            source_type=self.source_type,
                            collected_at=datetime.utcnow(),
                            confidence=confidence,
                            severity=20,
                            tags=['subdomain', 'discovery', 'passive_osint'],
                            raw_response={
                                'subdomain': host,
                                'ips': ips,
                                'sources': sources,
                            },
                            normalized_entity_type='subdomain',
                            normalized_value=host,
                            organization_id=org_id,
                            scan_id=scan_id,
                            metadata={
                                'parent_domain': domain,
                                'subdomain': host,
                                'resolved_ips': ips,
                                'discovery_sources': sources,
                            },
                        )
                    )

                await vlog(f'{domain}: final resolved subdomains={len(resolved)}, unique IPs={len({ip for ips in resolved.values() for ip in ips})}', 'info')

        logger.info(f'SubdomainFinder: Discovered {len(results)} enriched subdomains')
        return results

    async def _from_crtsh(self, client: httpx.AsyncClient, domain: str, vlog) -> List[Tuple[str, List[str]]]:
        url = 'https://crt.sh/'
        r = await client.get(url, params={'q': f'%.{domain}', 'output': 'json'})
        if r.status_code != 200:
            raise RuntimeError(f'HTTP {r.status_code}')
        try:
            data = r.json()
        except Exception:
            data = json.loads(r.text.replace('}{', '},{'))
        out = []
        for item in data if isinstance(data, list) else []:
            for key in ('name_value', 'common_name'):
                value = item.get(key)
                if not value:
                    continue
                for part in str(value).split('\n'):
                    out.append((part, []))
        return self._dedupe_items(out)

    async def _from_hackertarget(self, client: httpx.AsyncClient, domain: str, vlog) -> List[Tuple[str, List[str]]]:
        r = await client.get('https://api.hackertarget.com/hostsearch/', params={'q': domain})
        if r.status_code != 200:
            raise RuntimeError(f'HTTP {r.status_code}')
        text = r.text.strip()
        if not text or 'error' in text.lower() or 'api count exceeded' in text.lower():
            return []
        out = []
        for line in text.splitlines():
            parts = [p.strip() for p in line.split(',')]
            if parts:
                host = parts[0]
                ip = parts[1] if len(parts) > 1 else ''
                out.append((host, [ip] if ip else []))
        return self._dedupe_items(out)

    async def _from_rapiddns(self, client: httpx.AsyncClient, domain: str, vlog) -> List[Tuple[str, List[str]]]:
        url = f'https://rapiddns.io/subdomain/{domain}'
        r = await client.get(url, params={'full': '1'})
        if r.status_code != 200:
            raise RuntimeError(f'HTTP {r.status_code}')
        return self._dedupe_items([(h, []) for h in self._extract_hosts(r.text, domain)])

    async def _from_commoncrawl(self, client: httpx.AsyncClient, domain: str, vlog) -> List[Tuple[str, List[str]]]:
        max_indexes = int(os.getenv('COMMONCRAWL_MAX_INDEXES', '2'))
        limit = int(os.getenv('COMMONCRAWL_LIMIT_PER_INDEX', '1000'))
        info = await client.get('https://index.commoncrawl.org/collinfo.json')
        if info.status_code != 200:
            raise RuntimeError(f'collinfo HTTP {info.status_code}')
        indexes = info.json()[:max_indexes]
        hosts = set()
        for idx in indexes:
            api = idx.get('cdx-api')
            if not api:
                continue
            try:
                r = await client.get(api, params={
                    'url': f'*.{domain}/*',
                    'output': 'json',
                    'fl': 'url',
                    'filter': 'status:200',
                    'collapse': 'urlkey',
                    'limit': str(limit),
                })
                if r.status_code != 200:
                    continue
                for line in r.text.splitlines():
                    try:
                        obj = json.loads(line)
                        host = urlparse(obj.get('url', '')).hostname or ''
                        if host:
                            hosts.add(host)
                    except Exception:
                        continue
            except Exception as exc:
                await vlog(f'CommonCrawl index query failed: {exc}', 'warning')
        return self._dedupe_items([(h, []) for h in hosts])

    async def _from_otx(self, client: httpx.AsyncClient, domain: str, vlog) -> List[Tuple[str, List[str]]]:
        headers = {}
        otx_key = os.getenv('OTX_API_KEY', '').strip()
        if otx_key:
            headers['X-OTX-API-KEY'] = otx_key
        url = f'https://otx.alienvault.com/api/v1/indicators/domain/{domain}/passive_dns'
        r = await client.get(url, headers=headers)
        if r.status_code in (401, 403):
            await vlog('OTX passive DNS requires/denied API key; skipping', 'warning')
            return []
        if r.status_code != 200:
            raise RuntimeError(f'HTTP {r.status_code}')
        data = r.json()
        out = []
        for item in data.get('passive_dns', []) if isinstance(data, dict) else []:
            host = item.get('hostname') or item.get('indicator') or item.get('host')
            address = item.get('address') or item.get('ip')
            if host:
                out.append((host, [address] if address else []))
        return self._dedupe_items(out)

    async def _from_dns_bruteforce(self, domain: str, vlog) -> List[Tuple[str, List[str]]]:
        limit = int(os.getenv('DNS_BRUTEFORCE_LIMIT', '180'))
        words = self._load_wordlist()[:limit]
        wildcard_ips = await self._wildcard_ips(domain)

        sem = asyncio.Semaphore(int(os.getenv('DNS_RESOLVE_CONCURRENCY', '80')))
        out = []

        async def check(word: str):
            host = f'{word}.{domain}'
            async with sem:
                ips = await self._resolve(host)
            if not ips:
                return None
            # Avoid polluting results when wildcard DNS resolves every random name.
            if wildcard_ips and set(ips).issubset(wildcard_ips):
                return None
            return host, ips

        tasks = [check(w) for w in words]
        for r in await asyncio.gather(*tasks, return_exceptions=True):
            if r and not isinstance(r, Exception):
                out.append(r)
        return self._dedupe_items(out)

    async def _resolve_many(self, hosts: List[str], domain: str, concurrency: int, source_ips: Dict[str, Set[str]], vlog) -> Dict[str, List[str]]:
        sem = asyncio.Semaphore(concurrency)
        resolved: Dict[str, List[str]] = {}
        wildcard_ips = await self._wildcard_ips(domain)

        async def one(host: str):
            async with sem:
                ips = await self._resolve(host)
            known = set(source_ips.get(host, set()))
            for ip in ips:
                known.add(ip)
            # Keep passive hostnames even if they no longer resolve, but prefer resolved IPs.
            if known:
                # If all IPs only match wildcard and there was no passive supplied IP, drop it.
                if wildcard_ips and known.issubset(wildcard_ips) and not source_ips.get(host):
                    return None
                return host, sorted(known)
            # keep unresolved passive names with empty list only when requested
            if os.getenv('KEEP_UNRESOLVED_SUBDOMAINS', 'false').lower() in ('1', 'true', 'yes'):
                return host, []
            return None

        for r in await asyncio.gather(*(one(h) for h in hosts), return_exceptions=True):
            if r and not isinstance(r, Exception):
                resolved[r[0]] = r[1]
        return resolved

    async def _resolve(self, host: str) -> List[str]:
        try:
            def work():
                values = socket.getaddrinfo(host, None, proto=socket.IPPROTO_TCP)
                ips = []
                for v in values:
                    ip = v[4][0]
                    if self._is_publicish_ip(ip):
                        ips.append(ip)
                return sorted(set(ips))
            return await asyncio.wait_for(asyncio.to_thread(work), timeout=float(os.getenv('DNS_RESOLVE_TIMEOUT', '4')))
        except Exception:
            return []

    async def _wildcard_ips(self, domain: str) -> Set[str]:
        label = ''.join(random.choice(string.ascii_lowercase) for _ in range(18))
        host = f'{label}.{domain}'
        return set(await self._resolve(host))

    def _load_wordlist(self) -> List[str]:
        custom = os.getenv('DNS_BRUTEFORCE_WORDLIST', '').strip()
        if custom and os.path.exists(custom):
            with open(custom, 'r', encoding='utf-8', errors='ignore') as f:
                words = [x.strip().lower() for x in f if x.strip() and not x.startswith('#')]
            return list(dict.fromkeys(words))
        return list(dict.fromkeys(COMMON_SUBS))

    def _extract_hosts(self, text: str, domain: str) -> Set[str]:
        pattern = re.compile(r'(?i)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+' + re.escape(domain))
        return {self._normalize_host(m.group(0), domain) for m in pattern.finditer(text) if self._normalize_host(m.group(0), domain)}

    def _dedupe_items(self, items: List[Tuple[str, List[str]]]) -> List[Tuple[str, List[str]]]:
        merged: Dict[str, Set[str]] = defaultdict(set)
        # Infer domain from each host itself; normalize happens later in context.
        for host, ips in items:
            clean = str(host or '').strip().lower().strip('.').replace('*.','')
            if not clean or ' ' in clean or '/' in clean:
                continue
            merged[clean].update([ip for ip in ips or [] if self._is_publicish_ip(ip)])
        return [(h, sorted(ips)) for h, ips in merged.items()]

    def _normalize_host(self, host: str, domain: str) -> str:
        if not host:
            return ''
        host = host.strip().lower().strip('.').replace('*.','')
        host = host.split(':')[0] if ':' in host and host.count(':') == 1 else host
        if not host.endswith('.' + domain) and host != domain:
            return ''
        if host == domain:
            return host
        if not re.match(r'^[a-z0-9._-]+$', host):
            return ''
        return host

    def _clean_domain(self, domain: str) -> str:
        domain = str(domain or '').strip().lower()
        domain = domain.replace('http://', '').replace('https://', '').split('/')[0].strip('.')
        if ':' in domain:
            domain = domain.split(':')[0]
        if not re.match(r'^[a-z0-9.-]+\.[a-z]{2,}$', domain):
            return ''
        return domain

    def _is_publicish_ip(self, ip: str) -> bool:
        if not ip or not isinstance(ip, str):
            return False
        # Keep simple; avoid strict ipaddress private filtering because internal assets may be legitimate.
        return bool(re.match(r'^[0-9]{1,3}(\.[0-9]{1,3}){3}$', ip) or ':' in ip)

    def _confidence(self, sources: List[str], ips: List[str]) -> float:
        base = 0.55
        base += min(len(sources), 4) * 0.08
        if ips:
            base += 0.10
        return min(base, 0.95)

    def normalize(self, raw_result: Any) -> List[SourceResult]:
        return [raw_result] if isinstance(raw_result, SourceResult) else []

    async def save(self, db, results: List[SourceResult]) -> int:
        saved = 0
        for r in results:
            subdomain = r.metadata['subdomain']
            await db.assets_subdomains.update_one(
                {'subdomain': subdomain},
                {
                    '$set': {
                        'subdomain': subdomain,
                        'parent_domain': r.metadata['parent_domain'],
                        'resolved_ips': r.metadata.get('resolved_ips', []),
                        'discovery_sources': r.metadata.get('discovery_sources', []),
                        'source_name': self.name,
                        'source_type': self.source_type,
                        'scan_id': r.scan_id,
                        'organization_id': r.organization_id,
                        'confidence': r.confidence,
                        'collected_at': r.collected_at,
                        'last_seen': r.collected_at,
                        'status': 'active',
                    },
                    '$setOnInsert': {'first_seen': r.collected_at},
                },
                upsert=True,
            )
            for ip in r.metadata.get('resolved_ips', []):
                await db.assets_ips.update_one(
                    {'ip': ip},
                    {
                        '$set': {
                            'ip': ip,
                            'organization_id': r.organization_id,
                            'source_name': self.name,
                            'source_type': self.source_type,
                            'discovered_via': subdomain,
                            'scan_id': r.scan_id,
                            'last_seen': r.collected_at,
                            'status': 'active',
                        },
                        '$setOnInsert': {'first_seen': r.collected_at, 'added_at': r.collected_at},
                    },
                    upsert=True,
                )
            saved += 1
        return saved

    async def healthcheck(self) -> dict:
        return {
            'source': self.name,
            'status': 'available',
            'type': self.source_type,
            'providers': ['crt.sh', 'HackerTarget', 'RapidDNS', 'CommonCrawl', 'AlienVault OTX', 'DNS brute force'],
        }
''')

# Add optional notes to .env.example
for env_file in [ROOT / '.env.example', ROOT / '.env']:
    if env_file.exists():
        backup(env_file)
        text = env_file.read_text()
        block = '''

# Passive subdomain discovery tuning
PASSIVE_SOURCE_TIMEOUT=25
PASSIVE_MAX_SUBDOMAINS_PER_DOMAIN=2500
DNS_BRUTEFORCE_ENABLED=true
DNS_BRUTEFORCE_LIMIT=180
DNS_RESOLVE_CONCURRENCY=80
DNS_RESOLVE_TIMEOUT=4
COMMONCRAWL_MAX_INDEXES=2
COMMONCRAWL_LIMIT_PER_INDEX=1000
KEEP_UNRESOLVED_SUBDOMAINS=false
# Optional: enable richer AlienVault OTX access when available
# OTX_API_KEY=
'''
        if 'PASSIVE_MAX_SUBDOMAINS_PER_DOMAIN' not in text:
            env_file.write_text(text.rstrip() + block)
            print(f'[fix] appended passive discovery settings to {env_file.name}')

print('\n== Patch complete ==')
print('Next commands:')
print('docker-compose build --no-cache backend')
print('docker-compose up -d backend')
print('docker-compose logs -f backend')
print('\nThen start a new scan. The Subdomain Discovery step will query crt.sh, HackerTarget, RapidDNS, CommonCrawl, OTX and a controlled DNS brute-force wordlist.')
