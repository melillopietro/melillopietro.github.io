from fastapi import APIRouter, Depends, HTTPException
from bson import ObjectId
from app.core.database import get_client, get_core_db, get_org_db
from app.core.tenant import get_current_user

router = APIRouter()

async def _get_org_and_db(org_id: str, user: dict):
    client = await get_client()
    core_db = get_core_db(client)
    membership = await core_db.memberships.find_one({"user_id": str(user["_id"]), "organization_id": org_id})
    if not membership:
        raise HTTPException(status_code=403, detail="Access denied")
    if not ObjectId.is_valid(org_id):
        raise HTTPException(status_code=400, detail="Invalid organization id")
    org = await core_db.organizations.find_one({"_id": ObjectId(org_id)})
    if not org:
        raise HTTPException(status_code=404, detail="Organization not found")
    return org, get_org_db(client, org["slug"])

def _oid(doc):
    if not doc:
        return doc
    out = dict(doc)
    if "_id" in out:
        out["id"] = str(out.pop("_id"))
    for key in ["created_at", "updated_at", "collected_at", "first_seen", "last_seen", "added_at"]:
        if key in out and hasattr(out[key], "isoformat"):
            out[key] = out[key].isoformat()
    return out

@router.get("")
async def list_assets(org_id: str, user: dict = Depends(get_current_user)):
    org, db = await _get_org_and_db(org_id, user)
    domains = await db.assets_domains.find().sort("last_seen", -1).limit(500).to_list(500)
    subdomains = await db.assets_subdomains.find().sort("last_seen", -1).limit(500).to_list(500)
    ips = await db.assets_ips.find().sort("added_at", -1).limit(500).to_list(500)
    services = await db.exposed_services.find().sort("last_seen", -1).limit(500).to_list(500)
    vulnerabilities = await db.vulnerabilities.find().sort("last_seen", -1).limit(500).to_list(500)
    dns_records = await db.dns_records.find().sort("last_seen", -1).limit(500).to_list(500)
    whois_records = await db.whois_records.find().sort("collected_at", -1).limit(200).to_list(200)
    return {
        "organization": {"id": org_id, "name": org.get("name"), "slug": org.get("slug")},
        "summary": {
            "domains": len(domains),
            "subdomains": len(subdomains),
            "ips": len(ips),
            "services": len(services),
            "vulnerabilities": len(vulnerabilities),
            "dns_records": len(dns_records),
            "whois_records": len(whois_records),
        },
        "domains": [_oid(x) for x in domains],
        "subdomains": [_oid(x) for x in subdomains],
        "ips": [_oid(x) for x in ips],
        "services": [_oid(x) for x in services],
        "vulnerabilities": [_oid(x) for x in vulnerabilities],
        "dns_records": [_oid(x) for x in dns_records],
        "whois_records": [_oid(x) for x in whois_records],
    }
