import asyncio
import json
import os
import re
import socket
from collections import defaultdict
from datetime import datetime
from typing import Any, Dict, List, Set, Tuple
from urllib.parse import urlparse

import httpx

from ..base import BaseSource, SourceResult
from ...core.logging import logger
try:
    from ...core.config import get_settings
except Exception:
    get_settings = None
try:
    from ...core.security import decrypt_api_key
except Exception:
    decrypt_api_key = None


COMMON_SUBS = [
    'www','mail','webmail','smtp','imap','pop','mx','mx1','mx2','ns','ns1','ns2','dns','dns1','dns2',
    'autodiscover','cpanel','whm','ftp','sftp','ssh','vpn','remote','rdp','citrix','portal','login',
    'sso','auth','idp','accounts','account','admin','administrator','dashboard','console','manage',
    'management','intranet','internal','extranet','private','secure','ssl','tls','api','api1','api2',
    'app','apps','mobile','m','web','site','www1','www2','static','assets','cdn','media','img','images',
    'files','download','uploads','docs','doc','wiki','kb','help','support','ticket','tickets','jira',
    'confluence','git','gitlab','github','bitbucket','jenkins','ci','cd','build','registry','docker',
    'harbor','nexus','sonar','sonarqube','grafana','kibana','elastic','elasticsearch','log','logs',
    'monitor','monitoring','status','health','prometheus','zabbix','nagios','splunk','siem','soc',
    'dev','test','qa','uat','stage','staging','preprod','pre-prod','demo','sandbox','lab','labs',
    'old','new','backup','bak','archive','legacy','dr','replica','db','database','mysql','mssql',
    'postgres','postgresql','mongo','redis','oracle','erp','crm','sap','sharepoint','owa','exchange',
    'office','mail1','mail2','newsletter','marketing','shop','store','ecommerce','billing','pay',
    'payments','invoice','vpn1','vpn2','gw','gateway','router','firewall','fw','proxy','waf','voip',
    'sip','pbx','call','video','meet','teams','zoom','ldap','ad','adfs','radius','cas','keycloak',
]


class SubdomainSource(BaseSource):
    name = 'SubdomainFinder'
    source_type = 'passive_osint'

    async def validate_config(self, config: dict) -> bool:
        return bool(config.get('domains'))

    def _setting(self, name: str, default: Any) -> Any:
        if get_settings:
            try:
                settings = get_settings()
                if hasattr(settings, name):
                    return getattr(settings, name)
            except Exception:
                pass
        return os.getenv(name, default)

    def _bool(self, name: str, default: bool = True) -> bool:
        value = self._setting(name, default)
        if isinstance(value, bool):
            return value
        return str(value).lower() in ('1', 'true', 'yes', 'on')

    async def run(self, input_context: dict) -> List[SourceResult]:
        domains = [self._clean_domain(d) for d in input_context.get('domains', []) if d]
        domains = [d for d in domains if d]
        org_id = input_context.get('organization_id', '')
        scan_id = input_context.get('scan_id', '')
        log_cb = input_context.get('log')
        api_sources = input_context.get('api_sources') or {}

        async def vlog(message: str, level: str = 'info'):
            logger.info(f'[SubdomainFinder] [{level}] {message}')
            if callable(log_cb):
                try:
                    await log_cb(message, level)
                except Exception:
                    pass

        if not domains:
            await vlog('No domains configured for passive discovery', 'warning')
            return []

        timeout = float(self._setting('PASSIVE_SOURCE_TIMEOUT', 25))
        max_per_domain = int(self._setting('PASSIVE_MAX_SUBDOMAINS_PER_DOMAIN', 2500))
        resolve_concurrency = int(self._setting('DNS_RESOLVE_CONCURRENCY', 80))

        headers = {
            'User-Agent': 'ThreatX-CTI-Platform/1.0 passive-asset-discovery',
            'Accept': 'application/json,text/plain,text/html,*/*',
        }

        results: List[SourceResult] = []

        async with httpx.AsyncClient(timeout=timeout, headers=headers, follow_redirects=True) as client:
            for domain in domains:
                await vlog(f'Starting passive discovery for {domain}', 'info')

                candidates: Dict[str, Set[str]] = defaultdict(set)
                source_ips: Dict[str, Set[str]] = defaultdict(set)

                async def merge(source_name: str, items: List[Tuple[str, List[str]]]):
                    for host, ips in items:
                        host = self._normalize_host(host, domain)
                        if not host:
                            continue
                        candidates[host].add(source_name)
                        for ip in ips or []:
                            if self._is_publicish_ip(ip):
                                source_ips[host].add(ip)

                jobs = []
                if self._bool('PASSIVE_CRTSH_ENABLED', True):
                    jobs.append(('crt.sh', self._from_crtsh(client, domain, vlog)))
                if self._bool('PASSIVE_HACKERTARGET_ENABLED', True):
                    jobs.append(('HackerTarget', self._from_hackertarget(client, domain, vlog)))
                if self._bool('PASSIVE_RAPIDDNS_ENABLED', True):
                    jobs.append(('RapidDNS', self._from_rapiddns(client, domain, vlog)))
                if self._bool('PASSIVE_COMMONCRAWL_ENABLED', True):
                    jobs.append(('CommonCrawl', self._from_commoncrawl(client, domain, vlog)))
                if self._bool('PASSIVE_OTX_ENABLED', True):
                    jobs.append(('AlienVault OTX', self._from_otx(client, domain, api_sources, vlog)))

                for source_name, task in jobs:
                    try:
                        items = await task
                        await merge(source_name, items)
                        await vlog(f'{source_name}: {len(items)} raw candidates', 'info')
                    except Exception as exc:
                        await vlog(f'{source_name} failed: {exc}', 'warning')

                if self._bool('DNS_BRUTEFORCE_ENABLED', True):
                    try:
                        brute_items = await self._from_dns_bruteforce(domain, vlog)
                        await merge('DNS brute force', brute_items)
                        await vlog(f'DNS brute force: {len(brute_items)} candidates', 'info')
                    except Exception as exc:
                        await vlog(f'DNS brute force failed: {exc}', 'warning')

                hosts = sorted(candidates.keys())[:max_per_domain]
                await vlog(f'{domain}: {len(hosts)} unique candidates before final resolution', 'info')

                resolved = await self._resolve_many(hosts, domain, resolve_concurrency, source_ips, vlog)

                for host, ips in resolved.items():
                    sources = sorted(candidates.get(host, []))
                    results.append(
                        SourceResult(
                            source_name=self.name,
                            source_type=self.source_type,
                            collected_at=datetime.utcnow(),
                            confidence=self._confidence(sources, ips),
                            severity=20,
                            tags=['subdomain', 'discovery', 'passive_osint'],
                            raw_response={'subdomain': host, 'ips': ips, 'sources': sources},
                            normalized_entity_type='subdomain',
                            normalized_value=host,
                            organization_id=org_id,
                            scan_id=scan_id,
                            metadata={
                                'parent_domain': domain,
                                'subdomain': host,
                                'resolved_ips': ips,
                                'discovery_sources': sources,
                            },
                        )
                    )

                await vlog(f'{domain}: final resolved subdomains={len(resolved)}, unique IPs={len({ip for ips in resolved.values() for ip in ips})}', 'info')

        logger.info(f'SubdomainFinder: Discovered {len(results)} enriched subdomains')
        return results

    async def _from_crtsh(self, client: httpx.AsyncClient, domain: str, vlog) -> List[Tuple[str, List[str]]]:
        r = await client.get('https://crt.sh/', params={'q': f'%.{domain}', 'output': 'json'})
        if r.status_code != 200:
            raise RuntimeError(f'HTTP {r.status_code}')
        try:
            data = r.json()
        except Exception:
            data = []
        hosts = set()
        for item in data:
            name_value = item.get('name_value', '') if isinstance(item, dict) else ''
            for h in str(name_value).split('\n'):
                h = h.strip().lower().lstrip('*.')
                if h:
                    hosts.add(h)
        return self._dedupe_items([(h, []) for h in hosts])

    async def _from_hackertarget(self, client: httpx.AsyncClient, domain: str, vlog) -> List[Tuple[str, List[str]]]:
        r = await client.get('https://api.hackertarget.com/hostsearch/', params={'q': domain})
        if r.status_code != 200:
            raise RuntimeError(f'HTTP {r.status_code}')
        text = r.text.strip()
        if not text or 'error' in text.lower() or 'api count exceeded' in text.lower():
            return []
        out = []
        for line in text.splitlines():
            parts = [p.strip() for p in line.split(',')]
            if parts:
                host = parts[0]
                ip = parts[1] if len(parts) > 1 else ''
                out.append((host, [ip] if ip else []))
        return self._dedupe_items(out)

    async def _from_rapiddns(self, client: httpx.AsyncClient, domain: str, vlog) -> List[Tuple[str, List[str]]]:
        r = await client.get(f'https://rapiddns.io/subdomain/{domain}', params={'full': '1'})
        if r.status_code != 200:
            raise RuntimeError(f'HTTP {r.status_code}')
        return self._dedupe_items([(h, []) for h in self._extract_hosts(r.text, domain)])

    async def _from_commoncrawl(self, client: httpx.AsyncClient, domain: str, vlog) -> List[Tuple[str, List[str]]]:
        max_indexes = int(self._setting('COMMONCRAWL_MAX_INDEXES', 2))
        limit = int(self._setting('COMMONCRAWL_LIMIT_PER_INDEX', 1000))
        info = await client.get('https://index.commoncrawl.org/collinfo.json')
        if info.status_code != 200:
            raise RuntimeError(f'collinfo HTTP {info.status_code}')
        indexes = info.json()[:max_indexes]
        hosts = set()
        for idx in indexes:
            api = idx.get('cdx-api')
            if not api:
                continue
            try:
                r = await client.get(api, params={
                    'url': f'*.{domain}/*',
                    'output': 'json',
                    'fl': 'url',
                    'filter': 'status:200',
                    'collapse': 'urlkey',
                    'limit': str(limit),
                })
                if r.status_code != 200:
                    continue
                for line in r.text.splitlines():
                    try:
                        obj = json.loads(line)
                        host = urlparse(obj.get('url', '')).hostname or ''
                        if host:
                            hosts.add(host)
                    except Exception:
                        continue
            except Exception as exc:
                await vlog(f'CommonCrawl index query failed: {exc}', 'warning')
        return self._dedupe_items([(h, []) for h in hosts])

    async def _from_otx(self, client: httpx.AsyncClient, domain: str, api_sources: dict, vlog) -> List[Tuple[str, List[str]]]:
        cfg = api_sources.get('otx') or api_sources.get('alienvault_otx') or {}
        base_url = (cfg.get('base_url') or 'https://otx.alienvault.com/api/v1').rstrip('/')
        encrypted = cfg.get('api_key_encrypted')
        api_key = cfg.get('api_key') or ''
        if encrypted and not api_key and decrypt_api_key:
            try:
                api_key = decrypt_api_key(encrypted)
            except Exception as exc:
                await vlog(f'OTX API key decrypt failed: {exc}', 'warning')
        headers = {'User-Agent': 'ThreatX-CTI-Platform/1.0'}
        if api_key:
            headers['X-OTX-API-KEY'] = api_key
        else:
            await vlog('OTX API key not configured in Wizard/Settings; trying unauthenticated passive DNS request', 'warning')
        url = f'{base_url}/indicators/domain/{domain}/passive_dns'
        r = await client.get(url, headers=headers)
        if r.status_code in (401, 403):
            await vlog('OTX passive DNS denied; configure AlienVault OTX API key in Wizard/Settings', 'warning')
            return []
        if r.status_code != 200:
            raise RuntimeError(f'HTTP {r.status_code}')
        data = r.json()
        out = []
        for item in data.get('passive_dns', []) if isinstance(data, dict) else []:
            host = item.get('hostname') or item.get('indicator') or item.get('host')
            address = item.get('address') or item.get('ip')
            if host:
                out.append((host, [address] if address else []))
        return self._dedupe_items(out)

    async def _from_dns_bruteforce(self, domain: str, vlog) -> List[Tuple[str, List[str]]]:
        limit = int(self._setting('DNS_BRUTEFORCE_LIMIT', 180))
        words = self._load_wordlist()[:limit]
        wildcard_ips = await self._wildcard_ips(domain)
        sem = asyncio.Semaphore(int(self._setting('DNS_RESOLVE_CONCURRENCY', 80)))
        out = []

        async def check(word: str):
            host = f'{word}.{domain}'
            async with sem:
                ips = await self._resolve(host)
            if not ips:
                return None
            if wildcard_ips and set(ips).issubset(wildcard_ips):
                return None
            return host, ips

        for r in await asyncio.gather(*(check(w) for w in words), return_exceptions=True):
            if r and not isinstance(r, Exception):
                out.append(r)
        return self._dedupe_items(out)

    async def _resolve_many(self, hosts: List[str], domain: str, concurrency: int, source_ips: Dict[str, Set[str]], vlog) -> Dict[str, List[str]]:
        sem = asyncio.Semaphore(concurrency)
        resolved: Dict[str, List[str]] = {}
        wildcard_ips = await self._wildcard_ips(domain)

        async def one(host: str):
            async with sem:
                ips = await self._resolve(host)
            known = set(source_ips.get(host, set()))
            for ip in ips:
                known.add(ip)
            if known:
                if wildcard_ips and known.issubset(wildcard_ips) and not source_ips.get(host):
                    return None
                return host, sorted(known)
            if self._bool('KEEP_UNRESOLVED_SUBDOMAINS', False):
                return host, []
            return None

        for r in await asyncio.gather(*(one(h) for h in hosts), return_exceptions=True):
            if r and not isinstance(r, Exception):
                resolved[r[0]] = r[1]
        return resolved

    async def _resolve(self, host: str) -> List[str]:
        try:
            def work():
                values = socket.getaddrinfo(host, None, proto=socket.IPPROTO_TCP)
                ips = []
                for v in values:
                    ip = v[4][0]
                    if self._is_publicish_ip(ip):
                        ips.append(ip)
                return sorted(set(ips))
            return await asyncio.wait_for(asyncio.to_thread(work), timeout=float(self._setting('DNS_RESOLVE_TIMEOUT', 4)))
        except Exception:
            return []

    async def _wildcard_ips(self, domain: str) -> Set[str]:
        random_host = 'tx-' + ''.join(['x' for _ in range(12)]) + '.' + domain
        return set(await self._resolve(random_host))

    def _load_wordlist(self) -> List[str]:
        custom = str(self._setting('DNS_BRUTEFORCE_WORDLIST', '') or '').strip()
        if custom and os.path.exists(custom):
            try:
                return [x.strip().lower() for x in open(custom, 'r', encoding='utf-8', errors='ignore') if x.strip() and not x.startswith('#')]
            except Exception:
                pass
        return COMMON_SUBS

    def _extract_hosts(self, text: str, domain: str) -> Set[str]:
        pattern = re.compile(r'(?i)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+' + re.escape(domain))
        return {m.group(0).lower().strip('.') for m in pattern.finditer(text or '')}

    def _normalize_host(self, value: str, domain: str) -> str:
        if not value:
            return ''
        h = value.lower().strip().strip('.').lstrip('*.')
        if ':' in h and '/' not in h:
            h = h.split(':', 1)[0]
        if h == domain or h.endswith('.' + domain):
            if re.fullmatch(r'[a-z0-9.-]+', h):
                return h
        return ''

    def _clean_domain(self, value: str) -> str:
        value = value.strip().lower()
        value = re.sub(r'^https?://', '', value)
        value = value.split('/')[0].split(':')[0].strip('.')
        return value

    def _is_publicish_ip(self, ip: str) -> bool:
        if not ip or ':' in ip:
            return False
        if ip.startswith(('10.', '127.', '169.254.', '192.168.')):
            return False
        if re.match(r'^172\.(1[6-9]|2[0-9]|3[0-1])\.', ip):
            return False
        return bool(re.match(r'^\d{1,3}(\.\d{1,3}){3}$', ip))

    def _confidence(self, sources: List[str], ips: List[str]) -> float:
        base = 0.55
        base += min(len(sources), 4) * 0.08
        if ips:
            base += 0.15
        return min(base, 0.95)

    def _dedupe_items(self, items: List[Tuple[str, List[str]]]) -> List[Tuple[str, List[str]]]:
        merged: Dict[str, Set[str]] = defaultdict(set)
        for host, ips in items:
            if not host:
                continue
            h = host.lower().strip().strip('.')
            for ip in ips or []:
                if ip:
                    merged[h].add(ip)
            if h not in merged:
                merged[h] = set()
        return [(h, sorted(v)) for h, v in sorted(merged.items())]

    def normalize(self, raw_result: Any) -> List[SourceResult]:
        return [raw_result] if isinstance(raw_result, SourceResult) else []

    async def save(self, db, results: List[SourceResult]) -> int:
        saved = 0
        for r in results:
            subdomain = r.metadata.get('subdomain') or r.normalized_value
            await db.assets_subdomains.update_one(
                {'subdomain': subdomain},
                {
                    '$set': {
                        'subdomain': subdomain,
                        'parent_domain': r.metadata.get('parent_domain'),
                        'resolved_ips': r.metadata.get('resolved_ips', []),
                        'discovery_sources': r.metadata.get('discovery_sources', []),
                        'organization_id': r.organization_id,
                        'source_name': self.name,
                        'source_type': self.source_type,
                        'scan_id': r.scan_id,
                        'confidence': r.confidence,
                        'severity': r.severity,
                        'last_seen': r.collected_at,
                        'status': 'active',
                    },
                    '$setOnInsert': {'first_seen': r.collected_at, 'added_at': r.collected_at},
                },
                upsert=True,
            )
            for ip in r.metadata.get('resolved_ips', []):
                await db.assets_ips.update_one(
                    {'ip': ip},
                    {
                        '$set': {
                            'ip': ip,
                            'organization_id': r.organization_id,
                            'source_name': self.name,
                            'source_type': self.source_type,
                            'discovered_via': subdomain,
                            'scan_id': r.scan_id,
                            'last_seen': r.collected_at,
                            'status': 'active',
                        },
                        '$setOnInsert': {'first_seen': r.collected_at, 'added_at': r.collected_at},
                    },
                    upsert=True,
                )
            saved += 1
        return saved

    async def healthcheck(self) -> dict:
        return {
            'source': self.name,
            'status': 'available',
            'type': self.source_type,
            'providers': ['crt.sh', 'HackerTarget', 'RapidDNS', 'CommonCrawl', 'AlienVault OTX', 'DNS brute force'],
        }
