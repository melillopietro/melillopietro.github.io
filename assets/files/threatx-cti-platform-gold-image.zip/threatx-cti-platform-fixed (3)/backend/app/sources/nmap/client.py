import asyncio
import shlex
import xml.etree.ElementTree as ET
from typing import Any, List
from datetime import datetime

from ..base import BaseSource, SourceResult
from ...core.logging import logger
from ...core.config import get_settings

settings = get_settings()


class NmapSource(BaseSource):
    name = "Nmap"
    source_type = "active_scan"

    async def validate_config(self, config: dict) -> bool:
        if not config.get("authorization_confirmed"):
            return False

        try:
            proc = await asyncio.create_subprocess_exec(
                "nmap",
                "--version",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, _ = await proc.communicate()
            return b"Nmap" in stdout
        except Exception:
            return False

    async def run(self, input_context: dict) -> List[SourceResult]:
        log = input_context.get("log")

        async def vlog(message: str, level: str = "info"):
            logger.info(f"[Nmap] [{level}] {message}")
            if callable(log):
                try:
                    await log(message, level)
                except Exception:
                    pass

        if not input_context.get("authorization_confirmed"):
            await vlog("Nmap skipped: authorization not confirmed", "warning")
            return []

        if not settings.NMAP_ENABLED:
            await vlog("Nmap skipped: disabled by settings", "warning")
            return []

        ips = list(dict.fromkeys(input_context.get("ips", [])))
        max_hosts = getattr(settings, "NMAP_MAX_HOSTS", 10)
        ips = ips[:max_hosts]

        await vlog(f"Nmap input hosts={len(ips)} max_hosts={max_hosts}: {ips}", "info")

        if not ips:
            await vlog("Nmap skipped: no IPs available from previous steps", "warning")
            return []

        org_id = input_context.get("organization_id", "")
        scan_id = input_context.get("scan_id", "")

        results = []

        for pos, ip in enumerate(ips, start=1):
            await vlog(f"Starting Nmap host {pos}/{len(ips)}: {ip}", "info")

            try:
                services = await self._scan_host(ip, input_context, vlog)

                await vlog(f"Nmap host {ip} completed. Open services={len(services)}", "info")

                for svc in services:
                    results.append(
                        SourceResult(
                            source_name=self.name,
                            source_type=self.source_type,
                            collected_at=datetime.utcnow(),
                            confidence=0.9,
                            severity=self._calc_sev(svc.get("port", 0)),
                            tags=["active_scan", "exposed_service"],
                            raw_response=svc,
                            normalized_entity_type="service",
                            normalized_value=f"{ip}:{svc['port']}",
                            organization_id=org_id,
                            scan_id=scan_id,
                            metadata={
                                "ip": ip,
                                "port": svc["port"],
                                "protocol": svc.get("protocol", "tcp"),
                                "state": svc.get("state", "open"),
                                "service_name": svc.get("service", ""),
                                "product": svc.get("product", ""),
                                "version": svc.get("version", ""),
                            },
                        )
                    )

            except asyncio.TimeoutError:
                await vlog(f"Nmap timeout on host {ip}", "error")
                raise RuntimeError(f"Nmap timeout on host {ip}")

            except Exception as exc:
                await vlog(f"Nmap failed on host {ip}: {exc}", "error")
                raise

        await vlog(f"Nmap completed for all hosts. Total exposed services={len(results)}", "info")
        return results

    async def _scan_host(self, ip: str, input_context: dict, vlog) -> List[dict]:
        timeout = int(getattr(settings, "NMAP_TIMEOUT", 120))

        raw_args = getattr(settings, "NMAP_DEFAULT_ARGS", "") or ""

        # Safer defaults for light scan. They reduce hanging on filtered hosts.
        safe_args = [
            "-Pn",
            "--open",
            "--reason",
            "--max-retries",
            "1",
            "--host-timeout",
            f"{timeout}s",
            "--stats-every",
            "10s",
        ]

        # If user has custom args, preserve them but still append XML output and target.
        user_args = shlex.split(raw_args)

        # Avoid duplicate XML output if configured already.
        if "-oX" not in user_args:
            user_args.extend(["-oX", "-"])

        cmd = ["nmap"] + safe_args + user_args + [ip]

        await vlog("Command: " + " ".join(shlex.quote(x) for x in cmd), "info")
        await vlog(f"Timeout: {timeout}s", "info")

        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        stdout_chunks: list[bytes] = []
        stderr_lines: list[str] = []

        async def read_stdout():
            while True:
                chunk = await proc.stdout.read(4096)
                if not chunk:
                    break
                stdout_chunks.append(chunk)

        async def read_stderr():
            while True:
                line = await proc.stderr.readline()
                if not line:
                    break
                decoded = line.decode(errors="ignore").strip()
                if decoded:
                    stderr_lines.append(decoded)
                    await vlog(f"stderr: {decoded}", "info")

        stdout_task = asyncio.create_task(read_stdout())
        stderr_task = asyncio.create_task(read_stderr())

        try:
            await asyncio.wait_for(proc.wait(), timeout=timeout)

        except asyncio.TimeoutError:
            await vlog(f"Timeout reached. Killing Nmap process for host {ip}", "error")
            proc.kill()

            try:
                await asyncio.wait_for(proc.wait(), timeout=10)
            except asyncio.TimeoutError:
                await vlog(f"Nmap process did not terminate cleanly after kill for host {ip}", "error")

            stdout_task.cancel()
            stderr_task.cancel()
            raise

        await stdout_task
        await stderr_task

        await vlog(f"Nmap return code: {proc.returncode}", "info")

        stdout = b"".join(stdout_chunks)

        if proc.returncode != 0:
            msg = "; ".join(stderr_lines[-5:]) if stderr_lines else "Unknown Nmap error"
            await vlog(f"Nmap non-zero return code for {ip}: {msg}", "error")
            raise RuntimeError(f"Nmap failed on {ip}: {msg}")

        if not stdout:
            await vlog(f"Nmap produced empty XML output for {ip}", "warning")
            return []

        return self._parse_xml(stdout.decode(errors="ignore"))

    def _parse_xml(self, xml_output: str) -> List[dict]:
        services = []

        try:
            root = ET.fromstring(xml_output)

            for port_elem in root.findall(".//port"):
                state_elem = port_elem.find("state")
                service_elem = port_elem.find("service")

                if state_elem is not None and state_elem.get("state") == "open":
                    svc = {
                        "port": int(port_elem.get("portid", 0)),
                        "protocol": port_elem.get("protocol", "tcp"),
                        "state": "open",
                    }

                    if service_elem is not None:
                        svc.update({
                            "service": service_elem.get("name", ""),
                            "product": service_elem.get("product", ""),
                            "version": service_elem.get("version", ""),
                        })

                    services.append(svc)

        except ET.ParseError as exc:
            logger.error(f"Nmap XML parse error: {exc}")
            raise RuntimeError(f"Nmap XML parse error: {exc}")

        return services

    def normalize(self, raw_result: Any) -> List[SourceResult]:
        return [raw_result] if isinstance(raw_result, SourceResult) else []

    async def save(self, db, results: List[SourceResult]) -> int:
        saved = 0

        for r in results:
            await db.exposed_services.update_one(
                {
                    "ip": r.metadata["ip"],
                    "port": r.metadata["port"],
                    "source_name": self.name,
                },
                {
                    "$set": {
                        "ip": r.metadata["ip"],
                        "port": r.metadata["port"],
                        "protocol": r.metadata.get("protocol"),
                        "service_name": r.metadata.get("service_name"),
                        "product": r.metadata.get("product"),
                        "version": r.metadata.get("version"),
                        "source_name": self.name,
                        "source_type": self.source_type,
                        "scan_id": r.scan_id,
                        "organization_id": r.organization_id,
                        "severity": r.severity,
                        "confidence": r.confidence,
                        "collected_at": r.collected_at,
                        "last_seen": r.collected_at,
                        "status": "open",
                    },
                    "$setOnInsert": {
                        "first_seen": r.collected_at,
                    },
                },
                upsert=True,
            )
            saved += 1

        return saved

    async def healthcheck(self) -> dict:
        try:
            proc = await asyncio.create_subprocess_exec(
                "nmap",
                "--version",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            await proc.communicate()
            available = proc.returncode == 0
        except Exception:
            available = False

        return {
            "source": self.name,
            "status": "available" if available else "unavailable",
            "type": self.source_type,
            "enabled": settings.NMAP_ENABLED,
        }

    def _calc_sev(self, port: int) -> int:
        return {
            21: 65,
            23: 80,
            445: 75,
            3389: 80,
            5900: 75,
            1433: 70,
            3306: 70,
        }.get(port, 35)
