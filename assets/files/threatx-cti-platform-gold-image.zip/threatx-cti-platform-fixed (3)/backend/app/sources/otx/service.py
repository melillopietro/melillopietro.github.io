from datetime import datetime
from typing import Any, List
import httpx

from ..base import BaseSource, SourceResult


class AlienVaultOTXSource(BaseSource):
    name = "AlienVaultOTX"
    source_type = "passive_dns"

    async def validate_config(self, config: dict) -> bool:
        return bool(config.get("api_key"))

    async def run(self, input_context: dict) -> List[SourceResult]:
        api_key = input_context.get("api_key")
        base_url = (input_context.get("base_url") or "https://otx.alienvault.com/api").rstrip("/")
        domains = input_context.get("domains", [])
        org_id = input_context.get("organization_id", "")
        scan_id = input_context.get("scan_id", "")
        log = input_context.get("log")

        async def vlog(message: str, level: str = "info"):
            if callable(log):
                try:
                    await log(message, level)
                except Exception:
                    pass

        if not api_key:
            await vlog("AlienVault OTX skipped: API key not configured", "warning")
            return []

        results: List[SourceResult] = []

        async with httpx.AsyncClient(timeout=25) as client:
            for domain in domains:
                url = f"{base_url}/v1/indicators/domain/{domain}/passive_dns"
                await vlog(f"AlienVault OTX passive DNS query: {domain}", "info")

                response = await client.get(
                    url,
                    headers={
                        "X-OTX-API-KEY": api_key,
                        "User-Agent": "ThreatX-CTI-Platform/1.0",
                    },
                )

                if response.status_code != 200:
                    await vlog(f"AlienVault OTX returned HTTP {response.status_code} for {domain}", "warning")
                    continue

                data = response.json()
                records = data.get("passive_dns", []) or data.get("data", []) or []

                for record in records:
                    hostname = (
                        record.get("hostname")
                        or record.get("indicator")
                        or record.get("address")
                        or ""
                    )

                    address = record.get("address") or record.get("ip") or ""

                    if not hostname or domain.lower() not in hostname.lower():
                        continue

                    hostname = hostname.lower().strip(".")

                    results.append(
                        SourceResult(
                            source_name=self.name,
                            source_type=self.source_type,
                            collected_at=datetime.utcnow(),
                            confidence=0.75,
                            severity=20,
                            tags=["otx", "passive_dns", "subdomain"],
                            raw_response=record,
                            normalized_entity_type="subdomain",
                            normalized_value=hostname,
                            organization_id=org_id,
                            scan_id=scan_id,
                            metadata={
                                "domain": domain,
                                "subdomain": hostname,
                                "resolved_ips": [address] if address else [],
                                "source": "alienvault_otx",
                            },
                        )
                    )

        await vlog(f"AlienVault OTX returned {len(results)} passive DNS candidates", "info")
        return results

    def normalize(self, raw_result: Any) -> List[SourceResult]:
        return [raw_result] if isinstance(raw_result, SourceResult) else []

    async def save(self, db, results: List[SourceResult]) -> int:
        saved = 0

        for r in results:
            subdomain = r.metadata.get("subdomain")
            if not subdomain:
                continue

            await db.assets_subdomains.update_one(
                {"subdomain": subdomain, "source_name": self.name},
                {
                    "$set": {
                        "subdomain": subdomain,
                        "domain": r.metadata.get("domain"),
                        "resolved_ips": r.metadata.get("resolved_ips", []),
                        "source_name": self.name,
                        "scan_id": r.scan_id,
                        "organization_id": r.organization_id,
                        "last_seen": r.collected_at,
                    },
                    "$setOnInsert": {
                        "first_seen": r.collected_at,
                    },
                },
                upsert=True,
            )

            for ip in r.metadata.get("resolved_ips", []):
                if not ip:
                    continue

                await db.assets_ips.update_one(
                    {"ip": ip},
                    {
                        "$set": {
                            "ip": ip,
                            "source_name": self.name,
                            "scan_id": r.scan_id,
                            "organization_id": r.organization_id,
                            "last_seen": r.collected_at,
                        },
                        "$setOnInsert": {
                            "first_seen": r.collected_at,
                        },
                    },
                    upsert=True,
                )

            saved += 1

        return saved

    async def healthcheck(self) -> dict:
        return {
            "source": self.name,
            "status": "available",
            "type": self.source_type,
            "enabled": True,
        }
