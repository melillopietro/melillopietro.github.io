from typing import Optional, Tuple
from app.integrations.service import get_enabled_credential, skipped_provider


async def optional_provider(db, provider: str) -> Tuple[Optional[dict], Optional[dict]]:
    """
    Helper for scan runners.

    Usage:

        credential, skipped = await optional_provider(db, "intelx")
        if skipped:
            results["intelx"] = skipped
        else:
            results["intelx"] = await run_intelx_scan(target, credential)

    This prevents missing API keys from failing the whole scan.
    """
    credential = await get_enabled_credential(db, provider)

    if not credential:
        return None, skipped_provider(provider)

    return credential, None
