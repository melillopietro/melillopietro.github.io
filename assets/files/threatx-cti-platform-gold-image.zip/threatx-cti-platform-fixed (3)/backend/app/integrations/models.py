from typing import Optional, Literal
from pydantic import BaseModel, Field

IntegrationStatus = Literal['not_configured', 'untested', 'ok', 'failed']


class IntegrationUpdate(BaseModel):
    api_key: Optional[str] = Field(default=None)
    base_url: Optional[str] = Field(default=None)
    enabled: bool = True


class IntegrationTestResponse(BaseModel):
    provider: str
    ok: bool
    status: IntegrationStatus
    message: str
    status_code: Optional[int] = None


class IntegrationResponse(BaseModel):
    provider: str
    display_name: str
    base_url: Optional[str] = None
    enabled: bool = False
    configured: bool = False
    last_test_status: IntegrationStatus = 'not_configured'
    last_test_message: Optional[str] = None
    last_test_at: Optional[str] = None
