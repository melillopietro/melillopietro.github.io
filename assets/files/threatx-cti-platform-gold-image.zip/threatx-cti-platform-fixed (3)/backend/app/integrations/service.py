from datetime import datetime
from typing import Optional, Dict, Any
import httpx

from app.core.security import encrypt_api_key, decrypt_api_key


PROVIDERS = {
    "intelx": {
        "display_name": "Intelligence X",
        "default_base_url": "https://free.intelx.io",
        "requires_api_key": True,
    },
    "shodan": {
        "display_name": "Shodan",
        "default_base_url": "https://api.shodan.io",
        "requires_api_key": True,
    },
    "hibp": {
        "display_name": "Have I Been Pwned",
        "default_base_url": "https://haveibeenpwned.com/api/v3",
        "requires_api_key": True,
    },
    "otx": {
        "display_name": "AlienVault OTX",
        "default_base_url": "https://otx.alienvault.com/api/v1",
        "requires_api_key": True,
    },
}


def now_iso() -> str:
    return datetime.utcnow().isoformat()


def _profile_source(profile: Optional[dict], provider: str) -> dict:
    if not profile:
        return {}
    return (profile.get("api_sources") or {}).get(provider, {}) or {}


async def _get_profile(db) -> Optional[dict]:
    return await db.organization_profile.find_one({})


async def list_integrations(db) -> list[dict]:
    profile = await _get_profile(db)
    result = []

    for provider, meta in PROVIDERS.items():
        existing = await db.api_credentials.find_one({"provider": provider})
        src = _profile_source(profile, provider)
        encrypted = src.get("api_key_encrypted") or (existing or {}).get("encrypted_api_key")
        base_url = src.get("base_url") or (existing or {}).get("base_url") or meta["default_base_url"]
        enabled = bool(src.get("enabled", (existing or {}).get("enabled", False)))

        result.append({
            "provider": provider,
            "display_name": meta["display_name"],
            "base_url": base_url,
            "enabled": enabled,
            "configured": bool(encrypted),
            "last_test_status": src.get("last_test_status") or (existing or {}).get("last_test_status", "not_configured"),
            "last_test_message": src.get("last_test_message") or (existing or {}).get("last_test_message"),
            "last_test_at": src.get("last_test_at") or (existing or {}).get("last_test_at"),
        })

    return result


async def upsert_integration(
    db,
    provider: str,
    api_key: Optional[str],
    base_url: Optional[str],
    enabled: bool,
) -> dict:
    if provider not in PROVIDERS:
        raise ValueError(f"Unsupported provider: {provider}")

    meta = PROVIDERS[provider]
    final_base_url = base_url or meta["default_base_url"]

    update: Dict[str, Any] = {
        "provider": provider,
        "display_name": meta["display_name"],
        "base_url": final_base_url,
        "enabled": enabled,
        "updated_at": now_iso(),
    }

    profile_set: Dict[str, Any] = {
        f"api_sources.{provider}.enabled": enabled,
        f"api_sources.{provider}.base_url": final_base_url,
        f"api_sources.{provider}.status": "configured" if api_key else "not_configured",
        f"api_sources.{provider}.updated_at": datetime.utcnow(),
    }

    if api_key is not None and api_key.strip():
        encrypted = encrypt_api_key(api_key.strip())
        update["encrypted_api_key"] = encrypted
        update["last_test_status"] = "untested"
        update["last_test_message"] = "API key saved but not tested yet."
        profile_set[f"api_sources.{provider}.api_key_encrypted"] = encrypted
        profile_set[f"api_sources.{provider}.last_test_status"] = "untested"
        profile_set[f"api_sources.{provider}.last_test_message"] = "API key saved but not tested yet."
        profile_set[f"api_sources.{provider}.configured_at"] = datetime.utcnow()

    await db.api_credentials.update_one(
        {"provider": provider},
        {"$set": update, "$setOnInsert": {"created_at": now_iso()}},
        upsert=True,
    )

    await db.organization_profile.update_one(
        {},
        {"$set": profile_set, "$setOnInsert": {"created_at": datetime.utcnow()}},
        upsert=True,
    )

    return (await list_integrations(db))[list(PROVIDERS.keys()).index(provider)]


async def delete_integration(db, provider: str) -> None:
    await db.api_credentials.delete_one({"provider": provider})
    await db.organization_profile.update_one({}, {"$unset": {f"api_sources.{provider}": ""}})


async def get_enabled_credential(db, provider: str) -> Optional[dict]:
    if provider not in PROVIDERS:
        return None

    profile = await _get_profile(db)
    src = _profile_source(profile, provider)
    encrypted = src.get("api_key_encrypted")
    base_url = src.get("base_url") or PROVIDERS[provider]["default_base_url"]
    enabled = src.get("enabled")

    if encrypted is None:
        credential = await db.api_credentials.find_one({"provider": provider, "enabled": True})
        if credential:
            encrypted = credential.get("encrypted_api_key")
            base_url = credential.get("base_url") or base_url
            enabled = credential.get("enabled")

    if not enabled or not encrypted:
        return None

    return {
        "provider": provider,
        "api_key": decrypt_api_key(encrypted),
        "base_url": base_url,
    }


def skipped_provider(provider: str, reason: Optional[str] = None) -> dict:
    return {
        "provider": provider,
        "status": "skipped",
        "reason": reason or f"{provider} API key not configured or provider disabled.",
    }


async def test_integration(db, provider: str) -> dict:
    if provider not in PROVIDERS:
        raise ValueError(f"Unsupported provider: {provider}")

    cred = await get_enabled_credential(db, provider)

    if not cred:
        return {
            "provider": provider,
            "ok": False,
            "status": "not_configured",
            "message": "API key not configured. The platform can still work without this provider.",
            "status_code": None,
        }

    api_key = cred["api_key"]
    base_url = cred["base_url"]

    if provider == "intelx":
        result = await _test_intelx(api_key, base_url)
    elif provider == "shodan":
        result = await _test_shodan(api_key, base_url)
    elif provider == "hibp":
        result = await _test_hibp(api_key, base_url)
    elif provider == "otx":
        result = await _test_otx(api_key, base_url)
    else:
        result = {"ok": False, "message": "Provider test not implemented.", "status_code": None}

    status = "ok" if result["ok"] else "failed"

    await db.api_credentials.update_one(
        {"provider": provider},
        {"$set": {"last_test_status": status, "last_test_message": result["message"], "last_test_at": now_iso(), "updated_at": now_iso()}},
        upsert=True,
    )
    await db.organization_profile.update_one(
        {},
        {"$set": {
            f"api_sources.{provider}.last_test_status": status,
            f"api_sources.{provider}.last_test_message": result["message"],
            f"api_sources.{provider}.last_test_at": datetime.utcnow(),
        }},
        upsert=True,
    )

    return {"provider": provider, "ok": result["ok"], "status": status, "message": result["message"], "status_code": result.get("status_code")}


async def _test_intelx(api_key: str, base_url: str) -> dict:
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            response = await client.get(base_url.rstrip("/") + "/", headers={"x-key": api_key, "User-Agent": "ThreatX-CTI-Platform/1.0"})
        if response.status_code in [200, 204, 400, 404]:
            return {"ok": True, "message": f"IntelX endpoint reachable at {base_url}.", "status_code": response.status_code}
        return {"ok": False, "message": f"IntelX API test failed: HTTP {response.status_code}.", "status_code": response.status_code}
    except Exception as exc:
        return {"ok": False, "message": f"IntelX connection failed: {exc}", "status_code": None}


async def _test_shodan(api_key: str, base_url: str) -> dict:
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            response = await client.get(base_url.rstrip("/") + f"/api-info?key={api_key}")
        return {"ok": response.status_code == 200, "message": "Shodan API key valid." if response.status_code == 200 else f"Shodan API test failed: HTTP {response.status_code}.", "status_code": response.status_code}
    except Exception as exc:
        return {"ok": False, "message": f"Shodan connection failed: {exc}", "status_code": None}


async def _test_hibp(api_key: str, base_url: str) -> dict:
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            response = await client.get(base_url.rstrip("/") + "/breaches", headers={"hibp-api-key": api_key, "user-agent": "ThreatX-CTI-Platform"})
        return {"ok": response.status_code == 200, "message": "HIBP API reachable." if response.status_code == 200 else f"HIBP API test failed: HTTP {response.status_code}.", "status_code": response.status_code}
    except Exception as exc:
        return {"ok": False, "message": f"HIBP connection failed: {exc}", "status_code": None}


async def _test_otx(api_key: str, base_url: str) -> dict:
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            response = await client.get(
                base_url.rstrip("/") + "/indicators/domain/example.com/general",
                headers={"X-OTX-API-KEY": api_key, "User-Agent": "ThreatX-CTI-Platform/1.0"},
            )
        return {"ok": response.status_code == 200, "message": "AlienVault OTX API key valid." if response.status_code == 200 else f"AlienVault OTX API test failed: HTTP {response.status_code}.", "status_code": response.status_code}
    except Exception as exc:
        return {"ok": False, "message": f"AlienVault OTX connection failed: {exc}", "status_code": None}
