from fastapi import APIRouter, Depends, HTTPException
from bson import ObjectId
from bson.errors import InvalidId

from app.core.database import get_client, get_core_db, get_org_db
from app.core.tenant import get_current_user
from .models import IntegrationUpdate
from .service import list_integrations, upsert_integration, delete_integration, test_integration

router = APIRouter()


def _validate_oid(value: str) -> ObjectId:
    try:
        return ObjectId(value)
    except (InvalidId, Exception):
        raise HTTPException(status_code=400, detail="Invalid organization ID")


async def _get_org_db_for_user(org_id: str, user: dict):
    client = await get_client()
    core_db = get_core_db(client)
    user_id = str(user["_id"])
    _validate_oid(org_id)

    membership = await core_db.memberships.find_one({"user_id": user_id, "organization_id": org_id})
    if not membership:
        raise HTTPException(status_code=403, detail="Access denied")

    org = await core_db.organizations.find_one({"_id": ObjectId(org_id)})
    if not org:
        raise HTTPException(status_code=404, detail="Organization not found")

    return get_org_db(client, org["slug"])


@router.get("")
async def get_integrations(org_id: str, current_user=Depends(get_current_user)):
    db = await _get_org_db_for_user(org_id, current_user)
    return await list_integrations(db, org_id)


@router.put("/{provider}")
async def update_integration(org_id: str, provider: str, payload: IntegrationUpdate, current_user=Depends(get_current_user)):
    db = await _get_org_db_for_user(org_id, current_user)
    try:
        return await upsert_integration(
            db=db,
            org_id=org_id,
            provider=provider,
            api_key=payload.api_key,
            base_url=payload.base_url,
            enabled=payload.enabled,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.post("/{provider}/test")
async def test_provider_integration(org_id: str, provider: str, current_user=Depends(get_current_user)):
    db = await _get_org_db_for_user(org_id, current_user)
    try:
        return await test_integration(db, org_id, provider)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.delete("/{provider}")
async def remove_integration(org_id: str, provider: str, current_user=Depends(get_current_user)):
    db = await _get_org_db_for_user(org_id, current_user)
    await delete_integration(db, org_id, provider)
    return {"message": "Integration removed", "provider": provider}
