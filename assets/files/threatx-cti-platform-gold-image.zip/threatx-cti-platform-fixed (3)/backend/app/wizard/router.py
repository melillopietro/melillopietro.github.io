from fastapi import APIRouter, HTTPException, Depends
from .schemas import WizardComplete, ApiKeyTest
from .service import complete_wizard, test_api_key
from ..core.database import get_client, get_core_db
from ..core.tenant import get_current_user

router = APIRouter(prefix='/api/wizard', tags=['wizard'])


@router.post('/complete')
async def wizard_complete(wizard_data: WizardComplete, user: dict = Depends(get_current_user)):
    if not wizard_data.step5.authorization_confirmed:
        raise HTTPException(status_code=400, detail='Authorization confirmation is required')
    client = await get_client()
    core_db = get_core_db(client)
    return await complete_wizard(core_db, client, wizard_data, str(user['_id']))


@router.post('/test-api-key')
async def test_api(data: ApiKeyTest, user: dict = Depends(get_current_user)):
    return await test_api_key(data.source_name, data.api_key, data.base_url)
