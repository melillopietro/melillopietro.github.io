from datetime import datetime
from ..core.security import encrypt_api_key
from ..core.database import get_org_db
from ..core.logging import logger
from ..organizations.service import create_organization
from ..organizations.models import OrgCreate
from .schemas import WizardComplete
import httpx


DEFAULT_BASE_URLS = {
    'hibp': 'https://haveibeenpwned.com/api/v3',
    'shodan': 'https://api.shodan.io',
    'intelx': 'https://free.intelx.io',
}


async def complete_wizard(core_db, client, wizard_data: WizardComplete, user_id: str) -> dict:
    sector_val = wizard_data.step1.sector if wizard_data.step1.sector else None
    size_val = wizard_data.step1.size if wizard_data.step1.size else None
    country_val = wizard_data.step1.country if wizard_data.step1.country else None

    org_data = OrgCreate(
        name=wizard_data.step1.name,
        description=wizard_data.step1.description or None,
        sector=sector_val,
        country=country_val,
        size=size_val,
        primary_domain=wizard_data.step1.primary_domain,
        security_contacts=wizard_data.step1.security_contacts or [],
    )
    org = await create_organization(core_db, client, org_data, user_id)
    org_id = str(org['_id'])
    org_db = get_org_db(client, org['slug'])

    domains = wizard_data.step2.domains if wizard_data.step2.domains else [wizard_data.step1.primary_domain]

    await org_db.organization_profile.update_one(
        {'organization_id': org_id},
        {'$set': {
            'domains': domains,
            'subdomains': wizard_data.step2.subdomains,
            'ips': wizard_data.step2.ips,
            'cidrs': wizard_data.step2.cidrs,
            'keywords': wizard_data.step2.keywords,
            'brand_keywords': wizard_data.step2.brand_keywords,
            'executive_keywords': wizard_data.step2.executive_keywords,
            'technologies': wizard_data.step2.technologies,
            'email_domains': wizard_data.step2.email_domains or [wizard_data.step1.primary_domain],
        }},
    )

    source_configs = [
        ('hibp', wizard_data.step3.hibp_api_key, wizard_data.step3.hibp_enabled, wizard_data.step3.hibp_base_url),
        ('shodan', wizard_data.step3.shodan_api_key, wizard_data.step3.shodan_enabled, wizard_data.step3.shodan_base_url),
        ('intelx', wizard_data.step3.intelx_api_key, wizard_data.step3.intelx_enabled, wizard_data.step3.intelx_base_url),
    ]

    api_sources = {}
    for source_name, api_key, enabled, base_url in source_configs:
        api_sources[source_name] = {
            'enabled': bool(enabled),
            'base_url': base_url or DEFAULT_BASE_URLS[source_name],
            'status': 'not_configured',
            'last_test_status': 'not_configured',
        }
        if api_key and enabled:
            api_sources[source_name].update({
                'api_key_encrypted': encrypt_api_key(api_key),
                'status': 'configured',
                'last_test_status': 'untested',
                'configured_at': datetime.utcnow(),
            })

    scan_policy = {
        'scan_type': wizard_data.step5.scan_type.value,
        'nmap_enabled': wizard_data.step5.nmap_enabled,
        'shodan_enabled': wizard_data.step5.shodan_enabled,
        'hibp_enabled': wizard_data.step5.hibp_enabled,
        'intelx_enabled': wizard_data.step5.intelx_enabled,
        'scan_frequency': wizard_data.step5.scan_frequency,
        'authorization_confirmed': wizard_data.step5.authorization_confirmed,
    }

    await org_db.organization_profile.update_one(
        {'organization_id': org_id},
        {'$set': {
            'api_sources': api_sources,
            'scan_policy': scan_policy,
            'authorization_confirmed': wizard_data.step5.authorization_confirmed,
        }},
    )

    for domain in domains:
        await org_db.assets_domains.update_one(
            {'domain': domain},
            {'$setOnInsert': {
                'domain': domain,
                'organization_id': org_id,
                'source_name': 'manual',
                'source_type': 'manual',
                'added_at': datetime.utcnow(),
                'status': 'active',
            }},
            upsert=True,
        )

    for ip in wizard_data.step2.ips:
        await org_db.assets_ips.update_one(
            {'ip': ip},
            {'$setOnInsert': {
                'ip': ip,
                'organization_id': org_id,
                'source_name': 'manual',
                'source_type': 'manual',
                'added_at': datetime.utcnow(),
                'status': 'active',
            }},
            upsert=True,
        )

    logger.info(f"Wizard completed for org '{org_data.name}' (id={org_id}) by user {user_id}")

    return {
        'organization_id': org_id,
        'slug': org['slug'],
        'message': 'Organization configured successfully',
        'start_scan': wizard_data.start_scan,
    }


async def test_api_key(source_name: str, api_key: str, base_url: str | None = None) -> dict:
    try:
        async with httpx.AsyncClient(timeout=10) as http_client:
            if source_name == 'hibp':
                base = (base_url or DEFAULT_BASE_URLS['hibp']).rstrip('/')
                resp = await http_client.get(
                    f'{base}/subscription/status',
                    headers={'hibp-api-key': api_key, 'user-agent': 'ThreatX-CTI'},
                )
                return {'status': 'ok' if resp.status_code == 200 else 'invalid', 'message': f'HTTP {resp.status_code}'}

            if source_name == 'shodan':
                base = (base_url or DEFAULT_BASE_URLS['shodan']).rstrip('/')
                resp = await http_client.get(f'{base}/api-info?key={api_key}')
                return {'status': 'ok' if resp.status_code == 200 else 'invalid', 'message': f'HTTP {resp.status_code}'}

            if source_name == 'intelx':
                base = (base_url or DEFAULT_BASE_URLS['intelx']).rstrip('/')
                resp = await http_client.get(f'{base}/authenticate/info', headers={'x-key': api_key})
                if resp.status_code in (200, 204):
                    return {'status': 'ok', 'message': f'HTTP {resp.status_code}'}
                if resp.status_code in (400, 404):
                    return {'status': 'ok', 'message': f'Endpoint reachable: HTTP {resp.status_code}'}
                return {'status': 'invalid', 'message': f'HTTP {resp.status_code}'}

        return {'status': 'unknown', 'message': f'Unknown source: {source_name}'}
    except Exception as exc:
        return {'status': 'error', 'message': str(exc)}
