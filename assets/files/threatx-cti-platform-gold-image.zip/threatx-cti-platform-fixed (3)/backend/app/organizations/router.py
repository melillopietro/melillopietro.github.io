from fastapi import APIRouter, HTTPException, Depends
from typing import List
from bson import ObjectId
from bson.errors import InvalidId
from datetime import datetime

from .models import OrgCreate, OrgResponse
from .service import create_organization, get_user_organizations, select_organization
from ..core.database import get_client, get_core_db, get_org_db
from ..core.tenant import get_current_user

router = APIRouter(prefix="/api/orgs", tags=["organizations"])


def _validate_oid(value: str) -> ObjectId:
    try:
        return ObjectId(value)
    except (InvalidId, Exception):
        raise HTTPException(status_code=400, detail="Invalid ID")


def _org_response(org: dict) -> OrgResponse:
    return OrgResponse(
        id=str(org["_id"]),
        name=org["name"],
        slug=org["slug"],
        description=org.get("description"),
        sector=org.get("sector"),
        country=org.get("country"),
        size=org.get("size"),
        primary_domain=org["primary_domain"],
        security_contacts=org.get("security_contacts", []),
        created_at=org["created_at"],
        is_active=org.get("is_active", True),
    )


async def _require_membership(core_db, user_id: str, org_id: str) -> dict:
    membership = await core_db.memberships.find_one({"user_id": user_id, "organization_id": org_id})
    if not membership:
        raise HTTPException(status_code=403, detail="Access denied")
    return membership


async def _get_org(core_db, org_id: str) -> dict:
    oid = _validate_oid(org_id)
    org = await core_db.organizations.find_one({"_id": oid})
    if not org:
        raise HTTPException(status_code=404, detail="Organization not found")
    return org


@router.post("", response_model=OrgResponse)
async def create_org(org_data: OrgCreate, user: dict = Depends(get_current_user)):
    client = await get_client()
    core_db = get_core_db(client)
    org = await create_organization(core_db, client, org_data, str(user["_id"]))
    return _org_response(org)


@router.get("", response_model=List[OrgResponse])
async def list_orgs(user: dict = Depends(get_current_user)):
    client = await get_client()
    core_db = get_core_db(client)
    orgs = await get_user_organizations(core_db, str(user["_id"]))
    return [_org_response(o) for o in orgs]


@router.get("/{org_id}", response_model=OrgResponse)
async def get_org(org_id: str, user: dict = Depends(get_current_user)):
    client = await get_client()
    core_db = get_core_db(client)
    await _require_membership(core_db, str(user["_id"]), org_id)
    org = await _get_org(core_db, org_id)
    return _org_response(org)


@router.post("/{org_id}/select")
async def select_org(org_id: str, user: dict = Depends(get_current_user)):
    client = await get_client()
    core_db = get_core_db(client)
    _validate_oid(org_id)
    try:
        await select_organization(core_db, str(user["_id"]), org_id)
    except ValueError as e:
        raise HTTPException(status_code=403, detail=str(e))
    return {"message": "Organization selected", "organization_id": org_id, "active_organization_id": org_id}


@router.delete("/{org_id}")
async def delete_org(org_id: str, user: dict = Depends(get_current_user)):
    client = await get_client()
    core_db = get_core_db(client)
    user_id = str(user["_id"])

    membership = await _require_membership(core_db, user_id, org_id)
    org = await _get_org(core_db, org_id)

    if membership.get("role") not in ("admin", "owner") and str(org.get("created_by")) != user_id:
        raise HTTPException(status_code=403, detail="Only organization admins can delete this organization")

    # Drop only the selected organization's tenant DB.
    org_db = get_org_db(client, org["slug"])
    await client.drop_database(org_db.name)

    # Remove only the selected organization and memberships.
    await core_db.organizations.delete_one({"_id": ObjectId(org_id)})
    await core_db.memberships.delete_many({"organization_id": org_id})
    await core_db.audit_logs.insert_one({
        "action": "organization_deleted",
        "user_id": user_id,
        "organization_id": org_id,
        "timestamp": datetime.utcnow(),
    })

    # Select another organization for the same user if available.
    remaining = await core_db.memberships.find({"user_id": user_id}).to_list(100)
    next_active_org_id = remaining[0]["organization_id"] if remaining else None
    await core_db.users.update_one(
        {"_id": ObjectId(user_id)},
        {"$set": {"active_organization_id": next_active_org_id, "updated_at": datetime.utcnow()}},
    )

    return {
        "message": "Organization deleted",
        "deleted_organization_id": org_id,
        "next_active_org_id": next_active_org_id,
    }
