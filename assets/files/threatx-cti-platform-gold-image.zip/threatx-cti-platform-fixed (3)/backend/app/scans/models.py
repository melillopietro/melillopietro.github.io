from pydantic import BaseModel
from enum import Enum


class ScanStatus(str, Enum):
    PENDING = 'pending'
    RUNNING = 'running'
    CANCELLING = 'cancelling'
    CANCELLED = 'cancelled'
    COMPLETED = 'completed'
    FAILED = 'failed'


class ScanCreate(BaseModel):
    scan_type: str = 'light'
