from fastapi import APIRouter, HTTPException, Depends
from bson import ObjectId
from datetime import datetime

from .orchestrator import ScanOrchestrator
from ..core.database import get_client, get_core_db, get_org_db
from ..core.tenant import get_current_user


router = APIRouter(prefix="/api/orgs/{org_id}/scans", tags=["scans"])


async def _get_org_and_db(org_id: str, user: dict):
    client = await get_client()
    core_db = get_core_db(client)

    membership = await core_db.memberships.find_one({
        "user_id": str(user["_id"]),
        "organization_id": org_id,
    })

    if not membership:
        raise HTTPException(status_code=403, detail="Access denied")

    org = await core_db.organizations.find_one({"_id": ObjectId(org_id)})

    if not org:
        raise HTTPException(status_code=404, detail="Organization not found")

    org_db = get_org_db(client, org["slug"])
    return client, core_db, org, org_db


def _serialize_scan(scan: dict, include_logs: bool = False):
    data = {
        "id": str(scan["_id"]),
        "scan_type": scan.get("scan_type"),
        "status": scan.get("status"),
        "steps": scan.get("steps", []),
        "created_at": scan["created_at"].isoformat() if scan.get("created_at") else None,
        "started_at": scan["started_at"].isoformat() if scan.get("started_at") else None,
        "completed_at": scan["completed_at"].isoformat() if scan.get("completed_at") else None,
        "total_findings": scan.get("total_findings", 0),
        "progress": scan.get("progress", 0),
        "completed_steps": scan.get("completed_steps"),
        "total_steps": scan.get("total_steps"),
    }

    if include_logs:
        logs = scan.get("logs", [])[-500:]
        data["logs"] = [
            {
                "timestamp": l.get("timestamp").isoformat() if l.get("timestamp") else None,
                "level": l.get("level"),
                "step": l.get("step"),
                "message": l.get("message"),
            }
            for l in logs
        ]

    return data


@router.post("/start")
async def start_scan(org_id: str, user: dict = Depends(get_current_user)):
    client, core_db, org, org_db = await _get_org_and_db(org_id, user)

    orchestrator = ScanOrchestrator()

    try:
        scan_id = await orchestrator.start_scan(org_id, org["slug"])
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    await core_db.audit_logs.insert_one({
        "action": "scan_started",
        "user_id": str(user["_id"]),
        "organization_id": org_id,
        "scan_id": scan_id,
        "timestamp": datetime.utcnow(),
    })

    return {
        "scan_id": scan_id,
        "status": "running",
    }


@router.get("")
async def list_scans(org_id: str, user: dict = Depends(get_current_user)):
    client, core_db, org, org_db = await _get_org_and_db(org_id, user)

    scans = await org_db.scan_jobs.find().sort("created_at", -1).limit(50).to_list(50)

    return [_serialize_scan(scan, include_logs=False) for scan in scans]


@router.get("/{scan_id}")
async def get_scan(org_id: str, scan_id: str, user: dict = Depends(get_current_user)):
    client, core_db, org, org_db = await _get_org_and_db(org_id, user)

    if not ObjectId.is_valid(scan_id):
        raise HTTPException(status_code=400, detail="Invalid scan id")

    scan = await org_db.scan_jobs.find_one({"_id": ObjectId(scan_id)})

    if not scan:
        raise HTTPException(status_code=404, detail="Scan not found")

    return _serialize_scan(scan, include_logs=True)


@router.get("/{scan_id}/logs")
async def get_scan_logs(org_id: str, scan_id: str, user: dict = Depends(get_current_user)):
    client, core_db, org, org_db = await _get_org_and_db(org_id, user)

    if not ObjectId.is_valid(scan_id):
        raise HTTPException(status_code=400, detail="Invalid scan id")

    scan = await org_db.scan_jobs.find_one({"_id": ObjectId(scan_id)}, {"logs": 1})

    if not scan:
        raise HTTPException(status_code=404, detail="Scan not found")

    logs = scan.get("logs", [])[-500:]

    return {
        "scan_id": scan_id,
        "logs": [
            {
                "timestamp": l.get("timestamp").isoformat() if l.get("timestamp") else None,
                "level": l.get("level"),
                "step": l.get("step"),
                "message": l.get("message"),
            }
            for l in logs
        ],
    }


@router.post("/{scan_id}/cancel")
async def cancel_scan(org_id: str, scan_id: str, user: dict = Depends(get_current_user)):
    client, core_db, org, org_db = await _get_org_and_db(org_id, user)

    if not ObjectId.is_valid(scan_id):
        raise HTTPException(status_code=400, detail="Invalid scan id")

    result = await org_db.scan_jobs.update_one(
        {
            "_id": ObjectId(scan_id),
            "status": {"$in": ["pending", "running"]},
        },
        {
            "$set": {
                "status": "cancelling",
                "cancel_requested": True,
                "updated_at": datetime.utcnow(),
            },
            "$push": {
                "logs": {
                    "timestamp": datetime.utcnow(),
                    "level": "warning",
                    "step": None,
                    "message": "Cancellation requested by user",
                }
            },
        },
    )

    if result.modified_count == 0:
        raise HTTPException(status_code=400, detail="Scan not found or not cancellable")

    return {
        "scan_id": scan_id,
        "status": "cancelling",
    }


@router.delete("/{scan_id}")
async def delete_scan(org_id: str, scan_id: str, user: dict = Depends(get_current_user)):
    client, core_db, org, org_db = await _get_org_and_db(org_id, user)

    if not ObjectId.is_valid(scan_id):
        raise HTTPException(status_code=400, detail="Invalid scan id")

    result = await org_db.scan_jobs.delete_one({"_id": ObjectId(scan_id)})

    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Scan not found")

    return {
        "scan_id": scan_id,
        "deleted": True,
    }
