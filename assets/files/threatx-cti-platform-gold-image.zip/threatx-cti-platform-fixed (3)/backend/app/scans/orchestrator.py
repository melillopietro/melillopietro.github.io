import asyncio
from datetime import datetime
from bson import ObjectId

from ..core.database import get_client, get_org_db
from ..core.security import decrypt_api_key
from ..core.logging import logger
from ..sources.registry import SourceRegistry


class ScanOrchestrator:
    PIPELINE = [
        {"name": "Subdomain Discovery", "source_name": "SubdomainFinder", "key": "subdomain"},
        {"name": "DNS Resolution", "source_name": "DNSResolver", "key": "dns"},
        {"name": "WHOIS Lookup", "source_name": "WHOIS", "key": "whois"},
        {"name": "Shodan Enrichment", "source_name": "Shodan", "key": "shodan"},
        {"name": "HIBP Breach Check", "source_name": "HIBP", "key": "hibp"},
        {"name": "IntelX Intelligence", "source_name": "IntelX", "key": "intelx"},
        {"name": "AlienVault OTX Passive DNS", "source_name": "AlienVaultOTX", "key": "otx"},
        {"name": "Nmap Active Scan", "source_name": "Nmap", "key": "nmap"},
    ]

    async def start_scan(self, org_id: str, org_slug: str, scan_type: str = "light") -> str:
        client = await get_client()
        org_db = get_org_db(client, org_slug)

        profile = await org_db.organization_profile.find_one({"organization_id": org_id})
        if not profile:
            raise ValueError("Organization profile not found")

        scan_policy = profile.get("scan_policy", {})
        api_sources = profile.get("api_sources", {})

        steps = []

        for s in self.PIPELINE:
            k = s["key"]
            skip = False
            skip_reason = None

            if k in ("shodan", "hibp", "intelx", "otx"):
                src = api_sources.get(k, {})
                if not src.get("api_key_encrypted") or src.get("enabled") is False:
                    skip = True
                    skip_reason = "API key not configured or provider disabled"

            if k == "nmap":
                if not scan_policy.get("nmap_enabled") or not profile.get("authorization_confirmed"):
                    skip = True
                    skip_reason = "Nmap disabled or authorization not confirmed"

            steps.append({
                "name": s["name"],
                "source_name": s["source_name"],
                "key": k,
                "status": "skipped" if skip else "pending",
                "started_at": None,
                "completed_at": datetime.utcnow() if skip else None,
                "error_message": skip_reason,
                "progress": 100 if skip else 0,
                "results_count": 0,
                "logs": [],
            })

        scan_doc = {
            "organization_id": org_id,
            "scan_type": scan_type,
            "status": "pending",
            "steps": steps,
            "logs": [{
                "timestamp": datetime.utcnow(),
                "level": "info",
                "message": f"Scan created. Type={scan_type}. Steps={len(steps)}",
                "step": None,
            }],
            "cancel_requested": False,
            "delete_requested": False,
            "created_at": datetime.utcnow(),
            "started_at": None,
            "completed_at": None,
            "total_findings": 0,
            "progress": 0,
        }

        result = await org_db.scan_jobs.insert_one(scan_doc)
        scan_id = str(result.inserted_id)

        asyncio.create_task(self._run_pipeline(org_id, org_slug, scan_id, profile))

        logger.info(f"Scan started: {scan_id}")
        return scan_id

    async def _log(self, org_db, scan_id: str, message: str, level: str = "info", step: str | None = None):
        event = {
            "timestamp": datetime.utcnow(),
            "level": level,
            "message": message,
            "step": step,
        }

        logger.info(f"[scan:{scan_id}] [{level}] {step or '-'} - {message}")

        await org_db.scan_jobs.update_one(
            {"_id": ObjectId(scan_id)},
            {"$push": {"logs": {"$each": [event], "$slice": -500}}},
        )

    async def _check_cancelled(self, org_db, scan_id: str):
        scan = await org_db.scan_jobs.find_one({"_id": ObjectId(scan_id)})
        if not scan:
            raise RuntimeError("Scan not found")

        if scan.get("delete_requested"):
            await self._log(org_db, scan_id, "Scan delete requested. Stopping pipeline.", "warning")
            raise asyncio.CancelledError("Scan deleted")

        if scan.get("cancel_requested"):
            await self._log(org_db, scan_id, "Scan cancellation requested. Stopping pipeline.", "warning")
            await org_db.scan_jobs.update_one(
                {"_id": ObjectId(scan_id)},
                {
                    "$set": {
                        "status": "cancelled",
                        "completed_at": datetime.utcnow(),
                        "progress": 100,
                    }
                },
            )
            raise asyncio.CancelledError("Scan cancelled")

    async def _run_pipeline(self, org_id: str, org_slug: str, scan_id: str, profile: dict):
        client = await get_client()
        org_db = get_org_db(client, org_slug)

        await org_db.scan_jobs.update_one(
            {"_id": ObjectId(scan_id)},
            {
                "$set": {
                    "status": "running",
                    "started_at": datetime.utcnow(),
                }
            },
        )

        await self._log(org_db, scan_id, "Pipeline started", "info")

        api_sources = profile.get("api_sources", {})
        domains = profile.get("domains", [])
        ips = list(profile.get("ips", []))
        keywords = profile.get("keywords", []) + profile.get("brand_keywords", [])
        email_domains = profile.get("email_domains", [])

        discovered_subs = []
        total_findings = 0

        try:
            for idx, step_def in enumerate(self.PIPELINE):
                await self._check_cancelled(org_db, scan_id)

                scan = await org_db.scan_jobs.find_one({"_id": ObjectId(scan_id)})
                step = scan["steps"][idx]

                if step.get("status") == "skipped":
                    await self._log(
                        org_db,
                        scan_id,
                        f"Step skipped: {step.get('error_message') or 'not configured'}",
                        "warning",
                        step_def["name"],
                    )
                    await self._recalc_progress(org_db, scan_id, total_findings)
                    continue

                await self._upd_step(
                    org_db,
                    scan_id,
                    idx,
                    {
                        "status": "running",
                        "started_at": datetime.utcnow(),
                        "progress": 10,
                    },
                )

                await self._log(org_db, scan_id, f"Starting step {idx + 1}/{len(self.PIPELINE)}", "info", step_def["name"])

                try:
                    source = SourceRegistry.get(step_def["source_name"])

                    if not source:
                        await self._log(org_db, scan_id, "Source not registered", "warning", step_def["name"])
                        await self._upd_step(
                            org_db,
                            scan_id,
                            idx,
                            {
                                "status": "skipped",
                                "completed_at": datetime.utcnow(),
                                "error_message": "Source not registered",
                                "progress": 100,
                            },
                        )
                        await self._recalc_progress(org_db, scan_id, total_findings)
                        continue

                    async def source_log(message: str, level: str = "info"):
                        await self._log(org_db, scan_id, message, level, step_def["name"])

                    context = {
                        "organization_id": org_id,
                        "scan_id": scan_id,
                        "domains": domains,
                        "ips": sorted(set(ips)),
                        "subdomains": discovered_subs,
                        "keywords": keywords,
                        "emails": [f"info@{d}" for d in email_domains],
                        "email_domains": email_domains,
                        "authorization_confirmed": profile.get("authorization_confirmed", False),
                        "log": source_log,
                        "scan_type": scan.get("scan_type", "light"),
                        "api_sources": api_sources,
                    }

                    k = step_def["key"]

                    if k in api_sources and api_sources[k].get("api_key_encrypted"):
                        try:
                            context["api_key"] = decrypt_api_key(api_sources[k]["api_key_encrypted"])
                            context["base_url"] = api_sources[k].get("base_url")
                        except Exception as exc:
                            await self._log(org_db, scan_id, f"Could not decrypt API key: {exc}", "error", step_def["name"])

                    results = await source.run(context)
                    results = results or []

                    await self._log(org_db, scan_id, f"Step returned {len(results)} raw results", "info", step_def["name"])

                    saved = 0
                    if results:
                        saved = await source.save(org_db, results)
                        total_findings += saved

                        if k == "subdomain":
                            for r in results:
                                sub = r.metadata.get("subdomain", "")
                                if sub:
                                    discovered_subs.append(sub)
                                ips.extend(r.metadata.get("resolved_ips", []))

                        elif k == "dns":
                            for r in results:
                                records = r.metadata.get("records", {})
                                ips.extend(records.get("A", []))

                    await self._log(
                        org_db,
                        scan_id,
                        f"Step completed. Saved={saved}. Known subdomains={len(set(discovered_subs))}. Known IPs={len(set(ips))}",
                        "info",
                        step_def["name"],
                    )

                    await self._upd_step(
                        org_db,
                        scan_id,
                        idx,
                        {
                            "status": "completed",
                            "completed_at": datetime.utcnow(),
                            "progress": 100,
                            "results_count": len(results),
                            "error_message": None,
                        },
                    )

                except asyncio.CancelledError:
                    raise

                except Exception as exc:
                    await self._log(org_db, scan_id, f"Step failed: {exc}", "error", step_def["name"])
                    logger.exception(f"Step {step_def['source_name']} failed")

                    await self._upd_step(
                        org_db,
                        scan_id,
                        idx,
                        {
                            "status": "failed",
                            "completed_at": datetime.utcnow(),
                            "progress": 100,
                            "error_message": str(exc),
                        },
                    )

                await self._recalc_progress(org_db, scan_id, total_findings)

            await self._run_risk(org_db, org_id, scan_id)

            await self._finalize(org_db, scan_id, total_findings)

        except asyncio.CancelledError:
            await self._log(org_db, scan_id, "Pipeline stopped by cancellation/delete request", "warning")

        except Exception as exc:
            await self._log(org_db, scan_id, f"Pipeline failed unexpectedly: {exc}", "error")
            logger.exception("Pipeline failed unexpectedly")
            await org_db.scan_jobs.update_one(
                {"_id": ObjectId(scan_id)},
                {
                    "$set": {
                        "status": "failed",
                        "completed_at": datetime.utcnow(),
                    }
                },
            )

    async def _run_risk(self, org_db, org_id: str, scan_id: str):
        try:
            await self._log(org_db, scan_id, "Starting risk calculation", "info", "Risk Engine")

            from ..risk.engine import RiskEngine
            engine = RiskEngine()
            await engine.calculate_risk(org_db, org_id, scan_id)

            await self._log(org_db, scan_id, "Risk calculation completed", "info", "Risk Engine")

        except Exception as exc:
            await self._log(org_db, scan_id, f"Risk calculation failed: {exc}", "error", "Risk Engine")
            logger.exception("Risk calculation failed")

    async def _finalize(self, org_db, scan_id: str, total_findings: int):
        scan = await org_db.scan_jobs.find_one({"_id": ObjectId(scan_id)})
        steps = scan.get("steps", [])

        for idx, step in enumerate(steps):
            if step.get("status") in ("pending", "running"):
                await self._upd_step(
                    org_db,
                    scan_id,
                    idx,
                    {
                        "status": "failed",
                        "completed_at": datetime.utcnow(),
                        "progress": 100,
                        "error_message": "Step did not finish before finalization",
                    },
                )

        await self._recalc_progress(org_db, scan_id, total_findings)

        await org_db.scan_jobs.update_one(
            {"_id": ObjectId(scan_id)},
            {
                "$set": {
                    "status": "completed",
                    "completed_at": datetime.utcnow(),
                    "progress": 100,
                    "total_findings": total_findings,
                }
            },
        )

        await self._log(org_db, scan_id, f"Scan completed. Total findings={total_findings}", "info")

    async def _recalc_progress(self, org_db, scan_id: str, total_findings: int):
        scan = await org_db.scan_jobs.find_one({"_id": ObjectId(scan_id)})
        steps = scan.get("steps", [])
        total = len(steps) or 1
        done = len([s for s in steps if s.get("status") in ("completed", "skipped", "failed", "cancelled")])
        progress = int((done / total) * 100)

        await org_db.scan_jobs.update_one(
            {"_id": ObjectId(scan_id)},
            {
                "$set": {
                    "progress": progress,
                    "total_findings": total_findings,
                    "completed_steps": done,
                    "total_steps": total,
                    "updated_at": datetime.utcnow(),
                }
            },
        )

    async def _upd_step(self, db, scan_id: str, idx: int, update: dict):
        await db.scan_jobs.update_one(
            {"_id": ObjectId(scan_id)},
            {"$set": {f"steps.{idx}.{k}": v for k, v in update.items()}},
        )
