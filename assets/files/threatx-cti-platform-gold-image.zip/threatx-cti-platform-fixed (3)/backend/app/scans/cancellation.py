from datetime import datetime
from bson import ObjectId

class ScanCancelled(Exception):
    pass

def _scan_filter(scan_id: str):
    if ObjectId.is_valid(scan_id):
        return {"_id": ObjectId(scan_id)}
    return {"id": scan_id}

async def request_scan_cancel(db, scan_id: str) -> bool:
    result = await db.scan_jobs.update_one(
        {**_scan_filter(scan_id), "status": {"$in": ["pending", "running", "cancelling"]}},
        {"$set": {"status": "cancelling", "cancel_requested": True, "updated_at": datetime.utcnow()}},
    )
    return result.modified_count > 0

async def mark_scan_deleted(db, scan_id: str) -> bool:
    result = await db.scan_jobs.delete_one(_scan_filter(scan_id))
    return result.deleted_count > 0

async def check_scan_cancelled(db, scan_id: str) -> None:
    scan = await db.scan_jobs.find_one(_scan_filter(scan_id))
    if not scan:
        raise ScanCancelled("Scan deleted")
    if scan.get("cancel_requested") or scan.get("status") == "cancelling":
        await db.scan_jobs.update_one(
            _scan_filter(scan_id),
            {"$set": {"status": "cancelled", "completed_at": datetime.utcnow(), "updated_at": datetime.utcnow(), "progress": scan.get("progress", 0)}},
        )
        raise ScanCancelled("Scan cancelled by user")
