from datetime import datetime
from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
import re

from app.core.database import get_core_db
from app.core.tenant import get_current_user


router = APIRouter()


class OrganizationCreate(BaseModel):
    name: str = Field(..., min_length=2, max_length=120)


def _now():
    return datetime.utcnow()


def _slugify(value: str) -> str:
    value = value.lower().strip()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    value = value.strip("-")
    return value or "organization"


def _maybe_oid(value: str):
    if ObjectId.is_valid(str(value)):
        return ObjectId(str(value))
    return value


def _get_user_id(current_user) -> str:
    if isinstance(current_user, dict):
        value = (
            current_user.get("id")
            or current_user.get("_id")
            or current_user.get("sub")
            or current_user.get("user_id")
        )
        if value:
            return str(value)

    for attr in ["id", "_id", "sub", "user_id"]:
        if hasattr(current_user, attr):
            value = getattr(current_user, attr)
            if value:
                return str(value)

    raise HTTPException(status_code=401, detail="Unable to resolve current user")


def _serialize(doc: dict) -> dict:
    out = {}

    for k, v in doc.items():
        if isinstance(v, ObjectId):
            out[k] = str(v)
        elif isinstance(v, datetime):
            out[k] = v.isoformat()
        else:
            out[k] = v

    if "_id" in doc:
        out["id"] = str(doc["_id"])

    if "id" not in out and "organization_id" in out:
        out["id"] = str(out["organization_id"])

    return out


async def _list_user_orgs(core_db, user_id: str) -> list[dict]:
    user_oid = _maybe_oid(user_id)

    membership_filter = {
        "$or": [
            {"user_id": user_id},
            {"user_id": user_oid},
            {"member_id": user_id},
            {"member_id": user_oid},
        ]
    }

    memberships = await core_db.memberships.find(membership_filter).to_list(length=500)

    org_ids = set()

    for m in memberships:
        for key in ["organization_id", "org_id", "organization"]:
            if key in m and m[key]:
                org_ids.add(str(m[key]))

    or_filters = [
        {"created_by": user_id},
        {"created_by": user_oid},
        {"owner_id": user_id},
        {"owner_id": user_oid},
    ]

    for org_id in org_ids:
        or_filters.append({"id": org_id})
        or_filters.append({"organization_id": org_id})

        if ObjectId.is_valid(org_id):
            or_filters.append({"_id": ObjectId(org_id)})

    if not or_filters:
        return []

    orgs = await core_db.organizations.find({"$or": or_filters}).to_list(length=500)

    seen = set()
    result = []

    for org in orgs:
        sid = str(org.get("_id") or org.get("id") or org.get("organization_id"))
        if sid not in seen:
            seen.add(sid)
            result.append(_serialize(org))

    return result


@router.get("/organizations")
async def list_organizations(current_user=Depends(get_current_user)):
    core_db = get_core_db()
    user_id = _get_user_id(current_user)

    orgs = await _list_user_orgs(core_db, user_id)

    active_org_id = None

    if isinstance(current_user, dict):
        active_org_id = current_user.get("active_organization_id")
    else:
        active_org_id = getattr(current_user, "active_organization_id", None)

    return {
        "organizations": orgs,
        "active_organization_id": str(active_org_id) if active_org_id else None,
    }


@router.post("/organizations")
async def create_organization(
    payload: OrganizationCreate,
    current_user=Depends(get_current_user),
):
    core_db = get_core_db()
    user_id = _get_user_id(current_user)
    user_oid = _maybe_oid(user_id)

    base_slug = _slugify(payload.name)
    slug = base_slug
    counter = 2

    while await core_db.organizations.find_one({"slug": slug}):
        slug = f"{base_slug}-{counter}"
        counter += 1

    org_oid = ObjectId()
    org_id = str(org_oid)

    org_doc = {
        "_id": org_oid,
        "id": org_id,
        "name": payload.name,
        "slug": slug,
        "created_by": user_id,
        "owner_id": user_id,
        "created_at": _now(),
        "updated_at": _now(),
        "is_active": True,
    }

    await core_db.organizations.insert_one(org_doc)

    await core_db.memberships.update_one(
        {
            "user_id": user_id,
            "organization_id": org_id,
        },
        {
            "$set": {
                "user_id": user_id,
                "organization_id": org_id,
                "org_id": org_id,
                "role": "owner",
                "updated_at": _now(),
            },
            "$setOnInsert": {
                "created_at": _now(),
            },
        },
        upsert=True,
    )

    await core_db.users.update_one(
        {
            "$or": [
                {"_id": user_oid},
                {"_id": user_id},
                {"id": user_id},
            ]
        },
        {
            "$set": {
                "active_organization_id": org_id,
                "updated_at": _now(),
            }
        },
    )

    return {
        "organization": _serialize(org_doc),
        "active_organization_id": org_id,
    }


@router.post("/organizations/{org_id}/activate")
async def activate_organization(
    org_id: str,
    current_user=Depends(get_current_user),
):
    core_db = get_core_db()
    user_id = _get_user_id(current_user)
    user_oid = _maybe_oid(user_id)

    orgs = await _list_user_orgs(core_db, user_id)
    allowed = any(str(org.get("id")) == str(org_id) for org in orgs)

    if not allowed:
        raise HTTPException(status_code=403, detail="Organization not available for this user")

    await core_db.users.update_one(
        {
            "$or": [
                {"_id": user_oid},
                {"_id": user_id},
                {"id": user_id},
            ]
        },
        {
            "$set": {
                "active_organization_id": org_id,
                "updated_at": _now(),
            }
        },
    )

    return {
        "active_organization_id": org_id,
    }
