#!/usr/bin/env bash
set -u

DC="${DOCKER_COMPOSE:-docker-compose}"
BACKEND_URL="${BACKEND_URL:-http://localhost:8000}"
FRONTEND_URL="${FRONTEND_URL:-http://localhost:5173}"

TOKEN="${THREATX_TOKEN:-}"
ORG_ID="${THREATX_ORG_ID:-}"
REPORT_ID="${THREATX_REPORT_ID:-}"

PASS=0
FAIL=0
WARN=0

green="\033[0;32m"
red="\033[0;31m"
yellow="\033[0;33m"
blue="\033[0;34m"
reset="\033[0m"

ok() {
  echo -e "${green}[PASS]${reset} $1"
  PASS=$((PASS + 1))
}

ko() {
  echo -e "${red}[FAIL]${reset} $1"
  FAIL=$((FAIL + 1))
}

warn() {
  echo -e "${yellow}[WARN]${reset} $1"
  WARN=$((WARN + 1))
}

info() {
  echo -e "${blue}[INFO]${reset} $1"
}

run_test() {
  local name="$1"
  shift

  info "$name"
  if "$@"; then
    ok "$name"
  else
    ko "$name"
  fi
}

auth_header_args() {
  if [ -n "$TOKEN" ]; then
    printf "%s\n%s\n" "-H" "Authorization: Bearer $TOKEN"
  fi
}

test_docker_compose() {
  $DC ps >/tmp/threatx_test_compose_ps.txt 2>&1
}

test_backend_health() {
  curl -fsS "$BACKEND_URL/api/health" >/tmp/threatx_health.json
  grep -q '"status":"healthy"' /tmp/threatx_health.json
}

test_frontend_home() {
  curl -fsS "$FRONTEND_URL" >/tmp/threatx_frontend_home.html
}

test_frontend_routes() {
  curl -fsS "$FRONTEND_URL/settings" >/tmp/threatx_frontend_settings.html
  curl -fsS "$FRONTEND_URL/reports" >/tmp/threatx_frontend_reports.html
}

test_backend_compile() {
  $DC exec -T backend sh -lc "python -m compileall -q /app/app"
}

test_frontend_build() {
  $DC exec -T frontend sh -lc "npm run build"
}

test_source_registry() {
  $DC exec -T backend sh -lc "python - <<'PY'
from app.sources.registry import init_sources, SourceRegistry

SourceRegistry._sources.clear()
init_sources()

names = set(SourceRegistry.get_names())
expected = {
    'HIBP',
    'Shodan',
    'IntelX',
    'AlienVaultOTX',
    'otx',
    'VirusTotal',
    'virustotal',
    'Nmap',
    'SubdomainFinder',
    'DNSResolver',
    'WHOIS',
}

missing = sorted(expected - names)

print('Registered sources:', sorted(names))

if missing:
    print('Missing sources:', missing)
    raise SystemExit(1)
PY"
}

test_source_api_endpoint() {
  local source="$1"
  local base_url="$2"

  local body
  body="$(curl -sS -X POST "$BACKEND_URL/api/wizard/test-api-key" \
    -H "Content-Type: application/json" \
    -d "{\"source_name\":\"$source\",\"api_key\":\"test-key\",\"base_url\":\"$base_url\"}")"

  echo "$body" > "/tmp/threatx_source_${source}.json"

  if echo "$body" | grep -qi "Unknown source"; then
    echo "$body"
    return 1
  fi

  return 0
}

test_orgs_endpoint() {
  local code
  if [ -n "$TOKEN" ]; then
    code="$(curl -sS -o /tmp/threatx_orgs.json -w "%{http_code}" \
      -H "Authorization: Bearer $TOKEN" \
      "$BACKEND_URL/api/orgs")"
  else
    code="$(curl -sS -o /tmp/threatx_orgs.json -w "%{http_code}" \
      "$BACKEND_URL/api/orgs")"
  fi

  case "$code" in
    200) return 0 ;;
    401|403)
      warn "Organizations endpoint requires authentication. Set THREATX_TOKEN to test it fully."
      return 0
      ;;
    *)
      echo "HTTP $code"
      cat /tmp/threatx_orgs.json
      return 1
      ;;
  esac
}

test_integrations_endpoint() {
  if [ -z "$ORG_ID" ]; then
    warn "THREATX_ORG_ID not set. Skipping integrations endpoint test."
    return 0
  fi

  local code

  if [ -n "$TOKEN" ]; then
    code="$(curl -sS -o /tmp/threatx_integrations.json -w "%{http_code}" \
      -H "Authorization: Bearer $TOKEN" \
      "$BACKEND_URL/api/orgs/$ORG_ID/integrations")"
  else
    code="$(curl -sS -o /tmp/threatx_integrations.json -w "%{http_code}" \
      "$BACKEND_URL/api/orgs/$ORG_ID/integrations")"
  fi

  case "$code" in
    200) return 0 ;;
    401|403)
      warn "Integrations endpoint requires authentication. Set THREATX_TOKEN to test it fully."
      return 0
      ;;
    404)
      warn "Integrations endpoint not found. This may be acceptable if not implemented."
      return 0
      ;;
    *)
      echo "HTTP $code"
      cat /tmp/threatx_integrations.json
      return 1
      ;;
  esac
}

test_reports_list() {
  if [ -z "$ORG_ID" ]; then
    warn "THREATX_ORG_ID not set. Skipping reports list test."
    return 0
  fi

  local code

  if [ -n "$TOKEN" ]; then
    code="$(curl -sS -o /tmp/threatx_reports.json -w "%{http_code}" \
      -H "Authorization: Bearer $TOKEN" \
      "$BACKEND_URL/api/orgs/$ORG_ID/reports")"
  else
    code="$(curl -sS -o /tmp/threatx_reports.json -w "%{http_code}" \
      "$BACKEND_URL/api/orgs/$ORG_ID/reports")"
  fi

  case "$code" in
    200) return 0 ;;
    401|403)
      warn "Reports endpoint requires authentication. Set THREATX_TOKEN to test it fully."
      return 0
      ;;
    *)
      echo "HTTP $code"
      cat /tmp/threatx_reports.json
      return 1
      ;;
  esac
}

test_report_download() {
  if [ -z "$ORG_ID" ] || [ -z "$REPORT_ID" ]; then
    warn "THREATX_ORG_ID or THREATX_REPORT_ID not set. Skipping report download test."
    return 0
  fi

  if [ -z "$TOKEN" ]; then
    warn "THREATX_TOKEN not set. Skipping authenticated report download test."
    return 0
  fi

  local code
  code="$(curl -sS -o /tmp/threatx_report_download.bin -w "%{http_code}" \
    -H "Authorization: Bearer $TOKEN" \
    "$BACKEND_URL/api/orgs/$ORG_ID/reports/$REPORT_ID/download")"

  if [ "$code" != "200" ]; then
    echo "HTTP $code"
    cat /tmp/threatx_report_download.bin
    return 1
  fi

  if grep -qi "Not authenticated" /tmp/threatx_report_download.bin; then
    cat /tmp/threatx_report_download.bin
    return 1
  fi

  return 0
}

echo "============================================================"
echo "ThreatX CTI Platform - Full Functional Test"
echo "Backend:  $BACKEND_URL"
echo "Frontend: $FRONTEND_URL"
echo "============================================================"

run_test "Docker Compose status" test_docker_compose
run_test "Backend health check" test_backend_health
run_test "Frontend home route" test_frontend_home
run_test "Frontend settings/reports routes" test_frontend_routes
run_test "Backend Python compile" test_backend_compile
run_test "Frontend production build" test_frontend_build
run_test "Backend source registry" test_source_registry

run_test "API source test: HIBP" test_source_api_endpoint "hibp" "https://haveibeenpwned.com/api/v3"
run_test "API source test: Shodan" test_source_api_endpoint "shodan" "https://api.shodan.io"
run_test "API source test: IntelX" test_source_api_endpoint "intelx" "https://free.intelx.io"
run_test "API source test: AlienVault OTX alias" test_source_api_endpoint "otx" "https://otx.alienvault.com/api/v1"
run_test "API source test: VirusTotal alias" test_source_api_endpoint "virustotal" "https://www.virustotal.com/api/v3"

run_test "Organizations endpoint" test_orgs_endpoint
run_test "Integrations endpoint" test_integrations_endpoint
run_test "Reports list endpoint" test_reports_list
run_test "Authenticated report download" test_report_download

echo "============================================================"
echo "Summary"
echo "PASS: $PASS"
echo "WARN: $WARN"
echo "FAIL: $FAIL"
echo "============================================================"

if [ "$FAIL" -gt 0 ]; then
  exit 1
fi

exit 0
