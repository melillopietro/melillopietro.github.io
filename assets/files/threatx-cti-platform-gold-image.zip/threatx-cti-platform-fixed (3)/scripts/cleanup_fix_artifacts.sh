#!/usr/bin/env bash
set -euo pipefail

APPLY=0

for arg in "$@"; do
  case "$arg" in
    --apply)
      APPLY=1
      ;;
    --help|-h)
      echo "Usage: ./scripts/cleanup_fix_artifacts.sh [--apply]"
      echo
      echo "Default mode is dry-run."
      echo "--apply removes detected backup/cache/fix artifacts."
      exit 0
      ;;
  esac
done

echo "============================================================"
echo "ThreatX cleanup helper"
echo "Mode: $([ "$APPLY" -eq 1 ] && echo APPLY || echo DRY-RUN)"
echo "============================================================"

TMP_FILE="/tmp/threatx_cleanup_candidates.txt"
: > "$TMP_FILE"

find . \
  -path "./node_modules" -prune -o \
  -path "./.git" -prune -o \
  -path "./dist" -prune -o \
  -type f \( \
    -name "*.bak" -o \
    -name "*.backup" -o \
    -name "*.backup_*" -o \
    -name "*.old" -o \
    -name "*.orig" -o \
    -name "*.rej" -o \
    -name "*.tmp" -o \
    -name "*.pyc" -o \
    -name "fix_*.py" -o \
    -name "fix-*.py" -o \
    -name "patch_*.py" -o \
    -name "patch-*.py" -o \
    -name "repair_*.py" -o \
    -name "debug_*.py" -o \
    -name "tmp_*.py" -o \
    -name "fix_*.sh" -o \
    -name "patch_*.sh" -o \
    -name "repair_*.sh" -o \
    -name "debug_*.sh" \
  \) \
  ! -path "./scripts/test_threatx.sh" \
  ! -path "./scripts/cleanup_fix_artifacts.sh" \
  -print >> "$TMP_FILE"

find . \
  -path "./node_modules" -prune -o \
  -path "./.git" -prune -o \
  -type d \( \
    -name "__pycache__" -o \
    -name ".pytest_cache" -o \
    -name ".mypy_cache" -o \
    -name ".ruff_cache" -o \
    -name ".vite-temp" \
  \) \
  -print >> "$TMP_FILE"

sort -u "$TMP_FILE" -o "$TMP_FILE"

if [ ! -s "$TMP_FILE" ]; then
  echo "No cleanup candidates found."
  exit 0
fi

echo "Candidates:"
cat "$TMP_FILE"

if [ "$APPLY" -ne 1 ]; then
  echo
  echo "Dry-run only. To delete these files/directories:"
  echo "./scripts/cleanup_fix_artifacts.sh --apply"
  exit 0
fi

echo
echo "Deleting candidates..."

while IFS= read -r item; do
  if [ -e "$item" ]; then
    rm -rf "$item"
    echo "Deleted: $item"
  fi
done < "$TMP_FILE"

echo "Cleanup completed."
