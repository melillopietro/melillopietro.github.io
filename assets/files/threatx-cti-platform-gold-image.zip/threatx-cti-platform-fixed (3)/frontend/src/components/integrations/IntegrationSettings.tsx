import { useEffect, useState } from 'react'
import { api } from '../../api/client'

type ProviderKey = 'hibp' | 'shodan' | 'intelx' | 'otx' | 'virustotal'

type ProviderConfig = {
  provider: ProviderKey
  source_name: string
  label: string
  description: string
  base_url: string
  api_key: string
  enabled: boolean
}

const DEFAULT_PROVIDERS: ProviderConfig[] = [
  {
    provider: 'hibp',
    source_name: 'hibp',
    label: 'Have I Been Pwned',
    description: 'Breach intelligence and exposed email checks.',
    base_url: 'https://haveibeenpwned.com/api/v3',
    api_key: '',
    enabled: true,
  },
  {
    provider: 'shodan',
    source_name: 'shodan',
    label: 'Shodan',
    description: 'Exposed services, ports, banners and vulnerability enrichment.',
    base_url: 'https://api.shodan.io',
    api_key: '',
    enabled: true,
  },
  {
    provider: 'intelx',
    source_name: 'intelx',
    label: 'Intelligence X',
    description: 'Leak, dark web and indexed intelligence lookups.',
    base_url: 'https://free.intelx.io',
    api_key: '',
    enabled: true,
  },
  {
    provider: 'otx',
    source_name: 'otx',
    label: 'AlienVault OTX',
    description: 'Passive DNS, threat indicators and AlienVault OTX enrichment.',
    base_url: 'https://otx.alienvault.com/api/v1',
    api_key: '',
    enabled: true,
  },
  {
    provider: 'virustotal',
    source_name: 'virustotal',
    label: 'VirusTotal',
    description: 'Domain, IP, URL and file reputation enrichment from VirusTotal.',
    base_url: 'https://www.virustotal.com/api/v3',
    api_key: '',
    enabled: true,
  },
]

type Props = {
  orgId: string
}

export default function IntegrationSettings({ orgId }: Props) {
  const [providers, setProviders] = useState<ProviderConfig[]>(DEFAULT_PROVIDERS)
  const [status, setStatus] = useState<Record<string, string>>({})
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    loadSavedIntegrations()
  }, [orgId])

  function localStorageKey() {
    return 'threatx_api_integrations_' + orgId
  }

  async function loadSavedIntegrations() {
    const local = window.localStorage.getItem(localStorageKey())

    if (local) {
      try {
        const parsed = JSON.parse(local)
        setProviders(mergeProviders(parsed))
      } catch {
        setProviders(DEFAULT_PROVIDERS)
      }
    }

    const endpoints = [
      '/api/orgs/' + orgId + '/integrations',
      '/api/orgs/' + orgId + '/api-keys',
      '/api/settings/api-keys?organization_id=' + orgId,
      '/api/integrations?organization_id=' + orgId,
    ]

    for (const endpoint of endpoints) {
      try {
        const res = await api.get<any>(endpoint)
        const items = Array.isArray(res) ? res : res.items || res.sources || res.integrations || res.api_keys || []
        if (Array.isArray(items) && items.length > 0) {
          setProviders(mergeProviders(items))
          return
        }
      } catch {
        continue
      }
    }
  }

  function mergeProviders(items: any[]) {
    return DEFAULT_PROVIDERS.map(defaultProvider => {
      const found = items.find(item =>
        item.provider === defaultProvider.provider ||
        item.source_name === defaultProvider.source_name ||
        item.name === defaultProvider.provider ||
        item.name === defaultProvider.source_name
      )

      if (!found) return defaultProvider

      return {
        ...defaultProvider,
        api_key: found.api_key || found.key || '',
        base_url: found.base_url || defaultProvider.base_url,
        enabled: typeof found.enabled === 'boolean' ? found.enabled : defaultProvider.enabled,
      }
    })
  }

  function updateProvider(provider: ProviderKey, field: keyof ProviderConfig, value: string | boolean) {
    setProviders(prev =>
      prev.map(item =>
        item.provider === provider ? { ...item, [field]: value } : item
      )
    )
  }

  async function testProvider(provider: ProviderConfig) {
    if (!provider.api_key.trim()) {
      setStatus(prev => ({ ...prev, [provider.provider]: 'Insert an API key before testing.' }))
      return
    }

    setStatus(prev => ({ ...prev, [provider.provider]: 'Testing API key...' }))

    try {
      const res = await api.post<any>('/api/wizard/test-api-key', {
        source_name: provider.source_name,
        api_key: provider.api_key.trim(),
        base_url: provider.base_url.trim(),
      })

      setStatus(prev => ({
        ...prev,
        [provider.provider]: (res.status || 'ok') + ': ' + (res.message || 'API key tested.'),
      }))
    } catch (err: any) {
      setStatus(prev => ({
        ...prev,
        [provider.provider]: err.message || 'API test failed.',
      }))
    }
  }

  async function saveProvider(provider: ProviderConfig) {
    setLoading(true)
    setStatus(prev => ({ ...prev, [provider.provider]: 'Saving...' }))

    const payload = {
      organization_id: orgId,
      provider: provider.provider,
      source_name: provider.source_name,
      api_key: provider.api_key.trim() || null,
      base_url: provider.base_url.trim(),
      enabled: provider.enabled,
    }

    const endpoints = [
      '/api/orgs/' + orgId + '/integrations',
      '/api/orgs/' + orgId + '/api-keys',
      '/api/settings/api-keys',
      '/api/integrations/api-keys',
    ]

    let savedOnBackend = false
    let lastError = ''

    for (const endpoint of endpoints) {
      try {
        await api.post(endpoint, payload)
        savedOnBackend = true
        break
      } catch (err: any) {
        lastError = err.message || String(err)
      }
    }

    const nextProviders = providers.map(item =>
      item.provider === provider.provider ? provider : item
    )

    window.localStorage.setItem(localStorageKey(), JSON.stringify(nextProviders))

    setStatus(prev => ({
      ...prev,
      [provider.provider]: savedOnBackend
        ? 'Saved on backend.'
        : 'Saved locally. Backend save endpoint not found. Last error: ' + lastError,
    }))

    setLoading(false)
  }

  async function saveAll() {
    setLoading(true)

    for (const provider of providers) {
      await saveProvider(provider)
    }

    setLoading(false)
  }

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
        {providers.map(provider => (
          <div key={provider.provider} className="card space-y-4">
            <div className="flex items-start justify-between gap-4">
              <div>
                <h3 className="text-lg font-bold text-gray-100">{provider.label}</h3>
                <p className="text-sm text-gray-500 mt-1">{provider.description}</p>
              </div>

              <label className="flex items-center gap-2 text-sm text-gray-400 cursor-pointer">
                <input
                  type="checkbox"
                  className="rounded"
                  checked={provider.enabled}
                  onChange={e => updateProvider(provider.provider, 'enabled', e.target.checked)}
                />
                Enabled
              </label>
            </div>

            {provider.provider === 'intelx' ? (
              <select
                className="threatx-input input-field"
                value={provider.base_url}
                onChange={e => updateProvider(provider.provider, 'base_url', e.target.value)}
              >
                <option value="https://free.intelx.io">Free - https://free.intelx.io</option>
                <option value="https://public.intelx.io">Public - https://public.intelx.io</option>
                <option value="https://2.intelx.io">Paid - https://2.intelx.io</option>
              </select>
            ) : (
              <input
                className="threatx-input input-field"
                value={provider.base_url}
                onChange={e => updateProvider(provider.provider, 'base_url', e.target.value)}
                placeholder="Base URL"
              />
            )}

            <input
              type="password"
              className="threatx-input input-field"
              value={provider.api_key}
              onChange={e => updateProvider(provider.provider, 'api_key', e.target.value)}
              placeholder="API key"
            />

            <div className="flex flex-wrap items-center gap-3">
              <button className="btn-secondary" type="button" onClick={() => testProvider(provider)} disabled={loading}>
                Test
              </button>

              <button className="btn-primary" type="button" onClick={() => saveProvider(provider)} disabled={loading}>
                Save
              </button>

              {status[provider.provider] && (
                <span className="text-xs text-gray-400">{status[provider.provider]}</span>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="flex justify-end">
        <button className="btn-primary" type="button" onClick={saveAll} disabled={loading}>
          {loading ? 'Saving...' : 'Save all integrations'}
        </button>
      </div>
    </div>
  )
}
