import { cancelScan } from '../api/scans'

interface Props {
  orgId: string
  scanId: string
  status: string
  onDone?: () => Promise<void> | void
}

export default function StopScanButton({ orgId, scanId, status, onDone }: Props) {
  const visible = ['pending', 'running', 'cancelling'].includes(status)
  if (!visible) return null
  return (
    <button
      disabled={status === 'cancelling'}
      onClick={async () => {
        await cancelScan(orgId, scanId)
        if (onDone) await onDone()
      }}
      className="px-3 py-1.5 rounded-lg border border-red-500/30 text-red-300 hover:bg-red-500/10 disabled:opacity-50 text-sm"
    >
      {status === 'cancelling' ? 'Stopping...' : 'Stop Scan'}
    </button>
  )
}
