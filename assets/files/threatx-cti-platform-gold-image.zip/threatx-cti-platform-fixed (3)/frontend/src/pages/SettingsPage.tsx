import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { api } from '../api/client'
import IntegrationSettings from '../components/integrations/IntegrationSettings'
import { saveActiveOrgId, getActiveOrgId, clearActiveOrgId } from '../api/orgStorage'

type Org = {
  id: string
  name: string
  primary_domain: string
}

export default function SettingsPage() {
  const [orgs, setOrgs] = useState<Org[]>([])
  const [active, setActive] = useState(getActiveOrgId())
  const [name, setName] = useState('')
  const [domain, setDomain] = useState('')
  const [error, setError] = useState('')

  const load = async () => {
    try {
      const data = await api.get<Org[]>('/api/orgs')
      setOrgs(data)

      const stored = getActiveOrgId()
      if (stored) {
        setActive(stored)
      } else if (data[0]) {
        saveActiveOrgId(data[0].id)
        setActive(data[0].id)
      }
    } catch (err: any) {
      setError(err.message || 'Unable to load organizations')
    }
  }

  useEffect(() => {
    load().catch(console.error)
  }, [])

  const createOrg = async () => {
    if (!name.trim() || !domain.trim()) {
      alert('Insert organization name and primary domain')
      return
    }

    try {
      const org = await api.post<Org>('/api/orgs', {
        name: name.trim(),
        primary_domain: domain.trim(),
      })

      saveActiveOrgId(org.id)
      setActive(org.id)
      setName('')
      setDomain('')
      await load()
    } catch (err: any) {
      setError(err.message || 'Organization creation failed')
    }
  }

  const selectOrg = async (id: string) => {
    try {
      await api.post(`/api/orgs/${id}/select`)
      saveActiveOrgId(id)
      setActive(id)
    } catch (err: any) {
      setError(err.message || 'Unable to select organization')
    }
  }

  const deleteOrg = async (id: string) => {
    if (!confirm('Delete selected organization and its data?')) return

    try {
      await api.delete(`/api/orgs/${id}`)

      if (active === id) {
        clearActiveOrgId()
        setActive('')
      }

      await load()
    } catch (err: any) {
      setError(err.message || 'Organization deletion failed')
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Settings</h1>
          <p className="text-gray-500">
            Manage organizations and API integrations after the initial wizard.
          </p>
        </div>

        <Link to="/" className="btn-secondary whitespace-nowrap">
          Back to Dashboard
        </Link>
      </div>

      {error && (
        <div className="card border border-red-500/40 bg-red-500/10 text-red-300 text-sm">
          {error}
        </div>
      )}

      <div className="card space-y-4">
        <h2 className="text-lg font-semibold">Organization</h2>

        <div className="space-y-2">
          {orgs.map(org => (
            <div key={org.id} className="threatx-card-select p-3 flex items-center justify-between">
              <div>
                <div className="font-medium text-white">{org.name}</div>
                <div className="text-sm text-gray-500">{org.primary_domain}</div>
              </div>

              <div className="flex gap-2">
                <button className="btn-secondary" onClick={() => selectOrg(org.id)}>
                  {active === org.id ? 'Selected' : 'Use'}
                </button>

                <button className="btn-danger" onClick={() => deleteOrg(org.id)}>
                  Delete
                </button>
              </div>
            </div>
          ))}

          {orgs.length === 0 && (
            <p className="text-gray-500">No organization found. Create one below.</p>
          )}
        </div>

        <div className="grid md:grid-cols-3 gap-3">
          <input
            className="threatx-input"
            placeholder="New organization name"
            value={name}
            onChange={e => setName(e.target.value)}
          />

          <input
            className="threatx-input"
            placeholder="Primary domain"
            value={domain}
            onChange={e => setDomain(e.target.value)}
          />

          <button className="btn-primary" onClick={createOrg}>
            Create
          </button>
        </div>
      </div>

      {active ? (
        <>
          <h2 className="text-xl font-semibold">API Integrations</h2>
          <p className="text-gray-500">
            API keys are optional. Providers without keys are skipped during scans.
          </p>
          <IntegrationSettings orgId={active} />
        </>
      ) : (
        <div className="card text-gray-500">
          Create or select an organization to configure APIs.
        </div>
      )}
    </div>
  )
}
