import { useEffect, useState } from 'react'
import { api } from '../api/client'
import { getActiveOrgId } from '../api/orgStorage'

type AssetsData = { summary: any; domains: any[]; subdomains: any[]; ips: any[]; services: any[]; vulnerabilities: any[] }

export default function AssetsPage() {
  const orgId = getActiveOrgId()
  const [data, setData] = useState<AssetsData | null>(null)
  const [loading, setLoading] = useState(false)
  const load = async () => { if (!orgId) return; setLoading(true); try { setData(await api.get<AssetsData>(`/api/orgs/${orgId}/assets`)) } finally { setLoading(false) } }
  useEffect(() => { load().catch(console.error) }, [orgId])

  if (!orgId) return <div className="card text-gray-500">Select or create an organization first.</div>
  if (loading && !data) return <div className="card text-gray-500">Loading assets...</div>
  const s = data?.summary || {}
  return <div className="space-y-6">
    <div className="flex items-center justify-between"><div><h1 className="text-2xl font-bold">Assets</h1><p className="text-gray-500">Assets discovered by scans.</p></div><button className="btn-secondary" onClick={load}>Refresh</button></div>
    <div className="grid md:grid-cols-5 gap-3">{[['Domains',s.domains],['Subdomains',s.subdomains],['IPs',s.ips],['Services',s.services],['Vulnerabilities',s.vulnerabilities]].map(([k,v]) => <div key={String(k)} className="card"><div className="text-sm text-gray-500">{k}</div><div className="text-2xl font-bold">{String(v ?? 0)}</div></div>)}</div>
    <Section title="Subdomains" items={data?.subdomains || []} fields={['subdomain','parent_domain','status','source_name']} />
    <Section title="IP addresses" items={data?.ips || []} fields={['ip','discovered_via','status','source_name']} />
    <Section title="Exposed services" items={data?.services || []} fields={['ip','port','service_name','product','status']} />
    <Section title="Vulnerabilities" items={data?.vulnerabilities || []} fields={['cve_id','ip','port','cvss','status']} />
  </div>
}

function Section({title, items, fields}: {title:string; items:any[]; fields:string[]}) {
  return <div className="card space-y-3"><h2 className="text-lg font-semibold">{title}</h2>{items.length === 0 ? <p className="text-gray-500">No data.</p> : <div className="overflow-x-auto"><table className="w-full text-sm"><thead><tr>{fields.map(f => <th key={f} className="text-left text-gray-500 py-2">{f}</th>)}</tr></thead><tbody>{items.slice(0,200).map((it,idx) => <tr key={idx} className="border-t border-indigo-950/70">{fields.map(f => <td key={f} className="py-2 text-gray-300">{String(it[f] ?? '')}</td>)}</tr>)}</tbody></table></div>}</div>
}
