import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api } from '../api/client'
import { useAuth } from '../features/auth/AuthContext'
import { saveOrgId } from '../api/orgStorage'

const STEPS = ['Organization', 'Assets', 'API Sources', 'Scan Policy', 'Review']

export default function WizardPage() {
  const [step, setStep] = useState(0)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [apiTestStatus, setApiTestStatus] = useState<Record<string, string>>({})
  const navigate = useNavigate()
  const { user, setUser } = useAuth()

  const [form, setForm] = useState({
    step1: { name: '', description: '', sector: '', country: '', size: '', primary_domain: '', security_contacts: [] as string[] },
    step2: { domains: [] as string[], subdomains: [] as string[], ips: [] as string[], cidrs: [] as string[], keywords: [] as string[], brand_keywords: [] as string[], executive_keywords: [] as string[], technologies: [] as string[], email_domains: [] as string[], authorization_notes: '' },
    step3: {
      hibp_api_key: '', shodan_api_key: '', intelx_api_key: '', virustotal_api_key: '',
      hibp_base_url: 'https://haveibeenpwned.com/api/v3',
      shodan_base_url: 'https://api.shodan.io',
      intelx_base_url: 'https://free.intelx.io',
      virustotal_base_url: 'https://www.virustotal.com/api/v3',
      hibp_enabled: true, shodan_enabled: true, intelx_enabled: true, virustotal_enabled: true,
    },
    step4: { additional_users: [] },
    step5: { scan_type: 'light', nmap_enabled: false, shodan_enabled: true, hibp_enabled: true, intelx_enabled: true, otx_enabled: true, virustotal_enabled: true, scan_frequency: 'manual', authorization_confirmed: false },
  })

  const updateStep = (stepKey: string, field: string, value: any) => {
    setForm(prev => ({ ...prev, [stepKey]: { ...(prev as any)[stepKey], [field]: value } }))
  }

  const addToList = (stepKey: string, field: string, value: string) => {
    if (!value.trim()) return
    setForm(prev => ({ ...prev, [stepKey]: { ...(prev as any)[stepKey], [field]: [...(prev as any)[stepKey][field], value.trim()] } }))
  }

  const removeFromList = (stepKey: string, field: string, index: number) => {
    setForm(prev => {
      const list = [...(prev as any)[stepKey][field]]
      list.splice(index, 1)
      return { ...prev, [stepKey]: { ...(prev as any)[stepKey], [field]: list } }
    })
  }

  const validateStep = (): boolean => {
    setError('')
    if (step === 0) {
      if (!form.step1.name.trim()) { setError('Organization name is required'); return false }
      if (!form.step1.primary_domain.trim()) { setError('Primary domain is required'); return false }
      if (!/^[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/.test(form.step1.primary_domain.trim())) {
        setError('Please enter a valid domain, for example example.com'); return false
      }
    }
    return true
  }

  const nextStep = () => { if (validateStep()) setStep(step + 1) }

  async function testApi(provider: 'hibp' | 'shodan' | 'intelx' | 'virustotal') {
    const apiKey = (form.step3 as any)[`${provider}_api_key`]
    const baseUrl = (form.step3 as any)[`${provider}_base_url`]
    if (!apiKey) {
      setApiTestStatus(prev => ({ ...prev, [provider]: 'Insert an API key before testing.' }))
      return
    }
    const res = await api.post<{ status: string; message: string }>('/api/wizard/test-api-key', { source_name: provider, api_key: apiKey, base_url: baseUrl })
    setApiTestStatus(prev => ({ ...prev, [provider]: `${res.status}: ${res.message}` }))
  }

  const handleSubmit = async () => {
    if (!form.step5.authorization_confirmed) { setError('Authorization confirmation required'); return }
    setLoading(true); setError('')
    try {
      const payload = {
        step1: { ...form.step1, primary_domain: form.step1.primary_domain.trim() },
        step2: form.step2,
        step3: {
          hibp_api_key: form.step3.hibp_api_key || null,
          shodan_api_key: form.step3.shodan_api_key || null,
          intelx_api_key: form.step3.intelx_api_key || null,
          virustotal_api_key: form.step3.virustotal_api_key || null,
          hibp_base_url: form.step3.hibp_base_url,
          shodan_base_url: form.step3.shodan_base_url,
          intelx_base_url: form.step3.intelx_base_url,
          virustotal_base_url: form.step3.virustotal_base_url,
          hibp_enabled: form.step3.hibp_enabled,
          shodan_enabled: form.step3.shodan_enabled,
          intelx_enabled: form.step3.intelx_enabled,
          virustotal_enabled: form.step3.virustotal_enabled,
        },
        step4: form.step4,
        step5: form.step5,
        start_scan: true,
      }
      const res = await api.post<{ organization_id: string; slug: string }>('/api/wizard/complete', payload)
      saveOrgId(res.organization_id)
      if (user) setUser({ ...user, active_organization_id: res.organization_id })
      navigate('/', { replace: true })
    } catch (err: any) {
      setError(err.message || 'Wizard completion failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-navy-950 p-6">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-2xl font-bold">Organization Setup Wizard</h1>
          <p className="text-gray-500 mt-1">Configure your threat intelligence platform</p>
        </div>

        <div className="flex items-center justify-center mb-8">
          {STEPS.map((s, i) => (
            <div key={i} className="flex items-center">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${i <= step ? 'bg-indigo-600 text-white' : 'bg-navy-800 text-gray-500'}`}>{i + 1}</div>
              {i < STEPS.length - 1 && <div className={`h-0.5 w-8 sm:w-12 mx-1 sm:mx-2 ${i < step ? 'bg-indigo-600' : 'bg-navy-800'}`} />}
            </div>
          ))}
        </div>

        <div className="card">
          {step === 0 && (
            <div className="space-y-4">
              <h2 className="text-lg font-bold">Organization Profile</h2>
              <p className="text-sm text-gray-500">Tell us about your organization</p>
              <div><label className="block text-sm text-gray-400 mb-1">Organization Name *</label><input className="input-field" value={form.step1.name} onChange={e => updateStep('step1', 'name', e.target.value)} placeholder="Acme Corp" /></div>
              <div><label className="block text-sm text-gray-400 mb-1">Primary Domain *</label><input className="input-field" value={form.step1.primary_domain} onChange={e => updateStep('step1', 'primary_domain', e.target.value)} placeholder="acme.com" /></div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="block text-sm text-gray-400 mb-1">Sector</label><select className="input-field" value={form.step1.sector} onChange={e => updateStep('step1', 'sector', e.target.value)}><option value="">Select...</option><option value="finance">Finance</option><option value="technology">Technology</option><option value="healthcare">Healthcare</option><option value="government">Government</option><option value="energy">Energy</option><option value="retail">Retail</option><option value="manufacturing">Manufacturing</option><option value="education">Education</option><option value="telecom">Telecom</option><option value="other">Other</option></select></div>
                <div><label className="block text-sm text-gray-400 mb-1">Country</label><input className="input-field" value={form.step1.country} onChange={e => updateStep('step1', 'country', e.target.value)} placeholder="IT" /></div>
              </div>
              <div><label className="block text-sm text-gray-400 mb-1">Description</label><textarea className="input-field h-20" value={form.step1.description} onChange={e => updateStep('step1', 'description', e.target.value)} placeholder="Brief description of your organization..." /></div>
            </div>
          )}

          {step === 1 && (
            <div className="space-y-4">
              <h2 className="text-lg font-bold">Asset Scope</h2>
              <p className="text-sm text-gray-500">Define the scope of your intelligence gathering. Press Enter to add items.</p>
              {[{label:'Additional Domains', key:'domains', ph:'example.com'}, {label:'Known Subdomains', key:'subdomains', ph:'api.example.com'}, {label:'IP Addresses', key:'ips', ph:'203.0.113.1'}, {label:'Keywords', key:'keywords', ph:'brand name'}, {label:'Technologies', key:'technologies', ph:'WordPress'}].map(({label, key, ph}) => (
                <div key={key}><label className="block text-sm text-gray-400 mb-1">{label}</label><input className="input-field" placeholder={`${ph} (press Enter to add)`} onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); addToList('step2', key, (e.target as HTMLInputElement).value); (e.target as HTMLInputElement).value = '' } }} />
                  <div className="flex flex-wrap gap-1 mt-1">{(form.step2 as any)[key].map((v: string, i: number) => (<span key={i} className="inline-flex items-center gap-1 px-2 py-0.5 bg-navy-700 text-gray-300 rounded text-xs">{v}<button onClick={() => removeFromList('step2', key, i)} className="text-gray-500 hover:text-red-400">Remove</button></span>))}</div>
                </div>
              ))}
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <h2 className="text-lg font-bold">API Sources</h2>
              <p className="text-sm text-gray-500">Configure external intelligence sources. These are optional and can be changed later in Settings.</p>
              {[{provider:'hibp', label:'HIBP API Key', key:'hibp_api_key', base:'hibp_base_url', en:'hibp_enabled', desc:'Have I Been Pwned breach detection'}, {provider:'shodan', label:'Shodan API Key', key:'shodan_api_key', base:'shodan_base_url', en:'shodan_enabled', desc:'Shodan exposed services and vulnerabilities'}, {provider:'intelx', label:'IntelX API Key', key:'intelx_api_key', base:'intelx_base_url', en:'intelx_enabled', desc:'Intelligence X dark web mentions'}, {provider:'virustotal', label:'VirusTotal API Key', key:'virustotal_api_key', base:'virustotal_base_url', en:'virustotal_enabled', desc:'VirusTotal domain, IP, URL and file reputation enrichment'}].map(({provider, label, key, base, en, desc}: any) => (
                <div key={key} className="bg-navy-800/50 rounded-lg p-4 space-y-3">
                  <div className="flex items-center justify-between mb-1"><label className="text-sm font-medium text-gray-300">{label}</label><label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" checked={(form.step3 as any)[en]} onChange={e => updateStep('step3', en, e.target.checked)} className="rounded" /><span className="text-xs text-gray-500">Enabled</span></label></div>
                  <p className="text-xs text-gray-500">{desc}</p>
                  {provider === 'intelx' && <select className="input-field" value={(form.step3 as any)[base]} onChange={e => updateStep('step3', base, e.target.value)}><option value="https://free.intelx.io">Free - https://free.intelx.io</option><option value="https://public.intelx.io">Public - https://public.intelx.io</option><option value="https://2.intelx.io">Paid - https://2.intelx.io</option></select>}
                  {provider !== 'intelx' && <input className="input-field" value={(form.step3 as any)[base]} onChange={e => updateStep('step3', base, e.target.value)} placeholder="Base URL" />}
                  <input type="password" className="input-field" value={(form.step3 as any)[key]} onChange={e => updateStep('step3', key, e.target.value)} placeholder="Enter API key (optional)..." />
                  <div className="flex items-center gap-3"><button className="btn-secondary" type="button" onClick={() => testApi(provider)}>Test</button>{apiTestStatus[provider] && <span className="text-xs text-gray-500">{apiTestStatus[provider]}</span>}</div>
                </div>
              ))}
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              <h2 className="text-lg font-bold">Scan Policy</h2>
              <p className="text-sm text-gray-500">Configure how the platform will scan your assets</p>
              <div><label className="block text-sm text-gray-400 mb-2">Scan Type</label><div className="flex gap-4">{[{val:'light', label:'Light Scan', desc:'Passive analysis only'}, {val:'deep', label:'Deep Scan', desc:'Passive + active scanning'}].map(t => (<button key={t.val} onClick={() => updateStep('step5', 'scan_type', t.val)} className={`flex-1 px-4 py-3 rounded-lg border text-left ${form.step5.scan_type === t.val ? 'border-indigo-500 bg-indigo-600/20' : 'border-navy-600'}`}><span className={form.step5.scan_type === t.val ? 'text-indigo-300 font-medium' : 'text-gray-400'}>{t.label}</span><p className="text-xs text-gray-500 mt-1">{t.desc}</p></button>))}</div></div>
              <div className="space-y-3"><p className="text-sm text-gray-400 font-medium">Sources to enable:</p>{[{label:'Enable Nmap (Active Scan)', key:'nmap_enabled', warn:true}, {label:'Enable Shodan', key:'shodan_enabled'}, {label:'Enable HIBP', key:'hibp_enabled'}, {label:'Enable IntelX', key:'intelx_enabled'},
                  {label:'Enable AlienVault OTX', key:'otx_enabled'}, {label:'Enable VirusTotal', key:'virustotal_enabled'}].map(({label, key, warn}) => (<label key={key} className="flex items-center gap-3 cursor-pointer"><input type="checkbox" checked={(form.step5 as any)[key]} onChange={e => updateStep('step5', key, e.target.checked)} className="rounded" /><span className="text-sm text-gray-300">{label}</span>{warn && (form.step5 as any)[key] && <span className="text-xs text-amber-400">requires authorization</span>}</label>))}</div>
              <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4 mt-4"><label className="flex items-start gap-3 cursor-pointer"><input type="checkbox" checked={form.step5.authorization_confirmed} onChange={e => updateStep('step5', 'authorization_confirmed', e.target.checked)} className="rounded mt-1" /><span className="text-sm text-amber-300">I confirm that I have authorization to perform scans and analysis on the assets specified above. Active scanning will only target explicitly authorized assets.</span></label></div>
            </div>
          )}

          {step === 4 && (
            <div className="space-y-4">
              <h2 className="text-lg font-bold">Review & Launch</h2>
              <p className="text-sm text-gray-500">Please confirm your setup before proceeding</p>
              <div className="space-y-3 text-sm">
                <div className="bg-navy-800/50 rounded-lg p-3"><span className="text-gray-500">Organization:</span> <span className="text-gray-200 ml-2">{form.step1.name}</span></div>
                <div className="bg-navy-800/50 rounded-lg p-3"><span className="text-gray-500">Domain:</span> <span className="text-gray-200 ml-2">{form.step1.primary_domain}</span></div>
                <div className="bg-navy-800/50 rounded-lg p-3"><span className="text-gray-500">Assets:</span> <span className="text-gray-200 ml-2">{form.step2.domains.length} domains, {form.step2.ips.length} IPs, {form.step2.keywords.length} keywords</span></div>
                <div className="bg-navy-800/50 rounded-lg p-3"><span className="text-gray-500">Sources:</span> <span className="text-gray-200 ml-2">{[form.step3.hibp_enabled && 'HIBP', form.step3.shodan_enabled && 'Shodan', form.step3.intelx_enabled && 'IntelX', form.step5.otx_enabled && 'AlienVault OTX', form.step5.virustotal_enabled && 'VirusTotal'].filter(Boolean).join(', ') || 'None'}</span></div>
                <div className="bg-navy-800/50 rounded-lg p-3"><span className="text-gray-500">Scan:</span> <span className="text-gray-200 ml-2">{form.step5.scan_type} {form.step5.nmap_enabled ? '+ Nmap' : ''}</span></div>
                <div className="bg-navy-800/50 rounded-lg p-3"><span className="text-gray-500">Authorization:</span> <span className={form.step5.authorization_confirmed ? 'text-emerald-400 ml-2' : 'text-red-400 ml-2'}>{form.step5.authorization_confirmed ? 'Confirmed' : 'Not confirmed'}</span></div>
              </div>
            </div>
          )}

          {error && <p className="text-red-400 text-sm mt-4 bg-red-500/10 border border-red-500/20 rounded-lg p-3">{error}</p>}

          <div className="flex justify-between mt-6 pt-4 border-t border-navy-700/50">
            <button onClick={() => { setError(''); setStep(Math.max(0, step - 1)) }} disabled={step === 0} className="btn-secondary disabled:opacity-50">Back</button>
            {step < STEPS.length - 1 ? <button onClick={nextStep} className="btn-primary">Next</button> : <button onClick={handleSubmit} disabled={loading || !form.step5.authorization_confirmed} className="btn-primary disabled:opacity-50">{loading ? 'Creating...' : 'Create & Start Scan'}</button>}
          </div>
        </div>
      </div>
    </div>
  )
}

