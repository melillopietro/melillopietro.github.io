import { useEffect, useState } from 'react'
import { getActiveOrgId } from '../api/orgStorage'
import { listScans, startScan, cancelScan, deleteScan } from '../api/scans'

type Scan = { id: string; scan_type: string; status: string; steps: any[]; created_at: string; completed_at: string|null; total_findings: number; progress: number; completed_steps?: number; total_steps?: number }
const terminal = ['completed','skipped','failed']

export default function ScansPage() {
  const [scans, setScans] = useState<Scan[]>([])
  const [loading, setLoading] = useState(false)
  const orgId = getActiveOrgId()

  const load = async () => { if (orgId) setScans(await listScans(orgId)) }
  useEffect(() => { load().catch(console.error) }, [orgId])
  useEffect(() => { const t = setInterval(() => { if (scans.some(s => ['pending','running','cancelling'].includes(s.status))) load().catch(console.error) }, 3000); return () => clearInterval(t) }, [orgId, scans])

  const start = async () => { if (!orgId) return alert('Select or create an organization first'); setLoading(true); try { await startScan(orgId); setTimeout(() => load().catch(console.error), 700) } finally { setLoading(false) } }
  const stop = async (id: string) => { if (!orgId) return; await cancelScan(orgId, id); await load() }
  const remove = async (id: string) => { if (!orgId || !confirm('Delete this scan only?')) return; await deleteScan(orgId, id); await load() }

  const statusColor = (s: string) => s === 'completed' ? 'badge-low' : s === 'running' || s === 'cancelling' ? 'badge-medium' : s === 'failed' ? 'badge-critical' : 'badge-high'
  const stepCount = (scan: Scan) => scan.completed_steps ?? scan.steps?.filter((s:any) => terminal.includes(s.status)).length ?? 0
  const totalSteps = (scan: Scan) => scan.total_steps ?? scan.steps?.length ?? 0

  return <div className="space-y-6">
    <div className="flex items-center justify-between"><h1 className="text-2xl font-bold">Scans</h1><button onClick={start} disabled={loading} className="btn-primary">{loading ? 'Starting...' : 'Start New Scan'}</button></div>
    <div className="space-y-3">
      {scans.length === 0 && <div className="card text-center py-12"><p className="text-gray-500">No scans yet. Start your first scan to gather intelligence.</p></div>}
      {scans.map(scan => <div key={scan.id} className="card">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-3"><span className={`badge ${statusColor(scan.status)}`}>{scan.status}</span><span className="text-sm text-gray-400">{scan.scan_type} scan</span></div>
          <div className="flex items-center gap-2"><span className="text-xs text-gray-500">{scan.created_at?.split('T')[0]}</span>{['pending','running','cancelling'].includes(scan.status) && <button className="btn-secondary" onClick={() => stop(scan.id)}>Stop</button>}<button className="btn-danger" onClick={() => remove(scan.id)}>Delete</button></div>
        </div>
        <div className="w-full bg-navy-800 rounded-full h-2 mb-3"><div className="bg-indigo-600 h-2 rounded-full transition-all" style={{ width: `${scan.progress || 0}%` }} /></div>
        <div className="flex items-center gap-4 text-sm text-gray-500"><span>Findings: {scan.total_findings}</span><span>Steps: {stepCount(scan)}/{totalSteps(scan)}</span></div>
        {scan.steps?.length > 0 && <div className="mt-3 grid grid-cols-2 md:grid-cols-4 gap-2">{scan.steps.map((s:any, i:number) => <div key={i} className="text-xs bg-navy-800/50 rounded px-2 py-1"><span className={s.status === 'completed' ? 'text-emerald-400' : s.status === 'running' ? 'text-amber-400' : s.status === 'failed' ? 'text-red-400' : s.status === 'skipped' ? 'text-gray-500' : 'text-gray-600'}>{s.status}</span><span className="text-gray-500 ml-1">{s.name}</span>{s.error_message && <div className="text-gray-600 truncate">{s.error_message}</div>}</div>)}</div>}
      </div>)}
    </div>
  </div>
}
