import { useEffect, useState } from 'react'
import { api } from '../api/client'
import { getActiveOrgId } from '../api/orgStorage'

interface Report {
  id: string
  title: string
  generated_at: string
  risk_score: number
  risk_level: string
  findings_count: number
}

export default function ReportsPage() {
  const [reports, setReports] = useState<Report[]>([])
  const [generating, setGenerating] = useState(false)
  const [downloading, setDownloading] = useState<string>('')
  const [error, setError] = useState('')

  const orgId = getActiveOrgId()

  useEffect(() => {
    loadReports()
  }, [orgId])

  async function loadReports() {
    if (!orgId) return

    try {
      const data = await api.get<Report[]>(`/api/orgs/${orgId}/reports`)
      setReports(data)
    } catch (err: any) {
      setError(err.message || 'Unable to load reports')
    }
  }

  async function generate() {
    if (!orgId) {
      setError('No active organization selected')
      return
    }

    setGenerating(true)
    setError('')

    try {
      await api.post(`/api/orgs/${orgId}/reports/generate`)
      await loadReports()
    } catch (err: any) {
      setError(err.message || 'Report generation failed')
    } finally {
      setGenerating(false)
    }
  }

  function getToken() {
    return (
      localStorage.getItem('token') ||
      localStorage.getItem('access_token') ||
      localStorage.getItem('auth_token') ||
      localStorage.getItem('threatx_token') ||
      localStorage.getItem('threatx_access_token') ||
      ''
    )
  }

  async function download(reportId: string) {
    if (!orgId) {
      setError('No active organization selected')
      return
    }

    const token = getToken()

    if (!token) {
      setError('Authentication token not found. Please log out and log in again.')
      return
    }

    setDownloading(reportId)
    setError('')

    try {
      const baseUrl =
        import.meta.env.VITE_API_URL ||
        import.meta.env.VITE_API_BASE_URL ||
        'http://localhost:8000'

      const response = await fetch(`${baseUrl}/api/orgs/${orgId}/reports/${reportId}/download`, {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      if (!response.ok) {
        const text = await response.text()
        throw new Error(text || `Download failed with HTTP ${response.status}`)
      }

      const blob = await response.blob()
      const url = window.URL.createObjectURL(blob)

      const a = document.createElement('a')
      a.href = url
      a.download = `threatx-report-${reportId}.pdf`
      document.body.appendChild(a)
      a.click()
      a.remove()

      window.URL.revokeObjectURL(url)
    } catch (err: any) {
      setError(err.message || 'Report download failed')
    } finally {
      setDownloading('')
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Reports</h1>
          <p className="text-gray-500">Generate and download authenticated PDF reports.</p>
        </div>

        <button onClick={generate} disabled={generating || !orgId} className="btn-primary">
          {generating ? 'Generating...' : 'Generate Report'}
        </button>
      </div>

      {error && (
        <div className="card border border-red-500/40 bg-red-500/10 text-red-300 text-sm">
          {error}
        </div>
      )}

      {!orgId ? (
        <div className="card text-center py-12">
          <p className="text-gray-600">No active organization selected.</p>
        </div>
      ) : reports.length === 0 ? (
        <div className="card text-center py-12">
          <p className="text-gray-600">No reports generated yet</p>
        </div>
      ) : (
        <div className="grid gap-4">
          {reports.map(r => (
            <div key={r.id} className="card flex items-center justify-between gap-4">
              <div>
                <h3 className="font-semibold text-white">{r.title}</h3>
                <p className="text-sm text-gray-500">
                  Generated: {r.generated_at} · Risk: {r.risk_level} · Findings: {r.findings_count}
                </p>
              </div>

              <button
                onClick={() => download(r.id)}
                disabled={downloading === r.id}
                className="btn-secondary text-sm"
              >
                {downloading === r.id ? 'Downloading...' : 'Download PDF'}
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
