import { useEffect, useState } from 'react'
import { api } from '../api/client'
import { saveActiveOrgId, getActiveOrgId, clearActiveOrgId } from '../api/orgStorage'

type Org = { id: string; name: string; primary_domain: string; slug?: string }

export default function OrganizationsPage() {
  const [orgs, setOrgs] = useState<Org[]>([])
  const [active, setActive] = useState(getActiveOrgId())
  const [name, setName] = useState('')
  const [domain, setDomain] = useState('')

  const load = async () => {
    const data = await api.get<Org[]>('/api/orgs')
    setOrgs(data)
    if (!active && data[0]) { saveActiveOrgId(data[0].id); setActive(data[0].id) }
  }
  useEffect(() => { load().catch(console.error) }, [])

  const createOrg = async () => {
    if (!name.trim() || !domain.trim()) return alert('Insert organization name and primary domain')
    const org = await api.post<Org>('/api/orgs', { name: name.trim(), primary_domain: domain.trim() })
    saveActiveOrgId(org.id); setActive(org.id); setName(''); setDomain(''); await load()
  }

  const useOrg = async (id: string) => {
    await api.post(`/api/orgs/${id}/select`)
    saveActiveOrgId(id); setActive(id)
  }

  const deleteOrg = async (id: string) => {
    if (!confirm('Delete this organization and its scans/assets?')) return
    await api.delete(`/api/orgs/${id}`)
    if (active === id) { clearActiveOrgId(); setActive('') }
    await load()
  }

  return <div className="space-y-6">
    <div><h1 className="text-2xl font-bold">Organizations</h1><p className="text-gray-500">Create, switch and delete organizations.</p></div>
    <div className="card space-y-4">
      <h2 className="text-lg font-semibold">Create new organization</h2>
      <div className="grid md:grid-cols-3 gap-3">
        <input className="threatx-input" placeholder="Organization name" value={name} onChange={e => setName(e.target.value)} />
        <input className="threatx-input" placeholder="Primary domain" value={domain} onChange={e => setDomain(e.target.value)} />
        <button className="btn-primary" onClick={createOrg}>Create organization</button>
      </div>
    </div>
    <div className="card space-y-4">
      <h2 className="text-lg font-semibold">Your organizations</h2>
      {orgs.length === 0 && <p className="text-gray-500">No organizations yet.</p>}
      {orgs.map(org => <div key={org.id} className="threatx-card-select p-4 flex items-center justify-between gap-3">
        <div><div className="font-semibold text-white">{org.name}</div><div className="text-sm text-gray-500">{org.primary_domain}</div></div>
        <div className="flex gap-2"><button className="btn-secondary" onClick={() => useOrg(org.id)}>{active === org.id ? 'Active' : 'Use'}</button><button className="btn-danger" onClick={() => deleteOrg(org.id)}>Delete</button></div>
      </div>)}
    </div>
  </div>
}
