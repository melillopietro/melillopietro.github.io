import { Outlet, Link, useLocation } from 'react-router-dom'
import { useAuth } from '../features/auth/AuthContext'
import { useState } from 'react'

const navItems = [
  { path: '/', label: 'Dashboard', icon: 'D' },
  { path: '/organizations', label: 'Organizations', icon: 'O' },
  { path: '/assets', label: 'Assets', icon: 'A' },
  { path: '/scans', label: 'Scans', icon: 'S' },
  { path: '/search', label: 'Search', icon: 'Q' },
  { path: '/reports', label: 'Reports', icon: 'R' },
  { path: '/alerts', label: 'Alerts', icon: '!' },
  { path: '/settings', label: 'Settings', icon: 'G' },
]

export default function AppLayout() {
  const { user, logout } = useAuth()
  const location = useLocation()
  const [collapsed, setCollapsed] = useState(false)

  return (
    <div className="flex h-screen overflow-hidden">
      <aside className={`${collapsed ? 'w-16' : 'w-64'} bg-navy-900 border-r border-navy-700/50 flex flex-col transition-all duration-300`}>
        <div className="p-4 border-b border-navy-700/50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center font-bold text-sm">TX</div>
            {!collapsed && <span className="font-bold text-lg bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent">ThreatX</span>}
          </div>
        </div>
        <nav className="flex-1 p-3 space-y-1">
          {navItems.map(item => (
            <Link key={item.path} to={item.path} className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors ${location.pathname === item.path ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/30' : 'text-gray-400 hover:text-gray-200 hover:bg-navy-800'}`}>
              <span className="w-5 h-5 rounded bg-navy-800 flex items-center justify-center text-xs">{item.icon}</span>
              {!collapsed && <span>{item.label}</span>}
            </Link>
          ))}
        </nav>
        <div className="p-4 border-t border-navy-700/50">
          {!collapsed && <p className="text-xs text-gray-500 truncate">{user?.email}</p>}
          <button onClick={logout} className="text-xs text-gray-500 hover:text-red-400 mt-1">Logout</button>
        </div>
      </aside>

      <main className="flex-1 overflow-auto">
        <header className="bg-navy-900/50 border-b border-navy-700/50 px-6 py-4 backdrop-blur-sm sticky top-0 z-10">
          <div className="flex items-center justify-between">
            <button onClick={() => setCollapsed(!collapsed)} className="text-gray-400 hover:text-white">Menu</button>
            <div className="flex items-center gap-4">
              <span className="text-sm text-gray-400">{user?.full_name}</span>
              <div className="w-8 h-8 bg-indigo-600 rounded-full flex items-center justify-center text-xs font-bold">{user?.full_name?.charAt(0).toUpperCase()}</div>
            </div>
          </div>
        </header>
        <div className="p-6"><Outlet /></div>
      </main>
    </div>
  )
}
