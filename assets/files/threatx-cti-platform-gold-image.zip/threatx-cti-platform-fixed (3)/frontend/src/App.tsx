import { Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider, useAuth } from './features/auth/AuthContext'
import LoginPage from './pages/LoginPage'
import RegisterPage from './pages/RegisterPage'
import DashboardPage from './pages/DashboardPage'
import WizardPage from './pages/WizardPage'
import AssetsPage from './pages/AssetsPage'
import ScansPage from './pages/ScansPage'
import SearchPage from './pages/SearchPage'
import ReportsPage from './pages/ReportsPage'
import AlertsPage from './pages/AlertsPage'
import SettingsPage from './pages/SettingsPage'
import OrganizationsPage from './pages/OrganizationsPage'
import AppLayout from './layouts/AppLayout'

function Loading() {
  return <div className="flex items-center justify-center h-screen bg-navy-950"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500" /></div>
}

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth()
  if (loading) return <Loading />
  if (!user) return <Navigate to="/login" replace />
  return <>{children}</>
}

function RequireOrg({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth()
  if (loading) return <Loading />
  if (!user) return <Navigate to="/login" replace />
  const hasOrg = user.active_organization_id || localStorage.getItem('active_org_id') || localStorage.getItem('org_id')
  if (!hasOrg) return <Navigate to="/wizard" replace />
  return <>{children}</>
}

function PublicOnlyRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth()
  if (loading) return <Loading />
  if (user) {
    const hasOrg = user.active_organization_id || localStorage.getItem('active_org_id') || localStorage.getItem('org_id')
    return <Navigate to={hasOrg ? '/' : '/wizard'} replace />
  }
  return <>{children}</>
}

export default function App() {
  return (
    <AuthProvider>
      <Routes>\n          <Route path="/settings" element={<SettingsPage />} />
        <Route path="/login" element={<PublicOnlyRoute><LoginPage /></PublicOnlyRoute>} />
        <Route path="/register" element={<PublicOnlyRoute><RegisterPage /></PublicOnlyRoute>} />
        <Route path="/wizard" element={<ProtectedRoute><WizardPage /></ProtectedRoute>} />
        <Route path="/" element={<RequireOrg><AppLayout /></RequireOrg>}>
          <Route index element={<DashboardPage />} />
          <Route path="organizations" element={<OrganizationsPage />} />
          <Route path="assets" element={<AssetsPage />} />
          <Route path="scans" element={<ScansPage />} />
          <Route path="search" element={<SearchPage />} />
          <Route path="reports" element={<ReportsPage />} />
          <Route path="alerts" element={<AlertsPage />} />
          <Route path="settings" element={<SettingsPage />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </AuthProvider>
  )
}
