import api from "./client";

export interface Organization {
  id: string;
  name: string;
  slug?: string;
  primary_domain?: string;
  created_at?: string;
}

export interface OrganizationsResponse {
  organizations: Organization[];
  organization?: Organization;
  active_organization_id?: string | null;
  next_active_org_id?: string | null;
}

export function saveOrgId(orgId: string) {
  localStorage.setItem("active_org_id", orgId);
  localStorage.setItem("org_id", orgId);
  localStorage.setItem("organization_id", orgId);
  localStorage.setItem("current_org_id", orgId);
}

export function clearOrgId() {
  localStorage.removeItem("active_org_id");
  localStorage.removeItem("org_id");
  localStorage.removeItem("organization_id");
  localStorage.removeItem("current_org_id");
}

export function getStoredOrgId(): string {
  return (
    localStorage.getItem("active_org_id") ||
    localStorage.getItem("org_id") ||
    localStorage.getItem("organization_id") ||
    localStorage.getItem("current_org_id") ||
    ""
  );
}

export async function getOrganizations(): Promise<OrganizationsResponse> {
  const organizations = await api.get<Organization[]>("/api/orgs");
  let active = getStoredOrgId();
  try {
    const me = await api.get<{ active_organization_id?: string | null }>("/api/auth/me");
    if (me.active_organization_id) active = me.active_organization_id;
  } catch {}
  if (!active && organizations.length > 0) active = organizations[0].id;
  if (active) saveOrgId(active);
  return { organizations, active_organization_id: active || null };
}

export async function createOrganization(name: string, primaryDomain: string): Promise<OrganizationsResponse> {
  const organization = await api.post<Organization>("/api/orgs", {
    name,
    primary_domain: primaryDomain,
  });
  saveOrgId(organization.id);
  return { organization, organizations: [organization], active_organization_id: organization.id };
}

export async function activateOrganization(orgId: string): Promise<{ active_organization_id: string }> {
  const response = await api.post<{ active_organization_id?: string; organization_id?: string }>(`/api/orgs/${orgId}/select`);
  const active = response.active_organization_id || response.organization_id || orgId;
  saveOrgId(active);
  return { active_organization_id: active };
}

export async function deleteOrganization(orgId: string): Promise<OrganizationsResponse> {
  const response = await api.delete<OrganizationsResponse>(`/api/orgs/${orgId}`);
  if (response.next_active_org_id) saveOrgId(response.next_active_org_id);
  else clearOrgId();
  return response;
}
