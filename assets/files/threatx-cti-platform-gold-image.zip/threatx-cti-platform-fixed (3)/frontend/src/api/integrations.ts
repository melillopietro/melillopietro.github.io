import api from "./client";

export type IntegrationStatus = "not_configured" | "untested" | "ok" | "failed";

export interface Integration {
  provider: string;
  display_name: string;
  base_url?: string;
  enabled: boolean;
  configured: boolean;
  last_test_status: IntegrationStatus;
  last_test_message?: string;
  last_test_at?: string;
}

export interface IntegrationUpdate {
  api_key?: string;
  base_url?: string;
  enabled: boolean;
}

export async function getIntegrations(orgId: string): Promise<Integration[]> {
  const response: any = await api.get(`/api/orgs/${orgId}/integrations`);
  return response.data;
}

export async function updateIntegration(
  orgId: string,
  provider: string,
  payload: IntegrationUpdate
): Promise<Integration> {
  const response: any = await api.put(`/api/orgs/${orgId}/integrations/${provider}`, payload);
  return response.data;
}

export async function testIntegration(orgId: string, provider: string): Promise<any> {
  const response: any = await api.post(`/api/orgs/${orgId}/integrations/${provider}/test`);
  return response.data;
}

export async function deleteIntegration(orgId: string, provider: string): Promise<any> {
  const response: any = await api.delete(`/api/orgs/${orgId}/integrations/${provider}`);
  return response.data;
}
