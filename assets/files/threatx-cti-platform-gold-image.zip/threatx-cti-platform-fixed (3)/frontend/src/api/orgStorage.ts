const ORG_KEYS = [
  "active_org_id",
  "org_id",
  "organization_id",
  "current_org_id",
];

export function getStoredOrgId(): string {
  for (const key of ORG_KEYS) {
    const value = localStorage.getItem(key);
    if (value && value.trim()) {
      return value;
    }
  }
  return "";
}

export function saveOrgId(orgId: string | null | undefined): void {
  if (!orgId) {
    clearOrgId();
    return;
  }

  for (const key of ORG_KEYS) {
    localStorage.setItem(key, orgId);
  }
}

export function clearOrgId(): void {
  for (const key of ORG_KEYS) {
    localStorage.removeItem(key);
  }
}

export function hasStoredOrgId(): boolean {
  return Boolean(getStoredOrgId());
}

export const getActiveOrgId = getStoredOrgId;
export const setActiveOrgId = saveOrgId;
export const saveActiveOrgId = saveOrgId;
export const clearActiveOrgId = clearOrgId;

export const getSavedOrgId = getStoredOrgId;
export const setSavedOrgId = saveOrgId;
export const saveSavedOrgId = saveOrgId;
export const clearSavedOrgId = clearOrgId;

export const getCurrentOrgId = getStoredOrgId;
export const setCurrentOrgId = saveOrgId;
export const saveCurrentOrgId = saveOrgId;
export const clearCurrentOrgId = clearOrgId;
