import { api } from './client'
export const listScans = (orgId: string) => api.get<any[]>(`/api/orgs/${orgId}/scans`)
export const startScan = (orgId: string) => api.post(`/api/orgs/${orgId}/scans/start`)
export const cancelScan = (orgId: string, scanId: string) => api.post(`/api/orgs/${orgId}/scans/${scanId}/cancel`)
export const deleteScan = (orgId: string, scanId: string) => api.delete(`/api/orgs/${orgId}/scans/${scanId}`)
