export async function downloadAuthenticatedFile(endpoint: string, filename: string) {
  const baseUrl =
    import.meta.env.VITE_API_URL ||
    import.meta.env.VITE_API_BASE_URL ||
    'http://localhost:8000'

  const token =
    localStorage.getItem('access_token') ||
    localStorage.getItem('token') ||
    localStorage.getItem('auth_token') ||
    localStorage.getItem('threatx_token') ||
    localStorage.getItem('threatx_access_token')

  const headers: Record<string, string> = {}

  if (token) {
    headers.Authorization = `Bearer ${token}`
  }

  const res = await fetch(baseUrl + endpoint, {
    method: 'GET',
    headers,
  })

  if (!res.ok) {
    const text = await res.text()
    throw new Error(text || `Download failed with HTTP ${res.status}`)
  }

  const blob = await res.blob()
  const url = window.URL.createObjectURL(blob)

  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  a.remove()

  window.URL.revokeObjectURL(url)
}
