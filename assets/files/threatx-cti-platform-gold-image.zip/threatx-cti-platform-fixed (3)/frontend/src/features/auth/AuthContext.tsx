import { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import { api } from '../../api/client'
import { saveOrgId, clearOrgId } from '../../api/orgStorage'

export interface User {
  id: string
  email: string
  full_name: string
  active_organization_id?: string | null
}

interface AuthContextType {
  user: User | null
  loading: boolean
  login: (email: string, password: string) => Promise<User>
  register: (email: string, password: string, fullName: string) => Promise<User>
  logout: () => void
  setUser: (user: User) => void
}

const AuthContext = createContext<AuthContextType>({} as AuthContextType)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const token = localStorage.getItem('token')
    if (token) {
      api.setToken(token)
      api.get<User>('/api/auth/me')
        .then((userData) => {
          setUser(userData)
          if (userData.active_organization_id) saveOrgId(userData.active_organization_id)
        })
        .catch(() => {
          api.setToken(null)
          clearOrgId()
        })
        .finally(() => setLoading(false))
    } else {
      setLoading(false)
    }
  }, [])

  const login = async (email: string, password: string): Promise<User> => {
    const res = await api.post<{ access_token: string; user: User }>('/api/auth/login', { email, password })
    api.setToken(res.access_token)
    setUser(res.user)
    if (res.user.active_organization_id) saveOrgId(res.user.active_organization_id)
    return res.user
  }

  const register = async (email: string, password: string, fullName: string): Promise<User> => {
    const res = await api.post<{ access_token: string; user: User }>('/api/auth/register', { email, password, full_name: fullName })
    api.setToken(res.access_token)
    setUser(res.user)
    return res.user
  }

  const logout = () => {
    api.setToken(null)
    clearOrgId()
    setUser(null)
  }

  return <AuthContext.Provider value={{ user, loading, login, register, logout, setUser }}>{children}</AuthContext.Provider>
}

export const useAuth = () => useContext(AuthContext)
